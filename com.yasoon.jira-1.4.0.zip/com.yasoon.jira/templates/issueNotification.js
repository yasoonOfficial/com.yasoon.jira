this["jira"] = this["jira"] || {};
this["jira"]["templates"] = this["jira"]["templates"] || {};
this["jira"]["templates"]["issueNotification"] = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n					<span title=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\r\n						<img src=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.iconUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" onerror=\"jiraHandleImageFallback(this)\" /> "
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n					</span>\r\n				";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n					<span class=\"aui-lozenge jira-issue-status-lozenge jira-issue-status-lozenge-"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.statusCategory)),stack1 == null || stack1 === false ? stack1 : stack1.colorName)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" title=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\r\n						"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n					</span>\r\n				";
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += " "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.duedate)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " ";
  return buffer;
  }

function program7(depth0,data) {
  
  
  return " - ";
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.affectedVersions", options) : helperMissing.call(depth0, "i18n", "notification.affectedVersions", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							<span>\r\n								";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.versions), {hash:{},inverse:self.noop,fn:self.program(10, program10, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n							</span>\r\n						</div>\r\n					</div>\r\n					";
  return buffer;
  }
function program10(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n								";
  stack1 = helpers.unless.call(depth0, (data == null || data === false ? data : data.first), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "<span title=\"";
  if (helper = helpers.description) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.description); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"> ";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\r\n								";
  return buffer;
  }
function program11(depth0,data) {
  
  
  return ", ";
  }

function program13(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.environment", options) : helperMissing.call(depth0, "i18n", "notification.environment", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							<div>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.environment)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</div>\r\n						</div>\r\n					</div>\r\n					";
  return buffer;
  }

function program15(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n								<span title=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\r\n									<img src=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.iconUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" onerror=\"jiraHandleImageFallback(this)\" /> "
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n								</span>\r\n							";
  return buffer;
  }

function program17(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\r\n								<span class=\"aui-lozenge jira-issue-status-lozenge jira-issue-status-lozenge-"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.statusCategory)),stack1 == null || stack1 === false ? stack1 : stack1.colorName)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" title=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\r\n									"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n								</span>\r\n							";
  return buffer;
  }

function program19(depth0,data) {
  
  var stack1;
  return escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.resolution)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1));
  }

function program21(depth0,data) {
  
  
  return "not done";
  }

function program23(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.fixVersions", options) : helperMissing.call(depth0, "i18n", "notification.fixVersions", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							<span>\r\n								";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.fixVersions), {hash:{},inverse:self.noop,fn:self.programWithDepth(24, program24, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n							</span>\r\n						</div>\r\n					</div>\r\n					";
  return buffer;
  }
function program24(depth0,data,depth1) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n								";
  stack1 = helpers.unless.call(depth0, (data == null || data === false ? data : data.first), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "<a href=\""
    + escapeExpression(((stack1 = (depth1 && depth1.baseUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "/browse/"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth1 && depth1.fields)),stack1 == null || stack1 === false ? stack1 : stack1.project)),stack1 == null || stack1 === false ? stack1 : stack1.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "/fixforversion/";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" title=\"";
  if (helper = helpers.description) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.description); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"> ";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</a>\r\n								";
  return buffer;
  }

function program26(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n			<div style=\"font:bold 14px arial, sans-serif; position:relative; overflow:hidden; margin-top: 15px;\">\r\n				"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.attachments", options) : helperMissing.call(depth0, "i18n", "notification.attachments", options)))
    + " <span style=\"position:absolute;  border-bottom: 1px solid #E2E2E2;width: 100%;top: 8px;margin: 0px 4px;\"></span>\r\n			</div>\r\n			<div class=\"row\" style=\"margin-top: 5px;\">\r\n				<div class=\"col-sm-12\">\r\n					";
  stack1 = helpers.each.call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.attachment), {hash:{},inverse:self.noop,fn:self.program(27, program27, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n				</div>\r\n			</div>\r\n			";
  return buffer;
  }
function program27(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\r\n					<span class=\"jiraFile\" style=\"margin-right:15px; white-space:nowrap;\">\r\n						<a href=\"";
  if (helper = helpers.content) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.content); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\r\n							<img style=\"width:16px;\" src=\"";
  if (helper = helpers.fileIcon) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.fileIcon); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" />";
  if (helper = helpers.filename) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.filename); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n						</a>\r\n					</span>\r\n					";
  return buffer;
  }

function program29(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n			<div class=\"row\" style=\"margin-top: 5px;\">\r\n				<div class=\"col-sm-4\">\r\n					<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.dueAt", options) : helperMissing.call(depth0, "i18n", "notification.dueAt", options)))
    + ":</span>\r\n				</div>\r\n				<div class=\"col-sm-8\">\r\n					<span>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.duedate)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\r\n				</div>\r\n			</div>\r\n			";
  return buffer;
  }

function program31(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\r\n			<div class=\"row\" style=\"margin-top: 5px;\">\r\n				<div class=\"col-sm-4\">\r\n					<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.finishedAt", options) : helperMissing.call(depth0, "i18n", "notification.finishedAt", options)))
    + ":</span>\r\n				</div>\r\n				<div class=\"col-sm-8\">\r\n					<span> "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.resolutiondate)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</span>\r\n				</div>\r\n			</div>\r\n			";
  return buffer;
  }

  buffer += "<div style=\"position:relative; line-height: 1.42857;\" class=\"jiraContainer\">\r\n	<!-- Collapsed View-->\r\n	<div class=\"row body-collapsed\" style=\"padding-top:2px; padding-bottom:3px;\">\r\n		<div class=\"col-sm-12\" style=\"padding-left: 20px;\">\r\n			<div class=\"jiraFeedExpand pull-left\" style=\"font:bold 14px arial, sans-serif; position:relative; overflow:hidden; cursor:pointer;\">\r\n				<i class=\"fa fa-caret-right\"></i> "
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.summary", options) : helperMissing.call(depth0, "i18n", "notification.summary", options)))
    + ":\r\n			</div>\r\n			<div class=\"pull-left summary-entry\" >\r\n				<span title=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.issuetype)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" >\r\n					<img src=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.issuetype)),stack1 == null || stack1 === false ? stack1 : stack1.iconUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" onerror=\"jiraHandleImageFallback(this)\" />"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.issuetype)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n				</span>\r\n			</div>\r\n			<div class=\"pull-left summary-entry\">\r\n				";
  stack1 = helpers.unless.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.statusCategory), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n				";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.statusCategory), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n			</div>\r\n			<div class=\"pull-left summary-entry\">\r\n				<span title=\""
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.dueAt", options) : helperMissing.call(depth0, "i18n", "notification.dueAt", options)))
    + "\">\r\n					<i class=\"fa fa-clock-o\"></i> ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.duedate), {hash:{},inverse:self.program(7, program7, data),fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n			</div>\r\n			<div class=\"pull-left summary-entry\">\r\n				<span>\r\n					<img src=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.assignee)),stack1 == null || stack1 === false ? stack1 : stack1.avatarUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" /> "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.assignee)),stack1 == null || stack1 === false ? stack1 : stack1.displayName)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n				</span>\r\n			</div>\r\n		</div>\r\n	</div>\r\n	<!-- Expanded View-->\r\n	<div class=\"row body-open\" style=\"display:none;\">\r\n		<div class=\"col-sm-8\" style=\"padding: 2px 20px;\">\r\n			<div class=\"jiraFeedClose\" style=\"font:bold 14px arial, sans-serif; position:relative; overflow:hidden; cursor:pointer;\">\r\n				<i class=\"fa fa-caret-down\"></i> "
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.details", options) : helperMissing.call(depth0, "i18n", "notification.details", options)))
    + " <span style=\"position:absolute;  border-bottom: 1px solid #E2E2E2;width: 100%;top: 8px;margin: 0px 4px;\"></span>\r\n			</div>\r\n			<div class=\"row\" >\r\n				<div class=\"col-sm-6\">\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.type", options) : helperMissing.call(depth0, "i18n", "notification.type", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							<span title=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.issuetype)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\r\n								<img src=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.issuetype)),stack1 == null || stack1 === false ? stack1 : stack1.iconUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" style=\"margin-right: 2px; width: 16px;\" onerror=\"jiraHandleImageFallback(this)\"/>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.issuetype)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n							</span>\r\n						</div>\r\n					</div>\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.priority", options) : helperMissing.call(depth0, "i18n", "notification.priority", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							<span>\r\n								<img src=\""
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.priority)),stack1 == null || stack1 === false ? stack1 : stack1.iconUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" style=\"margin-right: 2px; width: 16px;\" onerror=\"jiraHandleImageFallback(this)\"/>"
    + escapeExpression(((stack1 = ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.priority)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n							</span>\r\n						</div>\r\n					</div>\r\n					";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.versions), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n					";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.environment), {hash:{},inverse:self.noop,fn:self.program(13, program13, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n				</div>\r\n				<div class=\"col-sm-6\">\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.status", options) : helperMissing.call(depth0, "i18n", "notification.status", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							";
  stack1 = helpers.unless.call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.statusCategory), {hash:{},inverse:self.noop,fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n							";
  stack1 = helpers['if'].call(depth0, ((stack1 = ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.status)),stack1 == null || stack1 === false ? stack1 : stack1.statusCategory), {hash:{},inverse:self.noop,fn:self.program(17, program17, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n						</div>\r\n					</div>\r\n					<div class=\"row\" style=\"margin-top: 5px;\">\r\n						<div class=\"col-sm-4\">\r\n							<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.solution", options) : helperMissing.call(depth0, "i18n", "notification.solution", options)))
    + ":</span>\r\n						</div>\r\n						<div class=\"col-sm-8\">\r\n							<span> ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.resolution), {hash:{},inverse:self.program(21, program21, data),fn:self.program(19, program19, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\r\n						</div>\r\n					</div>\r\n					";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.fixVersions), {hash:{},inverse:self.noop,fn:self.program(23, program23, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n				</div>\r\n			</div>\r\n			<div style=\"font:bold 14px arial, sans-serif; position:relative; overflow:hidden; margin-top: 15px;\">\r\n				"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.description", options) : helperMissing.call(depth0, "i18n", "notification.description", options)))
    + " <span style=\"position:absolute;  border-bottom: 1px solid #E2E2E2;width: 100%;top: 8px;margin: 0px 4px;\"></span>\r\n			</div>\r\n			<div class=\"row\" style=\"margin-top: 5px;\">\r\n				<div class=\"col-sm-12\"> ";
  stack1 = ((stack1 = ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.description)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1);
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</div>\r\n			</div>\r\n			";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.fields)),stack1 == null || stack1 === false ? stack1 : stack1.attachment), {hash:{},inverse:self.noop,fn:self.program(26, program26, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n		</div>\r\n		<div class=\"col-sm-4\" style=\"padding: 10px 20px;\">\r\n			<div style=\"font:bold 14px arial, sans-serif; position:relative; overflow:hidden;\">\r\n				"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.persons", options) : helperMissing.call(depth0, "i18n", "notification.persons", options)))
    + " <span style=\"position:absolute;  border-bottom: 1px solid #E2E2E2;width: 100%;top: 8px;margin: 0px 4px;\"></span>\r\n			</div>\r\n			<div class=\"row\" style=\"margin-top: 5px;\">\r\n				<div class=\"col-sm-4\">\r\n					<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.assignee", options) : helperMissing.call(depth0, "i18n", "notification.assignee", options)))
    + ":</span>\r\n				</div>\r\n				<div class=\"col-sm-8\">\r\n					<span>\r\n						<img src=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.assignee)),stack1 == null || stack1 === false ? stack1 : stack1.avatarUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" style=\"margin-right: 2px; width: 16px;\" /> "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.assignee)),stack1 == null || stack1 === false ? stack1 : stack1.displayName)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n					</span>\r\n				</div>\r\n			</div>\r\n			<div class=\"row\" style=\"margin-top: 5px;\">\r\n				<div class=\"col-sm-4\">\r\n					<span style=\"color: #707070\">"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.creator", options) : helperMissing.call(depth0, "i18n", "notification.creator", options)))
    + ":</span>\r\n				</div>\r\n				<div class=\"col-sm-8\">\r\n					<span>\r\n						<img src=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.creator)),stack1 == null || stack1 === false ? stack1 : stack1.avatarUrl)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" style=\"margin-right: 2px; width: 16px;\" /> "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.creator)),stack1 == null || stack1 === false ? stack1 : stack1.displayName)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\r\n					</span>\r\n				</div>\r\n			</div>\r\n			<div style=\"font:bold 14px arial, sans-serif; position:relative; overflow:hidden; margin-top:15px;\">\r\n				"
    + escapeExpression((helper = helpers.i18n || (depth0 && depth0.i18n),options={hash:{},data:data},helper ? helper.call(depth0, "notification.dates", options) : helperMissing.call(depth0, "i18n", "notification.dates", options)))
    + " <span style=\"position:absolute;  border-bottom: 1px solid #E2E2E2;width: 100%;top: 8px;margin: 0px 4px;\"></span>\r\n			</div>\r\n			";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.duedate), {hash:{},inverse:self.noop,fn:self.program(29, program29, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n			";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.renderedFields)),stack1 == null || stack1 === false ? stack1 : stack1.resolutiondate), {hash:{},inverse:self.noop,fn:self.program(31, program31, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\r\n		</div>\r\n	</div>\r\n</div>";
  return buffer;
  });