/// <reference path="../../definitions/bluebird.d.ts" />
/// <reference path="../../definitions/jira.d.ts" />
/// <reference path="../../definitions/common.d.ts" />
/// <reference path="../../definitions/yasoon.d.ts" />
/// <reference path="../../definitions/allFields.d.ts" />
/// <reference path="./../renderer/FieldController.ts" />
/// <reference path="./../renderer/EmailController.ts" />
/// <reference path="./../renderer/TemplateController.ts" />
/// <reference path="./../renderer/RecentItemController.ts" />
/// <reference path="./../renderer/ServiceDeskController.ts" />
var jira = null; //Legacy
var NewEditDialog = (function () {
    function NewEditDialog() {
        var _this = this;
        //For application
        this.icons = new JiraIconController();
        this.recentItems = null;
        this.emailController = null;
        this.templateController = null;
        this.serviceDeskController = null;
        this.selectedProject = null;
        this.selectedIssueType = null;
        this.issueCreatedKey = null;
        //From Init
        this.isEditMode = false;
        this.systemInfo = null;
        this.editIssueId = null;
        this.settings = null;
        this.ownUser = null;
        this.mail = null;
        this.cacheUserMeta = [];
        this.cacheCreateMetas = [];
        this.cacheProjects = [];
        this.type = '';
        //Current Issue for editIssueId
        this.currentIssue = null;
        //Order of Fields in the form if in fixed mode. Fields not part of the array will be rendered afterwards
        this.fieldOrder = [
            'summary',
            'priority',
            'duedate',
            'components',
            'versions',
            'fixVersions',
            'assignee',
            'reporter',
            'environment',
            'description',
            'attachment',
            'labels',
            'timetracking'
        ];
        this.init = function (initParams) {
            jira = _this;
            //Parameter taken over from Main JIRA
            _this.settings = initParams.settings;
            _this.ownUser = initParams.ownUser;
            _this.isEditMode = !!initParams.editIssueId;
            _this.editIssueId = initParams.editIssueId;
            _this.mail = initParams.mail;
            _this.cacheUserMeta = initParams.userMeta || [];
            _this.cacheCreateMetas = initParams.createMetas || [];
            _this.cacheProjects = initParams.projects || [];
            _this.systemInfo = initParams.systemInfo || { versionNumbers: [6, 4, 0] };
            _this.type = initParams.type || '';
            //Register Close Handler
            yasoon.dialog.onClose(_this.cleanup);
            // Resize Window if nessecary (sized are optimized for default Window - user may have changed that)
            resizeWindowNew();
            //It's the edit case
            //Add Class to change title & labels
            if (_this.isEditMode) {
                $('#create-issue-dialog').addClass('edit-mode');
            }
            setTimeout(function () { _this.initDelayed(); }, 1);
        };
        this.cleanup = function () {
            //Invalidate dialog events so the following won't throw any events => will lead to errors
            // due to pending dialog.close
            yasoon.dialog.clearEvents();
            FieldController.raiseEvent(EventType.Cleanup, null);
        };
    }
    NewEditDialog.prototype.initDelayed = function () {
        var _this = this;
        try {
            //Init Fields - do this lately so yasoon.i18n is initialized
            this.loadFields();
            //Init Controller
            if (this.mail) {
                this.emailController = new EmailController(this.mail, this.type, this.settings, this.ownUser);
            }
            if (!this.isEditMode) {
                this.templateController = new TemplateController(this.ownUser, this.emailController);
            }
            this.recentItems = new RecentItemController(this.ownUser);
            this.serviceDeskController = new ServiceDeskController();
            //Render Header fields
            var projParams = {
                cache: this.cacheProjects,
                allowClear: false,
                isMainProjectField: true,
                showTemplates: true
            };
            FieldController.loadField(ProjectField.defaultMeta, ProjectField, projParams);
            FieldController.render(FieldController.projectFieldId, $('#HeaderArea'));
            FieldController.loadField(IssueTypeField.defaultMeta, IssueTypeField);
            FieldController.render(FieldController.issueTypeFieldId, $('#IssueArea'));
            //Register Attachment Field with concrete attachments
            var attachments = [];
            if (this.emailController) {
                attachments = this.emailController.getAttachmentFileHandles();
            }
            FieldController.register(FieldController.attachmentFieldId, AttachmentField, attachments);
            //Hook Events
            FieldController.registerEvent(EventType.FieldChange, this, FieldController.projectFieldId);
            FieldController.registerEvent(EventType.FieldChange, this, FieldController.issueTypeFieldId);
            if (this.isEditMode) {
                $('#LoaderArea').removeClass('hidden');
                //Set Project and issueType read-only
                $('#' + FieldController.projectFieldId).prop('disabled', true);
                $('#' + FieldController.issueTypeFieldId).prop('disabled', true);
                jiraGet('/rest/api/2/issue/' + this.editIssueId + '?expand=editmeta,renderedFields')
                    .then(function (issueString) {
                    _this.currentIssue = JSON.parse(issueString);
                    //Set Project and issueType 
                    FieldController.setValue(FieldController.projectFieldId, _this.currentIssue.fields['project'], true);
                    FieldController.setValue(FieldController.issueTypeFieldId, _this.currentIssue.fields['issuetype'], true);
                })
                    .catch(function (e) {
                    $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitConnection'));
                    console.log('Error during init of Edit View', e);
                    yasoon.util.log('Error during init of Edit View. ' + e.message, yasoon.util.severity.warning, getStackTrace(e));
                });
            }
            else {
                this.templateController.setInitialValues();
            }
            //Submit Button - (Create & Edit)
            $('#create-issue-submit').click(function (e) { _this.submitForm(e); });
            $('#create-issue-cancel').click(function () {
                _this.close({ action: 'cancel' });
            });
        }
        catch (e) {
            yasoon.util.log('An error occured during initialization ' + e.message, yasoon.util.severity.warning, getStackTrace(e));
        }
    };
    NewEditDialog.prototype.close = function (params) {
        //Check if dialog should be closed or not
        if (params && params.action === 'success' && $('#qf-create-another').is(':checked')) {
            $('#JiraSpinner').addClass('hidden');
            $('#create-issue-submit').prop('disabled', false);
            $('.form-body').scrollTop(0);
            var field = FieldController.getField('summary');
            if (field) {
                field.setValue('');
            }
            field = FieldController.getField('description');
            if (field) {
                field.setValue('');
            }
            //Cleanup attachments
            FieldController.raiseEvent(EventType.AttachmentChanged, []);
        }
        else {
            if (this.mail) {
                params.mail = {
                    entryId: this.mail.entryId,
                    storeId: this.mail.storeId
                };
            }
            yasoon.dialog.close(params);
        }
    };
    NewEditDialog.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (source === FieldController.projectFieldId) {
            this.selectedProject = newValue;
            if (this.selectedProject) {
                $('#IssueArea').removeClass('hidden');
                //Check Service Desk
                $('#ServiceArea').addClass('hidden'); //IssueTypeField Button will toggle this
            }
        }
        else if (source === FieldController.issueTypeFieldId) {
            this.selectedIssueType = newValue;
            if (this.selectedIssueType.subtask) {
                if (!FieldController.getField(FieldController.issueFieldId)) {
                    //First time we need the issue field
                    var issueField = FieldController.loadField(IssueField.defaultMeta, IssueField);
                    issueField.setProject(this.selectedProject);
                    FieldController.render(FieldController.issueFieldId, $('#SubtaskArea'));
                }
                $('#SubtaskArea').removeClass('hidden');
            }
            else {
                $('#SubtaskArea').addClass('hidden');
            }
            //Get latest meta and start new Rendering
            $('#LoaderArea').removeClass('hidden');
            $('#ContentArea').css('visibility', 'hidden');
            this.getMetaData()
                .then(function (meta) {
                //Set this as current meta
                FieldController.loadMeta(meta);
                return _this.renderIssue(meta);
            })
                .then(function () {
                $('#LoaderArea').addClass('hidden');
                $('#ContentArea').css('visibility', 'visible');
            })
                .then(function () {
                //Set reporter
                var reporterField = FieldController.getField(FieldController.reporterFieldId);
                if (reporterField) {
                    reporterField.setValue(_this.ownUser);
                }
                //Set all Values in edit case
                if (_this.isEditMode && _this.currentIssue) {
                    FieldController.setFormData(_this.currentIssue);
                }
                //Set Templates Values
                if (_this.templateController) {
                    _this.templateController.applyTemplate(_this.selectedProject.id, _this.selectedIssueType.id);
                }
            })
                .catch(function (e) {
                var type = yasoon.util.severity.warning;
                if (e instanceof jiraSyncError) {
                    $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitConnection'));
                }
                else {
                    type = yasoon.util.severity.error;
                    $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitUnknown'));
                }
                console.log('Error during rendering', e, e.stack);
                yasoon.util.log('An error occured during rendering. ' + e.message, type, getStackTrace(e));
            });
        }
        return null;
    };
    NewEditDialog.prototype.submitForm = function (e) {
        var _this = this;
        e.preventDefault();
        //Reset data
        var lifecycleData = null;
        var result = {};
        this.issueCreatedKey = null;
        //Prepare UI
        $('#MainAlert').addClass('hidden');
        $('#create-issue-submit').prop('disabled', true);
        $('#JiraSpinner').removeClass('hidden');
        //Check if Request type is needed and add it
        var isServiceDesk = this.serviceDeskController.isServiceDeskActive();
        return Promise.resolve()
            .then(function () {
            //1. Collect data:
            result = FieldController.getFormData(_this.isEditMode);
            //2. Remove special data
            if (isServiceDesk) {
                /* if (!result.fields[FieldController.requestTypeFieldId]) {
                     throw new Error(yasoon.i18n('dialog.errorNoRequestType'));
                 } */
                delete result.fields[FieldController.requestTypeFieldId];
                delete result.fields[FieldController.onBehalfOfFieldId];
                delete result.fields[FieldController.reporterFieldId];
            }
            //Inform Fields that save is going to start.
            lifecycleData = {
                cancel: false,
                data: result
            };
            //Wait till all beforeSave actions are done
            return FieldController.raiseEvent(EventType.BeforeSave, lifecycleData);
        })
            .then(function () {
            if (result.cancel) {
            }
            if (isServiceDesk && !_this.isEditMode)
                return _this.serviceDeskController.doBeforeSave(result);
            else
                return Promise.resolve({ issueCreated: false });
        })
            .then(function (sdData) {
            var doUpdate = _this.isEditMode || sdData.issueCreated;
            var issueId = _this.editIssueId ? _this.editIssueId : sdData.issueId;
            //Switch for edit or create
            var url = (doUpdate) ? '/rest/api/2/issue/' + issueId : '/rest/api/2/issue';
            var method = (doUpdate) ? yasoon.ajaxMethod.Put : yasoon.ajaxMethod.Post;
            //Submit request	
            return [
                sdData,
                jiraAjax(url, method, JSON.stringify(result))
            ];
        })
            .spread(function (sdData, data) {
            if (_this.isEditMode) {
                _this.issueCreatedKey = _this.currentIssue.key;
                return jiraGet('/rest/api/2/issue/' + _this.currentIssue.id);
            }
            else if (sdData.issueCreated) {
                _this.issueCreatedKey = sdData.issueKey;
                return jiraGet('/rest/api/2/issue/' + sdData.issueId);
            }
            else {
                var issue = JSON.parse(data); //A non-populated issue
                _this.issueCreatedKey = issue.key;
                return jiraGet('/rest/api/2/issue/' + issue.id);
            }
        })
            .then(function (data) {
            var issue = JSON.parse(data);
            issue.fields['project'] = _this.selectedProject;
            lifecycleData.newData = issue;
            //Save Template if created by Email
            if (_this.emailController) {
                _this.emailController.saveSenderTemplate(lifecycleData.data, issue.fields['project']);
            }
            //Check if SD needs to be called
            if (isServiceDesk && !_this.isEditMode)
                return _this.serviceDeskController.doAfterSave(issue).return(lifecycleData);
            return lifecycleData;
        })
            .then(function (lifecycleData) {
            //Wait till all AfterSave actions are done
            return FieldController.raiseEvent(EventType.AfterSave, lifecycleData);
        })
            .then(function () {
            var closeParams = {
                action: 'success',
                changeType: (_this.isEditMode) ? 'updated' : 'created',
                issueKey: _this.issueCreatedKey
            };
            _this.close(closeParams);
        })
            .catch(function (e) {
            $('#JiraSpinner').addClass('hidden');
            var text = 'Unknown';
            if (e instanceof jiraSyncError) {
                text = e.getUserFriendlyError();
            }
            else if (e.message) {
                text = e.message;
            }
            yasoon.util.log('Couldn\'t submit New Issue Dialog: ' + text + ' \n Error: ' + JSON.stringify(e) + ' \n Issue: ' + JSON.stringify(result), yasoon.util.severity.warning, getStackTrace(e));
            console.log(text, e, e.stack);
            if (_this.issueCreatedKey !== null) {
                $('#MainAlert').removeClass('hidden').find('.error-text').html(yasoon.i18n('dialog.errorAfterSubmitIssue', { error: text }));
            }
            else {
                $('#create-issue-submit').prop('disabled', false);
                $('#MainAlert').removeClass('hidden').find('.error-text').html(yasoon.i18n('dialog.errorSubmitIssue', { error: text }));
            }
        });
    };
    NewEditDialog.prototype.renderIssue = function (meta) {
        var _this = this;
        return this.renderIssueUser(meta)
            .catch(function (e) {
            console.log('Error in new renderLogic - switch to old one', e, e.stack);
            return _this.renderIssueFixed(meta);
        })
            .finally(function () {
            return FieldController.raiseEvent(EventType.AfterRender, {});
        });
    };
    NewEditDialog.prototype.renderIssueUser = function (meta) {
        return this.getUserPreferences()
            .then(function (renderData) {
            //First clean up everything
            FieldController.cleanupHtml();
            $('#ContainerFields').empty();
            $('#tab-list').empty();
            //Render each field
            var renderedTabs = {};
            for (var fieldName in renderData.fields) {
                var field = renderData.fields[fieldName];
                if (field.id === FieldController.projectFieldId || field.id === FieldController.issueTypeFieldId)
                    continue;
                //Check if userPrefences allow current field
                if (renderData.userPreferences.useQuickForm && (renderData.userPreferences.fields.indexOf(field.id) === -1 && field.required === false)) {
                    continue;
                }
                //Render tab if nessecary
                var containerId = '#ContainerFields';
                if (renderData.sortedTabs.length > 1) {
                    if (!renderedTabs[field.tab.position]) {
                        $('#tab-list').append('<li role="presentation" class="' + ((field.tab.position === 0) ? 'active' : '') + '"><a href="#tab-content' + field.tab.position + '" role="tab" data-toggle="tab">' + field.tab.label + '</a></li>');
                        $('#ContainerFields').addClass('tab-content');
                        $('#ContainerFields').append('<div role="tabpanel" class="tab-pane" id="tab-content' + field.tab.position + '"></div>');
                        if (field.tab.position === 0) {
                            $('#tab-content' + field.tab.position).addClass('active');
                        }
                        renderedTabs[field.tab.position] = true;
                    }
                    containerId = '#tab-content' + field.tab.position;
                }
                if (meta[field.id]) {
                    FieldController.render(field.id, $(containerId));
                }
            }
            //Tabs nessecary?
            if (Object.keys(renderedTabs).length > 1) {
                $('#tab-list').removeClass('hidden');
            }
            else {
                $('#tab-list').addClass('hidden');
            }
        });
    };
    NewEditDialog.prototype.renderIssueFixed = function (meta) {
        $('#ContainerFields').empty();
        $('#tab-list').empty();
        $('#tab-list').addClass('hidden');
        var addedFields = [];
        //Render Standard Fields on a predefined order if they are in the current meta. (We do not get any order from JIRA, so we assume one for standard fields)
        for (var name_1 in this.fieldOrder) {
            if (meta[name_1]) {
                FieldController.render(name_1, $('#ContainerFields'));
                addedFields.push(name_1);
            }
        }
        //Render remaining fields
        for (var name_2 in Object.keys(meta)) {
            if (addedFields.indexOf(name_2) === -1) {
                FieldController.render(name_2, $('#ContainerFields'));
            }
        }
    };
    NewEditDialog.prototype.getUserPreferences = function () {
        if (this.isEditMode) {
            return this.getUserPreferencesEdit(this.editIssueId);
        }
        else {
            return this.getUserPreferencesNew(this.selectedProject.id, this.selectedIssueType.id);
        }
    };
    NewEditDialog.prototype.getUserPreferencesNew = function (projectId, issueTypeId) {
        var _this = this;
        //Check Cache
        if (this.cacheUserMeta && this.cacheUserMeta[projectId] && this.cacheUserMeta[projectId][issueTypeId]) {
            return Promise.resolve(this.cacheUserMeta[projectId][issueTypeId]);
        }
        return jiraGet('/secure/QuickCreateIssue!default.jspa?decorator=none&pid=' + projectId + '&issuetype=' + issueTypeId)
            .then(function (data) {
            if (!_this.cacheUserMeta[projectId]) {
                _this.cacheUserMeta[projectId] = {};
            }
            _this.cacheUserMeta[projectId][issueTypeId] = JSON.parse(data);
            return _this.cacheUserMeta[projectId][issueTypeId];
        })
            .catch(function (e) {
            console.log('An error occured while getting userPreferences for Create', e, e.stack);
            yasoon.util.log('An error occured while getting userPreferences for Create. ' + e.message, yasoon.util.severity.warning, getStackTrace(e));
        });
    };
    NewEditDialog.prototype.getUserPreferencesEdit = function (editIssueId) {
        return jiraGet('/secure/QuickEditIssue!default.jspa?issueId=' + editIssueId + '&decorator=none')
            .then(function (data) {
            return JSON.parse(data);
        })
            .catch(function (e) {
            console.log('An error occured while getting userPreferences for Edit', e, e.stack);
            yasoon.util.log('An error occured while getting userPreferences for Edit. ' + e.message, yasoon.util.severity.warning, getStackTrace(e));
        });
    };
    NewEditDialog.prototype.getMetaData = function () {
        if (this.isEditMode) {
            return Promise.resolve(this.getEditMetaData());
        }
        else {
            return this.getCreateMetaData(this.selectedProject.id, this.selectedIssueType.id);
        }
    };
    ;
    NewEditDialog.prototype.getEditMetaData = function () {
        if (this.currentIssue && this.currentIssue.editmeta) {
            return this.currentIssue.editmeta.fields;
        }
    };
    NewEditDialog.prototype.getCreateMetaData = function (projectId, issueTypeId) {
        var _this = this;
        //Check in Cache
        //Do not check cache for Teamlead Instance to have latest data every time.
        if (this.cacheCreateMetas && this.cacheCreateMetas.length > 0 && !this.settings.teamlead) {
            var projectMeta = this.cacheCreateMetas.filter(function (m) { return m.id === projectId; })[0];
            if (projectMeta) {
                var issueType = projectMeta.issuetypes.filter(function (it) { return it.id === issueTypeId; })[0];
                if (issueType) {
                    return Promise.resolve(issueType.fields);
                }
            }
        }
        return jiraGet('/rest/api/2/issue/createmeta?projectIds=' + projectId + '&expand=projects.issuetypes.fields')
            .then(function (data) {
            var meta = JSON.parse(data);
            //Find selected project (should be selected by API Call, but I'm not sure if it works due to missing test data )
            var projectMeta = meta.projects.filter(function (p) { return p.id === projectId; })[0];
            if (projectMeta) {
                _this.cacheCreateMetas.push(projectMeta);
                var issueType = projectMeta.issuetypes.filter(function (it) { return it.id === issueTypeId; })[0];
                if (issueType) {
                    return Promise.resolve(issueType.fields);
                }
            }
        });
    };
    NewEditDialog.prototype.loadFields = function () {
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:textfield', SingleTextField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:url', SingleTextField);
        FieldController.register('summary', SingleTextField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:textarea', MultiLineTextField);
        FieldController.register('description', MultiLineTextField, { hasMentions: true, isMainField: true });
        FieldController.register('environment', MultiLineTextField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:multicheckboxes', CheckboxField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:radiobuttons', RadioField);
        FieldController.register('duedate', DateField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:datepicker', DateField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:datetime', DateTimeField);
        FieldController.register('labels', LabelSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:labels', LabelSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:float', NumberField);
        FieldController.register('priority', JiraSelectField);
        FieldController.register('security', JiraSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:select', JiraSelectField);
        FieldController.register('components', JiraSelectField, { multiple: true });
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:multiselect', JiraSelectField, { multiple: true });
        FieldController.register('fixVersions', VersionSelectField, { multiSelect: true, releasedFirst: false });
        FieldController.register('versions', VersionSelectField, { multiSelect: true, releasedFirst: true });
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:multiversion', VersionSelectField, { multiSelect: true, releasedFirst: true });
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:version', VersionSelectField, { multiSelect: false, releasedFirst: true });
        FieldController.register('reporter', UserSelectField);
        FieldController.register('assignee', UserSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:userpicker', UserSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:multiuserpicker', UserSelectField, { multiple: true });
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:cascadingselect', CascadedSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:project', ProjectField, { cache: jira.cacheProjects, allowClear: true });
        FieldController.register('timetracking', TimeTrackingField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:grouppicker', GroupSelectField);
        FieldController.register('com.atlassian.jira.plugin.system.customfieldtypes:multigrouppicker', GroupSelectField, { multiple: true });
        //Software
        FieldController.register('com.pyxis.greenhopper.jira:gh-epic-link', EpicLinkSelectField);
        FieldController.register('com.pyxis.greenhopper.jira:gh-sprint', SprintSelectField);
        FieldController.register('com.pyxis.greenhopper.jira:gh-epic-label', SingleTextField);
        //Service Desk
        FieldController.register('com.atlassian.servicedesk:sd-request-participants', UserSelectField, { multiple: true });
        //https://jira.atlassian.com/browse/JSD-4353
        //https://jira.atlassian.com/browse/JSD-4723
        //FieldController.register('com.atlassian.servicedesk:sd-customer-organizations', OrganizationField);
        //Tempo
        FieldController.register('com.tempoplugin.tempo-accounts:accounts.customfield', TempoAccountField);
        FieldController.register('com.tempoplugin.tempo-teams:team.customfield', TempoTeamField);
        //In Cloud we also have this one?!: com.atlassian.plugins.atlassian-connect-plugin:io.tempo.jira__account
        //Teamlead
        if (this.settings.teamlead && this.settings.teamlead.apiKey) {
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:company-select-field', TeamLeadCompanyField);
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:companies-select-field', TeamLeadCompanyField, { multiple: true });
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:contact-select-field', TeamLeadContactField);
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:contact-field', TeamLeadOldContactField);
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:contacts-field', TeamLeadOldContactField, { multiple: true });
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:single-product-select-field', TeamLeadProductField);
            FieldController.register('ru.teamlead.jira.plugins.teamlead-crm-plugin-for-jira:multi-products-select-field', TeamLeadProductField, { multiple: true });
        }
        //Watcher Field
        FieldController.register('com.burningcode.jira.issue.customfields.impl.jira-watcher-field:watcherfieldtype', UserSelectField, { multiple: true });
        //Intenso Dynamic (currently without Dynamic - just render)
        FieldController.register('com.intenso.jira.plugin.dynamic-forms:dynamic-cascadingselect-customfield', CascadedSelectField);
        FieldController.register('com.intenso.jira.plugin.dynamic-forms:dynamic-check-box-customfield', CheckboxField);
        FieldController.register('com.intenso.jira.plugin.dynamic-forms:dynamic-multiselect-customfield', JiraSelectField, { multiple: true });
        FieldController.register('com.intenso.jira.plugin.dynamic-forms:dynamic-radiobutton-customfield', RadioField);
        FieldController.register('com.intenso.jira.plugin.dynamic-forms:dynamic-select-customfield', JiraSelectField);
        FieldController.register('com.intenso.jira.plugin.dynamic-forms:secured-select', JiraSelectField);
    };
    ;
    return NewEditDialog;
}());
yasoon.dialog.load(new NewEditDialog());
function resizeWindowNew() {
    var bodyHeight = $('body').height();
    if (bodyHeight > 460) {
        $('body').css('overflow-y', 'hidden');
        $(".form-body").height(bodyHeight - 162);
    }
    else {
        $('body').css('overflow-y', 'scroll');
        $(".form-body").height(290);
    }
}
$(function () {
    $('body').css('overflow-y', 'hidden');
    $('form').on('submit', function (e) {
        e.preventDefault();
        return false;
    });
});
$(window).resize(resizeWindowNew);
//@ sourceURL=http://Jira/Dialog/jiraNewEditIssue.js 
