var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Bootbox = (function () {
    function Bootbox() {
    }
    Bootbox.confirm = function (options) {
        return new Promise(function (resolve, reject) {
            var optionsInt = {
                size: 'large',
                backdrop: false,
                message: options.message,
                className: 'jira-modal',
                callback: function (ok) {
                    var checkState = $('#checkboxConfirm').prop("checked");
                    resolve({
                        checkbox: checkState,
                        ok: ok
                    });
                },
                buttons: {
                    cancel: {
                        label: options.secondary,
                        className: "btn-secondary"
                    },
                    confirm: {
                        label: options.primary,
                        className: "btn-primary"
                    },
                }
            };
            if (options.checkbox) {
                optionsInt.checkbox = {
                    id: 'checkboxConfirm',
                    label: options.checkbox
                };
            }
            bootbox.confirm(optionsInt);
        });
    };
    Bootbox.showDialog = function (title, message, init) {
        var dialog = bootbox.dialog({
            title: title,
            message: message
        });
        dialog.init(init);
        return dialog;
    };
    return Bootbox;
}());
/// <reference path="../../definitions/bluebird.d.ts" />
/// <reference path="../../definitions/yasoon.d.ts" />
/// <reference path="../../definitions/common.d.ts" />
/// <reference path="../../definitions/moment.d.ts" />
var EmailController = (function () {
    function EmailController(mail, type, settings, ownUser) {
        var _this = this;
        this.allTemplates = {};
        this.senderTemplates = [];
        this.mail = mail;
        this.attachments = mail.attachments;
        this.settings = settings;
        this.ownUser = ownUser;
        this.type = type;
        //Start Render Markup
        this.renderBodyMarkupPromise = yasoon.outlook.mail.renderBody(mail, 'jiraMarkup')
            .then(function (markup) {
            _this.bodyAsMarkup = markup;
        })
            .catch(function () {
            _this.bodyAsMarkup = yasoon.i18n('general.couldNotRenderMarkup');
        })
            .then(function () {
            return _this.bodyAsMarkup;
        });
        this.bodyPlain = mail.getBody(0).replace(/\r/g, '').replace(/\n\n/g, '\n');
        if (this.type === 'selectedText') {
            this.selectionPlain = this.mail.getSelection(0).replace(/\r/g, '').replace(/\n\n/g, '\n');
            this.renderSelectionMarkupPromise = yasoon.outlook.mail.renderSelection(mail, 'jiraMarkup')
                .then(function (markup) {
                _this.selectionAsMarkup = markup;
            })
                .catch(function () {
                _this.selectionAsMarkup = yasoon.i18n('general.couldNotRenderMarkup');
            })
                .then(function () {
                return _this.selectionAsMarkup;
            });
        }
        //Get Reporter User
        this.loadSenderPromise = jiraGet('/rest/api/2/user/search?username=' + mail.senderEmail)
            .then(function (data) {
            console.log(data);
            var users = JSON.parse(data);
            if (users.length > 0) {
                _this.senderUser = users[0];
                FieldController.raiseEvent(EventType.SenderLoaded, _this.senderUser);
                return _this.senderUser;
            }
        });
        //Get Sender templates            
        var templateString = yasoon.setting.getAppParameter(EmailController.settingCreateTemplates);
        if (templateString) {
            this.allTemplates = JSON.parse(templateString) || {};
            if (this.getSenderEmail())
                this.senderTemplates = this.allTemplates[this.getSenderEmail()] || [];
        }
        FieldController.registerEvent(EventType.AfterSave, this);
        //Load Attachment Handles
        this.getAttachmentFileHandles();
    }
    EmailController.prototype.handleEvent = function (type, newValue, source) {
        if (type === EventType.AfterSave && this.mail) {
            var eventData = newValue;
            try {
                //Set Conversation Data
                var conversationData = this.getConversationData();
                var issue = eventData.newData;
                conversationData.issues[issue.id] = { id: issue.id, key: issue.key, summary: issue.fields['summary'], projectId: issue.fields['project'].id };
                yasoon.outlook.mail.setConversationData(this.mail, JSON.stringify(conversationData)); //jira.mail.setConversationData(JSON.stringify(conversation));
                //Set new message class to switch icon
                if (!this.mail.isSignedOrEncrypted || jira.settings.overwriteEncrypted)
                    this.mail.setMessageClass('IPM.Note.Jira');
            }
            catch (e) {
                //Not so important
                yasoon.util.log('Failed to set Conversation data', yasoon.util.severity.info, getStackTrace(e));
            }
        }
        return null;
    };
    EmailController.prototype.getAttachmentFileHandles = function (uniqueNames) {
        var _this = this;
        //If created by email, check for templates and attachments
        if (this.mail && !this.attachmentHandles) {
            this.attachmentHandles = [];
            //Add current mail to clipboard
            var mailHandle = this.mail.getFileHandle();
            if (this.settings.addEmailOnNewAddIssue) {
                mailHandle.selected = true;
            }
            //Replace some invalid JIRA chars
            var mailFileName = mailHandle.getFileName() || 'no subject.msg';
            mailFileName = mailFileName.replace('&', yasoon.i18n('general.and'));
            mailFileName = mailFileName.replace('+', yasoon.i18n('general.and'));
            mailHandle.setFileName(mailFileName);
            this.attachmentHandles.push(mailHandle);
            if (this.mail.attachments && this.mail.attachments.length > 0) {
                this.mail.attachments.forEach(function (attachment) {
                    var handle = attachment.getFileHandle();
                    handle.attachment = attachment;
                    if (_this.settings.addAttachmentsOnNewAddIssue) {
                        handle.selected = true;
                    }
                    //Provide unique names for attachments
                    if (uniqueNames) {
                        var uniqueKey = getUniqueKey();
                        var oldFileName = handle.getFileName() || 'unknown.file';
                        var newFileName = oldFileName.substring(0, oldFileName.lastIndexOf('.'));
                        newFileName = newFileName + '_' + uniqueKey + oldFileName.substring(oldFileName.lastIndexOf('.'));
                        handle.setFileName(newFileName);
                    }
                    _this.attachmentHandles.push(handle);
                });
            }
        }
        return this.attachmentHandles || [];
    };
    EmailController.prototype.getSubject = function () {
        return this.mail.subject;
    };
    EmailController.prototype.getBody = function (asMarkup) {
        if (asMarkup) {
            return this.renderBodyMarkupPromise;
        }
        else {
            return Promise.resolve(this.bodyPlain);
        }
    };
    EmailController.prototype.getSelection = function (asMarkup) {
        if (asMarkup) {
            return this.renderSelectionMarkupPromise;
        }
        else {
            return Promise.resolve(this.selectionPlain);
        }
    };
    EmailController.prototype.getSenderEmail = function () {
        return this.mail.senderEmail;
    };
    EmailController.prototype.getSenderUser = function () {
        return this.senderUser;
    };
    EmailController.prototype.getSentAt = function () {
        return moment(this.mail.receivedAt);
    };
    EmailController.prototype.getMailHeaderText = function (useMarkup) {
        var result = '';
        if (useMarkup) {
            result = yasoon.i18n('mail.mailHeaderMarkup', {
                senderName: this.mail.senderName,
                senderEmail: this.mail.senderEmail,
                date: moment(this.mail.receivedAt).format('LLL'),
                recipients: ((this.mail.recipients.length > 0) ? '[mailto:' + this.mail.recipients.join('], [mailto:') + ']' : yasoon.i18n('dialog.noRecipient')),
                subject: this.mail.subject
            });
        }
        else {
            result = yasoon.i18n('mail.mailHeaderPlain', {
                senderName: this.mail.senderName,
                senderEmail: this.mail.senderEmail,
                date: moment(this.mail.receivedAt).format('LLL'),
                recipients: ((this.mail.recipients.length > 0) ? this.mail.recipients.join(',') : yasoon.i18n('dialog.noRecipient')),
                subject: this.mail.subject
            });
        }
        //Add Attachments if available 
        var attachments = '';
        this.attachmentHandles.forEach(function (handle) {
            if (handle.attachment && !handle.attachment.isEmbeddedItem) {
                if (useMarkup) {
                    attachments = attachments + ((attachments) ? ', ' : ' ') + '[^' + handle.fileName + ']';
                }
                else {
                    attachments = attachments + ((attachments) ? ', ' : ' ') + handle.fileName;
                }
            }
        });
        if (attachments) {
            var label = yasoon.i18n('mail.attachments');
            if (useMarkup) {
                label = '*' + label + '*';
            }
            result = result + label + ':' + attachments + '\n';
        }
        //Add Final seperator
        result = result + '----\n';
        return result;
    };
    EmailController.prototype.getCurrentMailContent = function (asMarkup) {
        var _this = this;
        var promise = Promise.resolve('');
        if (this.type === 'wholeMail')
            promise = this.getBody(asMarkup);
        else
            promise = this.getSelection(asMarkup);
        return promise
            .then(function (markup) {
            if (jira.settings.addMailHeaderAutomatically === 'top') {
                markup = renderMailHeaderText(_this.mail, true) + '\n' + markup;
            }
            else if (jira.settings.addMailHeaderAutomatically === 'bottom') {
                markup = markup + '\n' + renderMailHeaderText(_this.mail, true);
            }
            return _this.handleAttachments(markup, _this.mail)
                .then(function (newMarkup) {
                if (_this.type === 'selectedText') {
                    _this.selectionAsMarkup = newMarkup;
                }
                else if (_this.type === 'wholeMail') {
                    _this.bodyAsMarkup = newMarkup;
                }
                return newMarkup;
            });
        });
    };
    EmailController.prototype.handleAttachments = function (originalMarkup, mail) {
        var _this = this;
        //Check each attachment if it needs to be embedded
        var embeddedItems = [];
        var markup = originalMarkup;
        this.attachmentHandles.forEach(function (attachment) {
            if (markup.indexOf('!' + attachment.contentId + '!') > -1) {
                embeddedItems.push(attachment);
            }
        });
        if (embeddedItems.length === 0)
            return Promise.resolve(originalMarkup);
        //Ensure they are persisted (performance)
        return new Promise(function (resolve, reject) {
            mail.persistAttachments(embeddedItems, resolve, reject);
        })
            .then(function () {
            return embeddedItems;
        })
            .map(function (handle) {
            return yasoon.io.getFileHash(handle)
                .then(function (hash) {
                handle.hash = hash;
                return hash;
            });
        })
            .then(function (hashes) {
            return yasoon.valueStore.queryAttachmentHashes(hashes)
                .catch(function (e) {
                yasoon.util.log('Could not load Attachment Blacklist', yasoon.util.severity.warning, getStackTrace(e));
                return { foundHashes: [] };
            });
        })
            .then(function (result) {
            embeddedItems.forEach(function (handle) {
                //Skip files whose hashes that were blocked	
                var regEx = new RegExp('!' + handle.contentId + '!', 'g');
                if (result.foundHashes.indexOf(handle.hash) >= 0) {
                    markup = markup.replace(regEx, '');
                    handle.blacklisted = true;
                    return;
                }
                //Replace the reference in the markup	
                handle.selected = true;
                markup = markup.replace(regEx, '!' + handle.getFileName() + '!');
                handle.setInUse();
            });
            FieldController.raiseEvent(EventType.AttachmentChanged, _this.attachmentHandles);
            return markup;
        })
            .catch(function (e) {
            yasoon.util.log('Error during handling of attachments', yasoon.util.severity.warning, getStackTrace(e));
            return markup;
        });
    };
    EmailController.prototype.getConversationData = function () {
        if (!this.mailConversationData) {
            var convData = yasoon.outlook.mail.getConversationData(this.mail);
            if (convData) {
                this.mailConversationData = JSON.parse(convData);
            }
            else {
                this.mailConversationData = {
                    issues: {}
                };
            }
        }
        return this.mailConversationData;
    };
    EmailController.prototype.saveSenderTemplate = function (values, project) {
        if (this.mail) {
            if (!project) {
                console.error('Trying to save a senderTemplate without project');
                return;
            }
            if (this.getSenderEmail()) {
                console.log('No sender email address.'); //Can happen e.g. on drafts
                return;
            }
            var fields = {};
            try {
                //We want the templates to be the same as in the JIRA addon, so we cannot use the values.fields, as they use deep objects. e.g. reporter: { name: 'admin' }
                //We need just reporter: 'admin', so we get all values again from the rendered Fields
                for (var fieldId in values.fields) {
                    if (fieldId != 'summary' && fieldId != 'description' && fieldId != 'duedate' && fieldId != 'project' && fieldId != 'issuetype') {
                        try {
                            fields[fieldId] = FieldController.getField(fieldId).getDomValue();
                        }
                        catch (e) {
                            console.log('Couldnt get field ' + fieldId, e, e.stack);
                        }
                    }
                }
                //Now we would not default email values anymore, so we have to merge the last template with the variables of the selected template
                var templateController = jira.templateController;
                var currentTemplate = templateController.getTemplate(project.id, values.fields['issuetype'].id);
                if (currentTemplate) {
                    for (var fieldId in currentTemplate.fields) {
                        if (templateController.containsVariable(currentTemplate.fields[fieldId])) {
                            fields[fieldId] = currentTemplate.fields[fieldId];
                        }
                    }
                }
                var template_1 = {
                    group: '-1',
                    projectId: project.id,
                    issueTypeId: values.fields['issuetype'].id,
                    templateName: yasoon.i18n('dialog.project') + ': ' + project.name,
                    priority: 4,
                    fields: fields,
                    lastUpdated: new Date().toISOString()
                };
                console.log('SenderTemplate', template_1);
                //Harmonize fields
                /*
                //Service Desk Data
                if (projectCopy.projectTypeKey === 'service_desk') {
                    template.serviceDesk = {
                        enabled: false,
                        requestType: '100'
                    };
                }
                */
                //Add or replace template
                var templateFound_1 = -1;
                this.senderTemplates.forEach(function (templ, index) {
                    if (templ.projectId == template_1.projectId) {
                        templateFound_1 = index;
                    }
                });
                if (templateFound_1 > -1) {
                    this.senderTemplates.splice(templateFound_1, 1);
                }
                this.senderTemplates.push(template_1);
                //Due to the save structure, check if there are too many entries is not so easy.
                //Stucture is: { "senderMail": [ArrayOfTemplates]}
                var counter_1 = 0;
                var senderMail_1 = '';
                var templateIndex_1 = 0;
                var lastUpdated_1 = new Date(2099, 0, 1).toISOString();
                var _loop_1 = function (mail) {
                    var currentTemplates = this_1.allTemplates[mail] || [];
                    currentTemplates.forEach(function (t, index) {
                        counter_1++;
                        if (lastUpdated_1 > t.lastUpdated) {
                            templateIndex_1 = index;
                            lastUpdated_1 = t.lastUpdated;
                            senderMail_1 = mail;
                        }
                    });
                };
                var this_1 = this;
                for (var mail in this.allTemplates) {
                    _loop_1(mail);
                }
                if (counter_1 > EmailController.settingMaxTemplates) {
                    this.allTemplates[senderMail_1].splice(templateIndex_1, 1);
                    if (this.allTemplates[senderMail_1].length === 0) {
                        delete this.allTemplates[senderMail_1];
                    }
                }
                this.allTemplates[this.getSenderEmail().toLowerCase()] = this.senderTemplates;
                var data = JSON.stringify(this.allTemplates);
                yasoon.setting.setAppParameter(EmailController.settingCreateTemplates, data);
            }
            catch (e) {
                //Saving the template should never interrupt saving...
                yasoon.util.log('Error while saving sender template', yasoon.util.severity.warning, getStackTrace(e));
                console.log('Error while saving sender template', e, e.stack);
            }
        }
    };
    return EmailController;
}());
EmailController.settingCreateTemplates = 'createTemplatesNew';
EmailController.settingMaxTemplates = 5;
/// <reference path="../Field.ts" />
var GetArray = (function () {
    function GetArray() {
    }
    GetArray.prototype.getValue = function (field, onlyChangedData) {
        var newValue = field.getDomValue();
        if (!Array.isArray(newValue)) {
            newValue = [newValue];
        }
        //In edit case: Only send changes
        if (onlyChangedData) {
            //Both empty
            if (!field.initialValue && newValue.length === 0)
                return;
            //If length the same and all values match, we do not need to send anything            
            if (field.initialValue && field.initialValue.length === newValue.length) {
                var isSame = field.initialValue.every(function (c) {
                    return newValue.indexOf(c) > -1;
                });
                if (isSame)
                    return;
            }
            return newValue;
        }
        else {
            //In creation case: Only send if not null	
            return (newValue.length > 0) ? newValue : undefined;
        }
    };
    return GetArray;
}());
/// <reference path="../Field.ts" />
/// <reference path="../../../definitions/common.d.ts" />
var GetObject = (function () {
    function GetObject(keyName) {
        this.keyName = keyName;
    }
    GetObject.prototype.getValue = function (field, onlyChangedData) {
        var newValue = field.getDomValue();
        var result = {};
        if (onlyChangedData) {
            //In edit case: Only send if changed	
            //Normalize
            var value = null;
            if (field.initialValue) {
                value = field.initialValue[this.keyName];
            }
            if (!isEqual(value, newValue)) {
                result[this.keyName] = newValue || "-1";
                return result;
            }
        }
        else {
            //In creation case: Only send if not null	
            if (newValue) {
                result[this.keyName] = newValue;
                return result;
            }
        }
    };
    return GetObject;
}());
/// <reference path="../Field.ts" />
/// <reference path="../../../definitions/common.d.ts" />
var GetObjectArray = (function () {
    function GetObjectArray(keyName) {
        this.keyName = keyName;
    }
    GetObjectArray.prototype.getValue = function (field, onlyChangedData) {
        var _this = this;
        var newValue = field.getDomValue();
        //In edit case: Only send changes
        if (onlyChangedData) {
            //Both empty
            if (!field.initialValue && newValue.length === 0)
                return;
            //If length the same and all values match, we do not need to send anything            
            if (field.initialValue && field.initialValue.length === newValue.length) {
                var isSame = field.initialValue.every(function (c) {
                    return findWithAttr(newValue, _this.keyName, c[_this.keyName]) > -1;
                });
                if (isSame)
                    return;
            }
            return newValue;
        }
        else {
            //In creation case: Only send if not null	
            return (newValue.length > 0) ? newValue : undefined;
        }
    };
    return GetObjectArray;
}());
/// <reference path="../Field.ts" />
/// <reference path="../../../definitions/common.d.ts" />
var GetOption = (function () {
    function GetOption(keyName, nullValue) {
        this.nullValue = '-1';
        this.keyName = keyName;
        if (nullValue !== undefined) {
            this.nullValue = nullValue;
        }
    }
    GetOption.prototype.getValue = function (field, onlyChangedData) {
        var _this = this;
        var selectField = field;
        var newValue = selectField.getDomValue();
        if (selectField.multiple) {
            var convertedValues_1 = [];
            newValue.forEach(function (id) {
                var obj = {};
                obj[_this.keyName] = id;
                convertedValues_1.push(obj);
            });
            //Multi Select
            if (onlyChangedData) {
                //Both empty
                if (!field.initialValue && convertedValues_1.length === 0)
                    return;
                //If length the same and all values match, we do not need to send anything            
                if (field.initialValue && field.initialValue.length === convertedValues_1.length) {
                    var isSame = field.initialValue.every(function (c) {
                        return findWithAttr(convertedValues_1, _this.keyName, c[_this.keyName]) > -1;
                    });
                    if (isSame)
                        return;
                }
                return convertedValues_1;
            }
            else {
                //In creation case: Only send if not null	
                return (convertedValues_1.length > 0) ? convertedValues_1 : undefined;
            }
        }
        else {
            //Single Select
            var result = {};
            if (onlyChangedData) {
                //In edit case: Only send if changed	
                //Normalize
                var select2Value = { id: null };
                if (field.initialValue) {
                    select2Value = selectField.convertToSelect2(field.initialValue);
                }
                if (!isEqual(select2Value.id, newValue)) {
                    result[this.keyName] = newValue || this.nullValue;
                    return result;
                }
            }
            else {
                //In creation case: Only send if not null	
                if (newValue) {
                    result[this.keyName] = newValue;
                    return result;
                }
            }
        }
    };
    return GetOption;
}());
/// <reference path="../Field.ts" />
/// <reference path="../../../definitions/common.d.ts" />
var GetTextValue = (function () {
    function GetTextValue() {
    }
    GetTextValue.prototype.getValue = function (field, onlyChangedData) {
        var newValue = field.getDomValue();
        if (onlyChangedData)
            //In edit case: Only send if changed	
            return (isEqual(field.initialValue, newValue)) ? undefined : newValue;
        else
            //In creation case: Only send if not null	
            return (newValue) ? newValue : undefined;
    };
    return GetTextValue;
}());
/// <reference path="../Field.ts" />
var SetCheckedValues = (function () {
    function SetCheckedValues() {
    }
    SetCheckedValues.prototype.setValue = function (field, value) {
        if (value) {
            if (Array.isArray(value)) {
                value.forEach(function (item) {
                    var id = (item && item.id) ? item.id : item;
                    field.ownContainer.find('[value=' + id + ']').prop('checked', true).trigger('change');
                });
            }
            else {
                var id = (value && value.id) ? value.id : value;
                field.ownContainer.find('[value=' + id + ']').prop('checked', true).trigger('change');
            }
        }
        return Promise.resolve(value);
    };
    return SetCheckedValues;
}());
/// <reference path="../Field.ts" />
/// <reference path="../../../definitions/moment.d.ts" />
var SetDateTimeValue = (function () {
    function SetDateTimeValue() {
    }
    SetDateTimeValue.prototype.setValue = function (field, value) {
        if (value) {
            var momentDate = moment(new Date(value));
            $('#' + field.id)["datetimepicker"]('setOptions', { value: momentDate.format('L') + ' ' + momentDate.format('HH:mm') });
            $('#' + field.id).trigger('change');
        }
        return Promise.resolve(value);
    };
    return SetDateTimeValue;
}());
/// <reference path="../Field.ts" />
/// <reference path="../../../definitions/moment.d.ts" />
var SetDateValue = (function () {
    function SetDateValue() {
    }
    SetDateValue.prototype.setValue = function (field, value) {
        if (value) {
            var momentDate = moment(new Date(value));
            $('#' + field.id)["datetimepicker"]('setOptions', { value: momentDate.format('L') });
            $('#' + field.id).trigger('change');
        }
        return Promise.resolve(value);
    };
    return SetDateValue;
}());
/// <reference path="../Field.ts" />
var SetOptionValue = (function () {
    function SetOptionValue() {
    }
    SetOptionValue.prototype.setValue = function (field, value) {
        var _this = this;
        var selectField = field;
        if (!field.isRendered()) {
            //Not rendered, nothing to do... will be called with field.initialValue again
            return;
        }
        if (value && Array.isArray(value)) {
            //Multiselect       
            return Promise.all(value.map(function (v) { return selectField.convertId(v); }))
                .then(function (arrayObj) {
                arrayObj = arrayObj.filter(function (v) { return !!v; });
                if (arrayObj.length === 0)
                    return;
                // Convert value into normalized select2 format
                var select2Values = arrayObj.map(function (v) { return selectField.convertToSelect2(v); });
                //Now there are two cases:
                //All values already exist in data --> we can just select the data
                //Some data do not yet exist --> rerender and select data
                var nonExistingElements = [];
                var selectedValues = [];
                select2Values.forEach(function (v) {
                    if (!_this.findInOptions(selectField.options.data, v.id)) {
                        nonExistingElements.push(v);
                    }
                    selectedValues.push(v.id);
                });
                if (nonExistingElements.length > 0) {
                    var newValues = selectField.options.data.concat(nonExistingElements);
                    selectField.setData(newValues);
                }
                $('#' + field.id).val(selectedValues).trigger('change');
            });
        }
        else if (value) {
            //Single Select
            //Convert value into correct value
            return selectField.convertId(value)
                .then(function (obj) {
                if (!obj)
                    return;
                // Convert value into normalized select2 format
                var select2Value = selectField.convertToSelect2(obj);
                //Now there are two cases:
                //All values already exist in data --> we can just select the data
                //Some data do not yet exist --> rerender and select data
                if (!_this.findInOptions(selectField.options.data, select2Value.id)) {
                    selectField.options.data.push(select2Value);
                    selectField.setData(selectField.options.data, true);
                }
                $('#' + field.id).val(select2Value.id).trigger('change');
            });
        }
    };
    SetOptionValue.prototype.findInOptions = function (inputData, id) {
        var result = inputData.filter(function (data) {
            if (data.children) {
                return (data.children.filter(function (child) { return child.id === id; }).length > 0);
            }
            else {
                return data.id === id;
            }
        });
        return result.length > 0;
    };
    return SetOptionValue;
}());
/// <reference path="../Field.ts" />
var SetTagValue = (function () {
    function SetTagValue() {
    }
    SetTagValue.prototype.setValue = function (field, value) {
        if (value) {
            var selectField_1 = field;
            var tags = void 0;
            if (typeof value === 'string') {
                tags = [value];
            }
            else {
                tags = value;
            }
            tags.forEach(function (label) {
                //Add Option tags so initial selection will work
                if (selectField_1.options.data.filter(function (d) { return d.id === label; }).length === 0) {
                    selectField_1.options.data.push(selectField_1.convertToSelect2(label));
                    $('#' + field.id).append("<option val=\"" + label + "\">" + label + "</option>");
                }
            });
            $('#' + field.id).val(tags).trigger('change');
        }
        return Promise.resolve(value);
    };
    return SetTagValue;
}());
/// <reference path="../Field.ts" />
var SetValue = (function () {
    function SetValue() {
    }
    SetValue.prototype.setValue = function (field, value) {
        $('#' + field.id).val(value).trigger('change');
        return Promise.resolve(value);
    };
    return SetValue;
}());
/// <reference path="../../definitions/jira.d.ts" />
/// <reference path="../../definitions/customSelect2.d.ts" />
/// <reference path="getter/GetArray.ts" />
/// <reference path="getter/GetObject.ts" />
/// <reference path="getter/GetObjectArray.ts" />
/// <reference path="getter/GetOption.ts" />
/// <reference path="getter/GetTextValue.ts" />
/// <reference path="setter/SetCheckedValues.ts" />
/// <reference path="setter/SetDateTimeValue.ts" />
/// <reference path="setter/SetDateValue.ts" />
/// <reference path="setter/SetOptionValue.ts" />
/// <reference path="setter/SetTagValue.ts" />
/// <reference path="setter/SetValue.ts" />
var Field = (function () {
    function Field(id, fieldMeta, params) {
        this.id = id;
        this.fieldMeta = fieldMeta;
        this.originalFieldMeta = jiraCloneObject(fieldMeta);
        this.params = params;
    }
    Field.prototype.getValue = function (onlyChangedData) {
        if (onlyChangedData === void 0) { onlyChangedData = false; }
        if (!getter)
            throw new Error("Please either redefine method getValue or add a @getter Annotation for " + this.id);
        return this.getter.getValue(this, onlyChangedData);
    };
    Field.prototype.setInitialValue = function (value) {
        this.initialValue = value;
    };
    Field.prototype.setValue = function (value) {
        if (!setter)
            throw new Error("Please either redefine method setValue or add a @setter Annotation for " + this.id);
        return this.setter.setValue(this, value);
    };
    Field.prototype.getType = function () {
        return this.fieldMeta.schema.system || this.fieldMeta.schema.custom;
    };
    Field.prototype.triggerValueChange = function () {
        var currentValue = this.getValue(false) || null; //harmonize null / undefined
        if (JSON.stringify(this.lastValue) != JSON.stringify(currentValue)) {
            FieldController.raiseEvent(EventType.FieldChange, currentValue, this.id);
            this.lastValue = currentValue;
        }
    };
    Field.prototype.updateFieldMeta = function (newMeta) {
        this.lastValue = undefined;
        this.fieldMeta = newMeta;
    };
    Field.prototype.setRequired = function (required) {
        var el = $("#" + this.id + "-field-group").find('.field-group');
        this.fieldMeta.required = required;
        if (required) {
            el.addClass('required');
        }
        else {
            el.removeClass('required');
        }
    };
    Field.prototype.setHidden = function (hidden) {
        var el = $("#" + this.id + "-field-group").find('.field-group');
        this.fieldMeta.isHidden = hidden;
        if (hidden) {
            el.addClass('hidden');
        }
        else {
            el.removeClass('hidden');
        }
    };
    Field.prototype.resetMeta = function () {
        this.fieldMeta = jiraCloneObject(this.originalFieldMeta);
        this.setHidden(this.fieldMeta.isHidden);
        this.setRequired(this.fieldMeta.required);
    };
    Field.prototype.renderField = function (container) {
        var _this = this;
        var fieldGroup = container.find('#' + this.id + '-field-group');
        //First render the field-group container for this field if it does not exist yet
        if (fieldGroup.length === 0) {
            fieldGroup = $("<div id=\"" + this.id + "-field-group\" data-field-id=\"" + this.id + "\"></div>").appendTo(container);
        }
        //Render label, mandatory and hidden logic
        var html = "<div class=\"field-group " + ((this.fieldMeta.required) ? 'required' : '') + " " + ((this.fieldMeta.isHidden) ? 'hidden' : '') + "\" >\n\t\t\t\t\t\t<label for=\"" + this.id + "\">" + this.fieldMeta.name + " \n\t\t\t\t\t\t\t<span class=\"aui-icon icon-required\">Required</span>\n\t\t\t\t\t\t</label>\n\t\t\t\t\t\t<div class=\"field-container\">\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t" + ((this.fieldMeta.description) ? '<div class="description">' + this.fieldMeta.description + '</div>' : '') + "\n\t\t\t\t\t</div>";
        this.ownContainer = $(fieldGroup).html(html).find('.field-container');
        //Only inject inner container for easier usage
        var result = this.render(this.ownContainer);
        //If it returns a promise, waitbefore adding event handler
        if (result && result.then) {
            return result.then(function () {
                _this.hookEventHandler();
            });
        }
        else {
            this.hookEventHandler();
            return Promise.resolve();
        }
    };
    Field.prototype.handleError = function (e) {
        console.log('Error during field rendering: ', e, e.message, e.stack);
        yasoon.util.log('Error during field rendering. ' + e.message + ' Field: ' + this.id + ' Meta: ' + JSON.stringify(this.fieldMeta), yasoon.util.severity.error, getStackTrace(e));
        if (this.isRendered()) {
            this.ownContainer.html('<span class="field-error"><i class="fa fa-exclamation-triangle" title="' + yasoon.i18n('dialog.errorFieldRendering') + '"></i></span>');
        }
    };
    Field.prototype.cleanup = function () {
        //Cleanup HTML
        //Default to do nothing... can be overwritten be concrete fields
    };
    Field.prototype.isRendered = function () {
        return (this.ownContainer != null);
    };
    return Field;
}());
var GetterType;
(function (GetterType) {
    GetterType[GetterType["Text"] = 0] = "Text";
    GetterType[GetterType["Object"] = 1] = "Object";
    GetterType[GetterType["ObjectArray"] = 2] = "ObjectArray";
    GetterType[GetterType["Array"] = 3] = "Array";
    GetterType[GetterType["Option"] = 4] = "Option";
})(GetterType || (GetterType = {}));
var SetterType;
(function (SetterType) {
    SetterType[SetterType["Text"] = 0] = "Text";
    SetterType[SetterType["CheckedValues"] = 1] = "CheckedValues";
    SetterType[SetterType["Date"] = 2] = "Date";
    SetterType[SetterType["DateTime"] = 3] = "DateTime";
    SetterType[SetterType["Option"] = 4] = "Option";
    SetterType[SetterType["Tag"] = 5] = "Tag";
})(SetterType || (SetterType = {}));
var EventType;
(function (EventType) {
    EventType[EventType["FieldChange"] = 0] = "FieldChange";
    EventType[EventType["AfterRender"] = 1] = "AfterRender";
    EventType[EventType["AfterSave"] = 2] = "AfterSave";
    EventType[EventType["BeforeSave"] = 3] = "BeforeSave";
    EventType[EventType["SenderLoaded"] = 4] = "SenderLoaded";
    EventType[EventType["UiAction"] = 5] = "UiAction";
    EventType[EventType["Cleanup"] = 6] = "Cleanup";
    EventType[EventType["AttachmentChanged"] = 7] = "AttachmentChanged";
})(EventType || (EventType = {}));
//@getter Annotation
function getter(getterType) {
    var params = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        params[_i - 1] = arguments[_i];
    }
    return function (target) {
        var proto = target.prototype;
        switch (getterType) {
            case GetterType.Text:
                proto.getter = new GetTextValue();
                break;
            case GetterType.Object:
                proto.getter = new GetObject(params[0]);
                break;
            case GetterType.ObjectArray:
                proto.getter = new GetObjectArray(params[0]);
                break;
            case GetterType.Array:
                proto.getter = new GetArray();
                break;
            case GetterType.Option:
                proto.getter = new GetOption(params[0], params[1]);
                break;
        }
    };
}
//@setter Annotation
function setter(setterType) {
    return function (target) {
        var proto = target.prototype;
        switch (setterType) {
            case SetterType.Text:
                proto.setter = new SetValue();
                break;
            case SetterType.CheckedValues:
                proto.setter = new SetCheckedValues();
                break;
            case SetterType.Date:
                proto.setter = new SetDateValue();
                break;
            case SetterType.DateTime:
                proto.setter = new SetDateTimeValue();
                break;
            case SetterType.Option:
                proto.setter = new SetOptionValue();
                break;
            case SetterType.Tag:
                proto.setter = new SetTagValue();
                break;
        }
    };
}
var FieldController;
(function (FieldController) {
    FieldController.projectFieldId = 'project';
    FieldController.issueTypeFieldId = 'issuetype';
    FieldController.issueFieldId = 'parent';
    FieldController.requestTypeFieldId = 'requesttype';
    FieldController.reporterFieldId = 'reporter';
    FieldController.onBehalfOfFieldId = 'onBehalfOf';
    FieldController.attachmentFieldId = 'attachment';
    FieldController.descriptionFieldId = 'description';
    FieldController.priorityFieldId = 'priority';
    // Add-to-Issue
    FieldController.commentFieldId = 'comment';
    var fieldTypes = {};
    var metaFields = {};
    var currentMeta = {};
    //Event --> Fields[]
    var lifecycleHandler = {};
    // Event --> FieldId --> Fields[]
    var fieldEventHandler = {};
    function register(key, newField, params) {
        fieldTypes[key] = { field: newField, params: params };
    }
    FieldController.register = register;
    function getFieldType(field) {
        return field.schema.custom || field.schema.system;
    }
    FieldController.getFieldType = getFieldType;
    function getField(id) {
        var field = metaFields[id];
        if (!field) {
            var fieldKey = Object.keys(metaFields).filter(function (fieldId) { return fieldId.toLowerCase() === id.toLowerCase(); })[0];
            field = metaFields[fieldKey];
        }
        return field;
    }
    FieldController.getField = getField;
    function getAllFields() {
        return metaFields;
    }
    FieldController.getAllFields = getAllFields;
    function enrichFieldMeta(field) {
        var hasChanged = false;
        //Look up in config and set mandatory flag
        //Look up in config and set Hidden field
        //Currently all visible
        field.isHidden = false;
        return hasChanged;
    }
    FieldController.enrichFieldMeta = enrichFieldMeta;
    function getMeta() {
        return currentMeta;
    }
    FieldController.getMeta = getMeta;
    function cleanupHtml() {
        for (var key in metaFields) {
            metaFields[key].cleanup();
        }
    }
    FieldController.cleanupHtml = cleanupHtml;
    function resetFields() {
        for (var key in metaFields) {
            metaFields[key].resetMeta();
        }
    }
    FieldController.resetFields = resetFields;
    function loadMeta(fields) {
        currentMeta = fields;
        //Add/ Update Fields with current meta
        for (var key in fields) {
            var field = fields[key];
            field.key = key; //Is not always set by Jira :/
            var type = getFieldType(field);
            if (type) {
                var buffer = fieldTypes[type];
                if (buffer) {
                    try {
                        loadField(field, buffer.field, buffer.params);
                    }
                    catch (e) {
                        yasoon.util.log("Error loading Field " + key, yasoon.util.severity.error, getStackTrace(e));
                        console.log("Error loading Field " + key, e, e.stack);
                    }
                }
            }
        }
        //Remove fields that are not present in current meta        
        for (var key in metaFields) {
            if (!fields[key]) {
                metaFields[key].cleanup();
                if (metaFields[key]['handleEvent'])
                    unhookEventHandler(metaFields[key]);
                delete metaFields[key];
            }
        }
    }
    FieldController.loadMeta = loadMeta;
    function unhookEventHandler(field) {
        for (var type in lifecycleHandler) {
            var handlerRegistration = lifecycleHandler[type];
            if (handlerRegistration.indexOf(field) > -1) {
                handlerRegistration.splice(handlerRegistration.indexOf(field), 1);
            }
        }
        for (var type in fieldEventHandler) {
            for (var fieldName in fieldEventHandler[type]) {
                var handlerRegistration = fieldEventHandler[type][fieldName];
                if (handlerRegistration.indexOf(field) > -1) {
                    handlerRegistration.splice(handlerRegistration.indexOf(field), 1);
                }
            }
        }
    }
    function loadField(fieldMeta, type, params) {
        enrichFieldMeta(fieldMeta);
        var field = getField(fieldMeta.key);
        if (field) {
            field.updateFieldMeta(fieldMeta);
            return field;
        }
        else {
            var handler = new type(fieldMeta.key, fieldMeta, params);
            metaFields[fieldMeta.key] = handler;
            return handler;
        }
    }
    FieldController.loadField = loadField;
    function render(id, container) {
        var field = getField(id);
        if (field) {
            try {
                return field.renderField(container);
            }
            catch (e) {
                field.handleError(e);
                return Promise.reject(e);
            }
        }
    }
    FieldController.render = render;
    function getValue(id, changedDataOnly) {
        var renderer = getField(id);
        if (renderer) {
            try {
                return renderer.getValue(changedDataOnly);
            }
            catch (e) {
                yasoon.util.log('Error: ' + e.message + '. Couldn\'t getValue for field ' + id, yasoon.util.severity.error);
            }
        }
    }
    FieldController.getValue = getValue;
    function getFormData(changedDataOnly) {
        var result = { fields: {} };
        //Find Meta for current Issue Type
        for (var key in metaFields) {
            var newValue = getValue(key, changedDataOnly);
            if (newValue !== undefined)
                result.fields[key] = newValue;
        }
        return result;
    }
    FieldController.getFormData = getFormData;
    function setValue(id, value, isInitialValue) {
        var field = getField(id);
        var prom;
        if (field) {
            try {
                prom = field.setValue(value);
                if (isInitialValue)
                    field.setInitialValue(value);
            }
            catch (e) {
                console.log('Error setting Field Value', e, e.message, e.stack);
                yasoon.util.log('Error: ' + e.message + '. Couldn\'t setValue for field ' + id, yasoon.util.severity.error, getStackTrace(e));
            }
        }
        if (!prom) {
            prom = Promise.resolve();
        }
        return prom;
    }
    FieldController.setValue = setValue;
    function setFormData(issue) {
        for (var key in metaFields) {
            if (key == FieldController.projectFieldId || key == FieldController.issueTypeFieldId)
                continue;
            setValue(key, issue.fields[key], true);
        }
    }
    FieldController.setFormData = setFormData;
    function raiseEvent(eventType, newValue, id) {
        //Check for Event Type
        var returnPromises = [];
        switch (eventType) {
            case EventType.FieldChange:
                //get Field handler
                var raiseChangeEvent_1 = function (field, evenType, newValue, id) {
                    setTimeout(function (eventType, newValue, id) {
                        try {
                            field.handleEvent(eventType, newValue, id);
                        }
                        catch (e) {
                            yasoon.util.log('Error: ' + e.message + ' in raiseEvent. EventType FieldChange|| newValue ' + newValue + ' || Id: ' + id, yasoon.util.severity.error, getStackTrace(e));
                        }
                    }, 1, eventType, newValue, id);
                };
                if (fieldEventHandler[eventType] && fieldEventHandler[eventType][id]) {
                    fieldEventHandler[eventType][id].forEach(function (field) {
                        raiseChangeEvent_1(field, eventType, newValue, id);
                    });
                }
                if (fieldEventHandler[eventType] && fieldEventHandler[eventType]['*']) {
                    fieldEventHandler[eventType]['*'].forEach(function (field) {
                        raiseChangeEvent_1(field, eventType, newValue, id);
                    });
                }
                break;
            default:
                if (lifecycleHandler[eventType]) {
                    lifecycleHandler[eventType].forEach(function (field) {
                        try {
                            var result = field.handleEvent(eventType, newValue);
                            if (result) {
                                returnPromises.push(result);
                            }
                        }
                        catch (e) {
                            yasoon.util.log('Error: ' + e.message + ' in raiseEvent. EventType ' + eventType + ' || newValue ' + newValue, yasoon.util.severity.error, getStackTrace(e));
                        }
                    });
                }
                break;
        }
        if (returnPromises.length > 0) {
            return Promise.all(returnPromises);
        }
    }
    FieldController.raiseEvent = raiseEvent;
    function registerEvent(eventType, handler, id) {
        switch (eventType) {
            case EventType.FieldChange:
                if (!fieldEventHandler[eventType]) {
                    fieldEventHandler[eventType] = {};
                }
                if (!fieldEventHandler[eventType][id]) {
                    fieldEventHandler[eventType][id] = [];
                }
                fieldEventHandler[eventType][id].unshift(handler);
                break;
            default:
                if (!lifecycleHandler[eventType]) {
                    lifecycleHandler[eventType] = [];
                }
                lifecycleHandler[eventType].unshift(handler);
                break;
        }
    }
    FieldController.registerEvent = registerEvent;
})(FieldController || (FieldController = {}));
//Util Stuff --> New File
function findWithAttr(array, attr, value) {
    for (var i = 0; i < array.length; i += 1) {
        if (array[i][attr] === value) {
            return i;
        }
    }
    return -1;
}
function insertAtCursor(myField, myValue) {
    var startPos = myField.selectionStart;
    var endPos = myField.selectionEnd;
    if (startPos > 0)
        myValue = '\n' + myValue;
    myField.value = myField.value.substring(0, startPos) +
        myValue +
        myField.value.substring(endPos, myField.value.length);
}
function sortByText(a, b) {
    return ((a.text.toLowerCase() > b.text.toLowerCase()) ? 1 : -1);
}
var RecentItemController = (function () {
    function RecentItemController(ownUser) {
        this.numberRecentIssues = 15;
        this.numberRecentUsers = 10;
        this.numberRecentProjects = 5;
        this.recentProjects = [];
        this.recentIssues = [];
        this.recentUsers = [];
        FieldController.registerEvent(EventType.AfterSave, this);
        //Load Recent Projects from DB
        var projectsString = yasoon.setting.getAppParameter(RecentItemController.recentProjectsSetting);
        if (projectsString) {
            this.recentProjects = JSON.parse(projectsString);
        }
        //Load Recent Issues from DB
        var issuesString = yasoon.setting.getAppParameter(RecentItemController.recentIssuesSetting);
        if (issuesString) {
            this.recentIssues = JSON.parse(issuesString);
        }
        //Load Recent Users from DB
        var usersString = yasoon.setting.getAppParameter(RecentItemController.recentUserSetting);
        if (usersString) {
            this.recentUsers = JSON.parse(usersString);
        }
        this.ownUser = ownUser;
    }
    RecentItemController.prototype.handleEvent = function (type, newValue, source) {
        if (type === EventType.AfterSave) {
            var issue = JSON.parse(JSON.stringify(newValue.newData));
            //Add Issue to RecentIssues
            this.addRecentIssue(issue);
            //Add Project to RecentProjects
            if (issue.fields && issue.fields['project']) {
                this.addRecentProject(issue.fields['project']);
            }
        }
        return null;
    };
    RecentItemController.prototype.addRecentProject = function (project) {
        var _this = this;
        setTimeout(function () {
            project = _this.minifyProject(project);
            //First remove old one
            //Second make sure list is not too long.
            //Third Add newProject at first position
            _this.recentProjects = _this.recentProjects.filter(function (i) { return i.id !== project.id; });
            if (_this.recentProjects.length >= _this.numberRecentProjects) {
                _this.recentProjects = _this.recentProjects.slice(1);
            }
            _this.recentProjects.unshift(project);
            yasoon.setting.setAppParameter(RecentItemController.recentProjectsSetting, JSON.stringify(_this.recentProjects));
        });
    };
    RecentItemController.prototype.addRecentIssue = function (issue) {
        var _this = this;
        setTimeout(function () {
            issue = _this.minifyIssue(issue);
            //First remove old one
            //Second make sure list is not too long.
            //Third Add NewIssue at first position
            _this.recentIssues = _this.recentIssues.filter(function (i) { return i.id !== issue.id; });
            if (_this.recentIssues.length >= _this.numberRecentIssues) {
                _this.recentIssues = _this.recentIssues.slice(1);
            }
            _this.recentIssues.unshift(issue);
            yasoon.setting.setAppParameter(RecentItemController.recentIssuesSetting, JSON.stringify(_this.recentIssues));
        });
    };
    RecentItemController.prototype.addRecentUser = function (user) {
        var _this = this;
        if (!user || user.name === '<new>' || user.name === this.ownUser.name)
            return;
        setTimeout(function () {
            user = _this.minifyUser(user);
            //First remove old one
            //Second make sure list is not too long.
            //Third Add newUser at first position
            _this.recentUsers = _this.recentUsers.filter(function (i) { return i.name !== user.name; });
            if (_this.recentUsers.length >= _this.numberRecentUsers) {
                _this.recentUsers = _this.recentUsers.slice(1);
            }
            _this.recentUsers.unshift(user);
            yasoon.setting.setAppParameter(RecentItemController.recentUserSetting, JSON.stringify(_this.recentUsers));
        });
    };
    RecentItemController.prototype.minifyIssue = function (issue) {
        //Only takeover summary and project
        var newIssue = {
            id: issue.id,
            key: issue.key,
            fields: {}
        };
        if (issue.fields && issue.fields['summary']) {
            newIssue.fields['summary'] = issue.fields['summary'];
        }
        if (issue.fields && issue.fields['project']) {
            var project = issue.fields['project'];
            var newProject = {
                id: project.id,
                key: project.key,
                name: project.name,
                projectTypeKey: project.projectTypeKey,
            };
            newIssue.fields['project'] = newProject;
        }
        return newIssue;
    };
    RecentItemController.prototype.minifyProject = function (project) {
        var newProject = {
            id: project.id,
            key: project.key,
            name: project.name,
            projectTypeKey: project.projectTypeKey
        };
        return newProject;
    };
    RecentItemController.prototype.minifyUser = function (user) {
        var newUser = {
            key: user.key,
            name: user.name,
            displayName: user.displayName,
            emailAddress: user.emailAddress,
            locale: user.locale
        };
        return newUser;
    };
    return RecentItemController;
}());
RecentItemController.recentIssuesSetting = 'recentIssues';
RecentItemController.recentProjectsSetting = 'recentProjects';
RecentItemController.recentUserSetting = 'recentUsers';
/// <reference path="../../definitions/bluebird.d.ts" />
/// <reference path="../../definitions/common.d.ts" />
var ServiceDeskController = (function () {
    function ServiceDeskController() {
        this.requestTypes = {};
        this.serviceDeskKeys = {};
        this._isServiceDeskActive = false;
        this.currentRequestTypeMeta = { requestTypeFields: [] };
        FieldController.registerEvent(EventType.FieldChange, this, FieldController.requestTypeFieldId);
        FieldController.registerEvent(EventType.FieldChange, this, FieldController.projectFieldId);
        FieldController.registerEvent(EventType.UiAction, this);
    }
    ServiceDeskController.prototype.isServiceDeskActive = function () {
        return this._isServiceDeskActive;
    };
    ServiceDeskController.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (type === EventType.UiAction) {
            var eventData = newValue;
            if (eventData.name === IssueTypeField.uiActionServiceDesk) {
                this._isServiceDeskActive = eventData.value;
            }
        }
        else if (type === EventType.FieldChange) {
            if (source == FieldController.requestTypeFieldId) {
                this.getRequestTypeMeta(newValue)
                    .then(function (meta) {
                    _this.currentRequestTypeMeta = meta;
                    //We need to put the fields back into original state, without the modifications from the previous request type
                    FieldController.resetFields();
                    //Now process the request type field meta (add possible required flags)
                    _this.updateFieldMeta();
                });
            }
            else if (source === FieldController.projectFieldId) {
                this.currentProject = newValue;
            }
        }
        return null;
    };
    ServiceDeskController.prototype.updateFieldMeta = function () {
        this.currentRequestTypeMeta.requestTypeFields.forEach(function (field) {
            var uiField = FieldController.getField(field.fieldId);
            if (uiField)
                uiField.setRequired(field.required);
        });
    };
    ServiceDeskController.prototype.doBeforeSave = function (data) {
        return __awaiter(this, void 0, void 0, function () {
            var projectId, requestTypeField, onBehalfOfField, postData_1, _a, meta, user, response, responseData;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.isVersionAtLeast('3.3.0')];
                    case 1:
                        if (!_b.sent())
                            return [3 /*break*/, 4];
                        projectId = data.fields[FieldController.projectFieldId].id;
                        requestTypeField = FieldController.getField(FieldController.requestTypeFieldId);
                        onBehalfOfField = FieldController.getField(FieldController.onBehalfOfFieldId);
                        _a = {};
                        return [4 /*yield*/, this.getServiceDeskKey(projectId)];
                    case 2:
                        postData_1 = (_a.serviceDeskId = (_b.sent()).id,
                            _a.requestTypeId = requestTypeField.getDomValue(),
                            _a.requestFieldValues = {},
                            _a);
                        meta = this.currentRequestTypeMeta;
                        if (meta.canRaiseOnBehalfOf) {
                            user = onBehalfOfField.getObjectValue();
                            postData_1.raiseOnBehalfOf = (user.name === '<new>') ? user.emailAddress : user.name;
                        }
                        meta.requestTypeFields.forEach(function (field) {
                            if (!field.required)
                                return;
                            postData_1.requestFieldValues[field.fieldId] = data.fields[field.fieldId];
                        });
                        return [4 /*yield*/, jiraAjax('/rest/servicedeskapi/request', yasoon.ajaxMethod.Post, JSON.stringify(postData_1))];
                    case 3:
                        response = _b.sent();
                        responseData = JSON.parse(response);
                        return [2 /*return*/, {
                                issueCreated: true,
                                issueId: responseData.issueId,
                                issueKey: responseData.issueKey
                            }];
                    case 4:
                        data.fields[FieldController.reporterFieldId] = data.fields[FieldController.onBehalfOfFieldId];
                        _b.label = 5;
                    case 5: return [2 /*return*/, { issueCreated: false }];
                }
            });
        });
    };
    ServiceDeskController.prototype.doAfterSave = function (issue) {
        return __awaiter(this, void 0, void 0, function () {
            var requestTypeOption, requestTypeId;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.isVersionAtLeast('3.3.0')];
                    case 1:
                        if (!(_a.sent())) {
                            try {
                                requestTypeOption = FieldController.getField(FieldController.requestTypeFieldId).getValue(false);
                                requestTypeId = parseInt(requestTypeOption.id);
                                return [2 /*return*/, jiraAjax('/rest/servicedesk/1/servicedesk/request/' + issue.id + '/request-types', yasoon.ajaxMethod.Post, JSON.stringify({ rtId: requestTypeId }))];
                            }
                            catch (e) {
                                return [2 /*return*/, Promise.reject(new Error('Could not create ServiceDesk Data'))];
                            }
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    ServiceDeskController.prototype.getServiceDeskVersion = function () {
        return __awaiter(this, void 0, void 0, function () {
            var data, e_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.serviceDeskVersion)
                            return [2 /*return*/, this.serviceDeskVersion];
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, jiraGet('/rest/servicedeskapi/info')];
                    case 2:
                        data = _a.sent();
                        this.serviceDeskVersion = JSON.parse(data).version;
                        return [3 /*break*/, 4];
                    case 3:
                        e_1 = _a.sent();
                        this.serviceDeskVersion = '3.0.0';
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/, this.serviceDeskVersion];
                }
            });
        });
    };
    ServiceDeskController.prototype.isVersionAtLeast = function (as) {
        return __awaiter(this, void 0, void 0, function () {
            var version, baseVersion, baseNumbers, asNumbers, result, i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getServiceDeskVersion()];
                    case 1:
                        version = _a.sent();
                        baseVersion = version.split('-')[0];
                        baseNumbers = baseVersion.split('.').map(function (n) { return parseInt(n); });
                        asNumbers = as.split('.').map(function (n) { return parseInt(n); });
                        result = true;
                        for (i = 0; i < baseNumbers.length; i++) {
                            if (asNumbers[i] > baseNumbers[i])
                                result = false;
                            else if (asNumbers[i] < baseNumbers[i])
                                break; //we have at least one number which is lower expected => quit now
                        }
                        return [2 /*return*/, result];
                }
            });
        });
    };
    ServiceDeskController.prototype.getRequestTypes = function (serviceDeskKey) {
        return __awaiter(this, void 0, void 0, function () {
            var data, groups, promises_1, types, allTypes_1, data, allTypes;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (this.requestTypes[serviceDeskKey.key]) {
                            return [2 /*return*/, this.requestTypes[serviceDeskKey.key]];
                        }
                        return [4 /*yield*/, this.isVersionAtLeast('3.3.0')];
                    case 1:
                        if (!_a.sent())
                            return [3 /*break*/, 4];
                        return [4 /*yield*/, jiraGet('/rest/servicedesk/1/servicedesk/' + serviceDeskKey.key + '/groups')];
                    case 2:
                        data = _a.sent();
                        groups = JSON.parse(data);
                        promises_1 = [];
                        groups.forEach(function (group) {
                            promises_1.push(jiraGet('/rest/servicedesk/1/servicedesk/' + serviceDeskKey.key + '/groups/' + group.id + '/request-types'));
                        });
                        return [4 /*yield*/, Promise.all(promises_1).map(function (typeString) { return JSON.parse(typeString); })];
                    case 3:
                        types = _a.sent();
                        allTypes_1 = [];
                        types.forEach(function (typesInner) {
                            typesInner.forEach(function (type) {
                                //Do not add twice
                                if (allTypes_1.filter(function (t) { return t.id === type.id; }).length === 0) {
                                    allTypes_1.push(type);
                                }
                            });
                        });
                        this.requestTypes[serviceDeskKey.key] = allTypes_1;
                        return [2 /*return*/, allTypes_1];
                    case 4: return [4 /*yield*/, jiraGet('/rest/servicedesk/1/servicedesk/' + serviceDeskKey.key + '/request-types')];
                    case 5:
                        data = _a.sent();
                        allTypes = JSON.parse(data);
                        this.requestTypes[serviceDeskKey.key] = allTypes;
                        return [2 /*return*/, allTypes];
                }
            });
        });
    };
    ServiceDeskController.prototype.getRequestTypeMeta = function (requestType) {
        return __awaiter(this, void 0, void 0, function () {
            var data, e_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.isVersionAtLeast('3.3.0')];
                    case 1:
                        if (!_a.sent())
                            return [3 /*break*/, 5];
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 4, , 5]);
                        return [4 /*yield*/, jiraGet("/rest/servicedeskapi/servicedesk/" + requestType.portalId + "/requesttype/" + requestType.id + "/field")];
                    case 3:
                        data = _a.sent();
                        return [2 /*return*/, JSON.parse(data)];
                    case 4:
                        e_2 = _a.sent();
                        console.log(e_2);
                        yasoon.util.log(e_2.toString(), yasoon.util.severity.warning);
                        return [2 /*return*/, { requestTypeFields: [] }];
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    ServiceDeskController.prototype.getServiceDeskKey = function (projectId, projectKey) {
        return __awaiter(this, void 0, void 0, function () {
            var data, serviceData, serviceDeskKey, e_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        //Return buffer
                        if (this.serviceDeskKeys[projectId]) {
                            return [2 /*return*/, Promise.resolve(this.serviceDeskKeys[projectId])];
                        }
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, jiraGet('/rest/servicedesk/1/servicedesk-data')];
                    case 2:
                        data = _a.sent();
                        serviceData = JSON.parse(data);
                        if (serviceData.length > 0) {
                            serviceDeskKey = serviceData.filter(function (s) { return s.projectId == projectId; })[0];
                            this.serviceDeskKeys[projectId] = { id: serviceDeskKey.id, key: serviceDeskKey.key };
                        }
                        else {
                            this.serviceDeskKeys[projectId] = { id: projectId, key: projectKey.toLowerCase() };
                        }
                        return [3 /*break*/, 4];
                    case 3:
                        e_3 = _a.sent();
                        console.log(e_3);
                        yasoon.util.log(e_3.toString(), yasoon.util.severity.warning);
                        this.serviceDeskKeys[projectId] = { id: projectId, key: projectKey.toLowerCase() };
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/, this.serviceDeskKeys[projectId]];
                }
            });
        });
    };
    ServiceDeskController.prototype.getCurrentServiceDeskKey = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (this.currentProject.projectTypeKey === 'service_desk')
                    return [2 /*return*/, this.getServiceDeskKey(this.currentProject.id)];
                return [2 /*return*/, Promise.resolve(null)];
            });
        });
    };
    return ServiceDeskController;
}());
/// <reference path="../../definitions/moment.d.ts" />
var TemplateController = (function () {
    function TemplateController(ownUser, emailController, type) {
        var _this = this;
        this.groupHierachy = [];
        this.dependentFields = {};
        this.defaultTemplates = [];
        this.emailContent = '';
        this.ownUser = ownUser;
        this.emailController = emailController;
        this.type = type;
        //Load Data
        var groupsString = '';
        var initialDataString = '';
        var defaultTemplatesString = '';
        var oauthService = yasoon.app.getOAuthService(jira.settings.currentService);
        var instanceDataString = '';
        var initialSelection = [];
        if (oauthService && oauthService.appParams && oauthService.appParams['jiraDataId']) {
            instanceDataString = yasoon.setting.getAppParameter(oauthService.appParams['jiraDataId']);
        }
        if (instanceDataString) {
            var data = JSON.parse(instanceDataString);
            this.groupHierachy = data[TemplateController.settingGroupHierarchy] || [];
            initialSelection = data[TemplateController.settingInitialSelection] || [];
            this.defaultTemplates = data[TemplateController.settingDefaultTemplates] || [];
        }
        else {
            //Load non-instance settings
            groupsString = yasoon.setting.getAppParameter(TemplateController.settingGroupHierarchy);
            if (!groupsString)
                groupsString = '[]';
            initialDataString = yasoon.setting.getAppParameter(TemplateController.settingInitialSelection);
            if (!initialDataString)
                initialDataString = '[]';
            defaultTemplatesString = yasoon.setting.getAppParameter(TemplateController.settingDefaultTemplates);
            if (!defaultTemplatesString)
                defaultTemplatesString = '[]';
            this.groupHierachy = JSON.parse(groupsString);
            initialSelection = JSON.parse(initialDataString);
            this.defaultTemplates = JSON.parse(defaultTemplatesString);
        }
        //Filter for current Data 
        //Only keep groups that are assigned to current user
        this.groupHierachy = this.groupHierachy.filter(function (group) {
            return _this.ownUser.groups.items.filter(function (userGroup) {
                return userGroup.name === group.name;
            }).length > 0;
        });
        //Only keep initial Selections necessary for current user
        //--> Sort by Group Hierarchy and pick the highest
        if (initialSelection.length > 0) {
            initialSelection = initialSelection.filter(function (selection) {
                return _this.ownUser.groups.items.filter(function (userGroup) {
                    return userGroup.name === selection.group;
                }).length > 0;
            });
            this.initialSelection = initialSelection.sort(function (a, b) {
                var groupA = _this.getGroup(a.group);
                var groupB = _this.getGroup(b.group);
                var posA = (groupA) ? groupA.position : 10000;
                var posB = (groupB) ? groupB.position : 10000;
                return posA - posB;
            })[0];
        }
        //Only keep defaultTemplates for groups of current user
        this.defaultTemplates = this.defaultTemplates.filter(function (defaultTemplate) {
            return defaultTemplate.group === '-1' || _this.getGroup(defaultTemplate.group) != null;
        });
        //Sort Asc by priority
        this.defaultTemplates = this.defaultTemplates.sort(function (a, b) { return a.priority - b.priority; });
        FieldController.registerEvent(EventType.AfterRender, this);
    }
    TemplateController.prototype.handleEvent = function (type, newValue, source) {
        if (type === EventType.FieldChange) {
            var dependentFieldIds = this.dependentFields[source] || [];
            dependentFieldIds.forEach(function (dependentFieldId) {
                var dependentField = FieldController.getField(dependentFieldId);
                var currentValue = dependentField.getValue(false);
                if (!currentValue && !dependentField.initialValue)
                    return;
                if (!currentValue || !dependentField.initialValue || JSON.stringify(currentValue) == JSON.stringify(dependentField.initialValue)) {
                    FieldController.setValue(dependentField.id, newValue, true);
                }
            });
        }
        else if (type === EventType.AfterRender) {
            this.cleanupEvents();
        }
        return null;
    };
    TemplateController.prototype.applyTemplate = function (projectId, issueTypeId) {
        //We first check if we have a pending template
        if (this.dialogSelectedTemplate && this.dialogSelectedTemplate.projectId == projectId && this.dialogSelectedTemplate.issueTypeId == issueTypeId) {
            this.setFieldValues(this.dialogSelectedTemplate);
            this.dialogSelectedTemplate = null;
        }
        else {
            var template = this.getTemplate(projectId, issueTypeId);
            if (template)
                this.setFieldValues(template);
        }
    };
    TemplateController.prototype.setInitialValues = function (initialValues) {
        if (!initialValues) {
            initialValues = this.initialSelection;
        }
        var projPromise = Promise.resolve();
        var issueTypePromise = Promise.resolve();
        var renderRequired = false;
        if (initialValues) {
            //Only set values if it has changed
            var projectField = FieldController.getField(FieldController.projectFieldId);
            if (initialValues.projectId && projectField.getDomValue() != initialValues.projectId) {
                projPromise = FieldController.setValue(FieldController.projectFieldId, initialValues.projectId, true);
                renderRequired = true;
            }
            var issueTypeField = FieldController.getField(FieldController.issueTypeFieldId);
            if (initialValues.issueTypeId != '-1' && issueTypeField.getDomValue() != initialValues.issueTypeId) {
                issueTypePromise = FieldController.setValue(FieldController.issueTypeFieldId, initialValues.issueTypeId, true);
                renderRequired = true;
            }
        }
        return Promise.all([renderRequired, projPromise, issueTypePromise]);
    };
    TemplateController.prototype.setFieldValues = function (template) {
        var _this = this;
        var promise = Promise.resolve([]);
        //Make sure emailData are loaded
        if (this.emailController) {
            promise = Promise.all([this.emailController.getCurrentMailContent(true), this.emailController.loadSenderPromise]);
        }
        promise.spread(function (content) {
            _this.emailContent = content;
            if (template && template.fields) {
                for (var fieldId in template.fields) {
                    if (template.fields.hasOwnProperty(fieldId)) {
                        var value = template.fields[fieldId];
                        var renderedField = FieldController.getField(fieldId);
                        if (renderedField) {
                            if (typeof value === 'string' && _this.containsVariable(value)) {
                                //Fixed variables
                                value = _this.getFixedValue(value, renderedField.constructor['name']);
                            }
                            else if (typeof value === 'string' && value.indexOf('|') === 0) {
                                value = _this.getDynamicValue(fieldId, value);
                            }
                            else {
                                value = value;
                            }
                            if (value) {
                                FieldController.setValue(fieldId, value, true);
                            }
                        }
                    }
                }
            }
        })
            .catch(function (e) {
            console.log('setFieldValue Error', e, e.stack);
        });
    };
    TemplateController.prototype.getTemplate = function (projectId, issueTypeId) {
        var result = null;
        if (this.defaultTemplates) {
            this.defaultTemplates.some(function (template) {
                //Check if Project and issueType matches
                if ((template.projectId === '-1' || template.projectId === projectId) &&
                    (template.issueTypeId === '-1' || template.issueTypeId === issueTypeId)) {
                    result = template;
                    return true;
                }
                return false;
            });
        }
        return result;
    };
    TemplateController.prototype.showTemplateSelection = function () {
        var _this = this;
        var namedTemplates = this.defaultTemplates.filter(function (t) { return t.templateName; });
        var senderTemplates = [];
        if (this.emailController) {
            senderTemplates = this.emailController.senderTemplates;
        }
        if (!this.loadTemplateSelectionPromise) {
            this.loadTemplateSelectionPromise = Promise.resolve($.getScript(yasoon.io.getLinkPath('templates/selectTemplateDialog.js')))
                .then(function () {
                return jira.templates.selectTemplateDialog({
                    senderMail: _this.emailController.getSenderEmail(),
                    senderTemplates: senderTemplates,
                    namedTemplates: namedTemplates
                });
            });
        }
        this.loadTemplateSelectionPromise.then(function (tmpl) {
            var dialog = Bootbox.showDialog('Select Template', tmpl, function () {
                $('.trigger-named-template').click(function (e) {
                    var templateName = $(e.target).text();
                    _this.dialogSelectedTemplate = namedTemplates.filter(function (t) { return t.templateName === templateName; })[0];
                    //First select Initial Values
                    _this.setInitialValues({ projectId: _this.dialogSelectedTemplate.projectId, issueTypeId: _this.dialogSelectedTemplate.issueTypeId })
                        .spread(function (renderRequired) {
                        if (!renderRequired) {
                            _this.setFieldValues(_this.dialogSelectedTemplate);
                            _this.dialogSelectedTemplate = null;
                        }
                        dialog.modal('hide');
                    });
                });
                $('.trigger-sender-template').click(function (e) {
                    var projectId = $(e.currentTarget).data('projectId');
                    _this.dialogSelectedTemplate = senderTemplates.filter(function (t) { return t.projectId == projectId; })[0];
                    if (_this.dialogSelectedTemplate) {
                        //First select Initial Values
                        _this.setInitialValues({ projectId: _this.dialogSelectedTemplate.projectId, issueTypeId: _this.dialogSelectedTemplate.issueTypeId })
                            .spread(function (renderRequired) {
                            if (!renderRequired) {
                                _this.setFieldValues(_this.dialogSelectedTemplate);
                                _this.dialogSelectedTemplate = null;
                            }
                            dialog.modal('hide');
                        });
                    }
                });
            });
        });
    };
    TemplateController.prototype.containsVariable = function (value) {
        return (value.indexOf && value.indexOf('<') === 0 && value.indexOf('>') > 0);
    };
    TemplateController.prototype.getFixedValue = function (value, fieldType) {
        if (value === '<TODAY>') {
            return moment(new Date()).format('YYYY-MM-DD');
        }
        else if (value.indexOf('<TODAY>') === 0) {
            try {
                //Replace all non numeric chars
                var numOfDays = parseInt(value.replace(/\D/g, ''));
                var currentDate = new Date();
                currentDate.setDate(currentDate.getDate() + numOfDays);
                return moment(currentDate).format('YYYY-MM-DD');
            }
            catch (e) {
            }
        }
        else if (value === '<USER>') {
            return this.ownUser.name || this.ownUser.key;
        }
        else if (value === '<SUBJECT>') {
            return this.emailController.getSubject();
        }
        else if (value === '<BODY>') {
            return this.emailContent;
        }
        else if (value === '<SENDER>') {
            //Special Handling for User Picker
            if (fieldType === 'UserSelectField') {
                return this.emailController.getSenderUser();
            }
            else {
                return this.emailController.getSenderEmail();
            }
        }
        else if (value === '<SENTAT>') {
            return moment(this.emailController.getSentAt()).format('YYYY-MM-DD hh:mm:ss');
        }
    };
    TemplateController.prototype.getDynamicValue = function (fieldId, value) {
        var parentFieldId = value.replace(/\|/g, '').toLowerCase();
        var parentField = FieldController.getField(parentFieldId);
        if (parentField) {
            if (!this.dependentFields[parentField.id]) {
                this.dependentFields[parentField.id] = [];
            }
            this.dependentFields[parentField.id].push(fieldId);
            FieldController.registerEvent(EventType.FieldChange, this, parentField.id);
            return parentField.getValue(false);
        }
    };
    TemplateController.prototype.getGroup = function (group) {
        if (group === '-1') {
            return {
                name: 'Default',
                position: 1000
            };
        }
        else {
            return this.groupHierachy.filter(function (userGroup) {
                return userGroup.name === group;
            })[0];
        }
    };
    TemplateController.prototype.cleanupEvents = function () {
        //FieldController Events will be unloaded automatically whenever a new meta is loaded
        //just reinitialize dependedFields
        this.dependentFields = {};
    };
    return TemplateController;
}());
TemplateController.settingGroupHierarchy = 'groups';
TemplateController.settingInitialSelection = 'initialSelection';
TemplateController.settingDefaultTemplates = 'defaultTemplates';
/// <reference path="../Field.ts" />
/// <reference path="../FieldController.ts" />
/// <reference path="../../../definitions/handlebars.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../Bootbox.ts" />
var AttachmentField = (function (_super) {
    __extends(AttachmentField, _super);
    function AttachmentField(id, fieldMeta, attachments) {
        var _this = _super.call(this, id, fieldMeta) || this;
        _this.deactivatePreview = false;
        _this.getTemplate = null;
        _this.currentParameters = null;
        _this.attachments = [];
        _this.descriptionField = null;
        _this.attachments = attachments || [];
        _this.getTemplate = Promise.all([
            $.getScript(yasoon.io.getLinkPath('templates/attachmentFieldsNew.js')),
            $.getScript(yasoon.io.getLinkPath('templates/attachmentLink.js')),
        ])
            .spread(function () {
            Handlebars.registerPartial("attachmentLink", jira.templates.attachmentLink);
            return jira.templates.attachmentFieldsNew;
        });
        FieldController.registerEvent(EventType.AfterSave, _this);
        FieldController.registerEvent(EventType.AttachmentChanged, _this);
        FieldController.registerEvent(EventType.Cleanup, _this);
        return _this;
    }
    AttachmentField.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (type === EventType.AfterSave) {
            var lifecycleData = newValue;
            var formData_1 = [];
            this.attachments.forEach(function (file) {
                if (file.selected) {
                    formData_1.push({
                        type: yasoon.formData.File,
                        name: 'file',
                        value: file
                    });
                }
            });
            this.deactivatePreview = true;
            if (formData_1.length > 0) {
                return jiraAjax('/rest/api/2/issue/' + lifecycleData.newData.id + '/attachments', yasoon.ajaxMethod.Post, null, formData_1);
            }
        }
        else if (type === EventType.Cleanup) {
            //Dispose all Attachments
            this.attachments.forEach(function (handle) {
                try {
                    handle.dispose();
                }
                catch (e) {
                }
            });
        }
        else if (type === EventType.AttachmentChanged) {
            if (newValue)
                this.attachments = newValue;
            this.render(this.ownContainer)
                .then(function () {
                _this.hookEventHandler();
            });
        }
    };
    AttachmentField.prototype.getDomValue = function () {
        return '';
    };
    AttachmentField.prototype.getValue = function () {
        //Nessecary as attachments will upload differently
        return undefined;
    };
    AttachmentField.prototype.setValue = function () {
        //Attachments work differently
        return Promise.resolve();
    };
    AttachmentField.prototype.getSelectedAttachments = function () {
        return this.attachments.filter(function (a) { return a.selected; });
    };
    AttachmentField.prototype.getCurrentAttachment = function (elem) {
        var handleId = $(elem).closest('.jiraAttachmentLink').data('id');
        return this.attachments.filter(function (item) { return item.id === handleId; })[0];
    };
    AttachmentField.prototype.submitRename = function (elem) {
        var domAttachmentLink = elem.closest('.jiraAttachmentLink');
        var handle = this.getCurrentAttachment(elem);
        var newName = domAttachmentLink.find('.attachmentNewName input').val().trim() + handle.extension;
        var oldName = handle.fileName;
        if (handle.fileName != newName) {
            domAttachmentLink.find('.attachmentNameValue').text(newName);
            handle.setFileName(newName);
            handle.fileName = newName;
            handle.fileNameNoExtension = newName.substring(0, newName.lastIndexOf('.'));
            var eventData = {
                name: AttachmentField.uiActionRename,
                value: {
                    oldName: oldName,
                    newName: newName
                }
            };
            FieldController.raiseEvent(EventType.UiAction, eventData);
        }
        domAttachmentLink.find('.attachmentMain').removeClass('edit');
    };
    AttachmentField.prototype.raiseHandleChangedEvent = function (handle) {
        var eventData = {
            name: AttachmentField.uiActionSelect,
            value: handle
        };
        FieldController.raiseEvent(EventType.UiAction, eventData);
    };
    AttachmentField.prototype.hookEventHandler = function () {
        var _this = this;
        //Blacklist Events
        if (this.currentParameters.blacklistedAttachments.length > 0) {
            $(this.ownContainer).find('.show-blacklisted-attachments').removeClass('hidden');
            $(this.ownContainer).find('.show-blacklisted-attachments').off().click(function (e) {
                e.preventDefault();
                $(_this.ownContainer).find('.attachments-blacklisted').removeClass('hidden');
                $(_this.ownContainer).find('.hide-blacklisted-attachments').removeClass('hidden');
                $(e.target).addClass('hidden');
            });
            $(this.ownContainer).find('.hide-blacklisted-attachments').off().click(function (e) {
                e.preventDefault();
                $(_this.ownContainer).find('.attachments-blacklisted').addClass('hidden');
                $(_this.ownContainer).find('.show-blacklisted-attachments').removeClass('hidden');
                $(e.target).addClass('hidden');
            });
        }
        $(this.ownContainer).find('.addAttachmentLink').off().click(function (e) {
            e.preventDefault();
            yasoon.view.fileChooser.open(function (selectedFiles) {
                selectedFiles.forEach(function (handle) {
                    handle.selected = true;
                });
                var attachments = _this.attachments.concat(selectedFiles);
                //Rerender
                FieldController.raiseEvent(EventType.AttachmentChanged, attachments);
            });
        });
        $('.jiraAttachmentLink .checkbox input').off().on('change', function (e) {
            var handle = _this.getCurrentAttachment($(e.target));
            handle.selected = !handle.selected;
            _this.raiseHandleChangedEvent(handle);
        });
        $('.attachmentAddRef').off().click(function (e) {
            e.preventDefault();
            var handle = _this.getCurrentAttachment($(e.target));
            //Select attachment to be uploaded
            handle.selected = true;
            $(e.target).closest('.jiraAttachmentLink').find('.checkbox input').prop('checked', true);
            //Notify description
            FieldController.raiseEvent(EventType.UiAction, { name: AttachmentField.uiActionAddRef, value: handle });
        });
        $('.attachmentAddToBlacklist').off().click(function (e) {
            e.preventDefault();
            var handle = _this.getCurrentAttachment($(e.target));
            var hideInfo = yasoon.setting.getAppParameter('dialog.hideAttachmentBlacklistExplanation');
            var showInfoDialog;
            if (hideInfo && hideInfo === 'true') {
                showInfoDialog = Promise.resolve({ ok: true }); //Skip
            }
            else {
                showInfoDialog = Bootbox.confirm({
                    message: yasoon.i18n('dialog.attachmentAddToBlacklistDialog'),
                    checkbox: yasoon.i18n('dialog.dontShowAgain'),
                    primary: yasoon.i18n('dialog.ok'),
                    secondary: yasoon.i18n('dialog.cancel')
                });
            }
            showInfoDialog.then(function (result) {
                if (result.ok) {
                    //First, set as blacklisted
                    yasoon.io.getFileHash(handle).then(function (hash) {
                        return yasoon.valueStore.putAttachmentHash(hash);
                    });
                    //Now, update UI
                    handle.blacklisted = true;
                    handle.selected = false;
                    //rerender
                    FieldController.raiseEvent(EventType.AttachmentChanged);
                    //Now remove all references from the description field
                    _this.raiseHandleChangedEvent(handle);
                    //Only accept dont ask again if was confirmed with ok					
                    if (result.checkbox) {
                        yasoon.setting.setAppParameter('dialog.hideAttachmentBlacklistExplanation', 'true');
                    }
                }
            });
        });
        $('.attachmentRename').off().click(function (e) {
            e.preventDefault();
            $(e.target).closest('.attachmentMain').addClass('edit');
        });
        $('.attachmentRenameConfirm').off().click(function (e) {
            e.preventDefault();
            _this.submitRename($(e.target));
        });
        $('.attachmentRenameCancel').click(function (e) {
            e.preventDefault();
            var domAttachmentLink = $(e.target).closest('.jiraAttachmentLink');
            domAttachmentLink.find('.attachmentMain').removeClass('edit');
            var handle = _this.getCurrentAttachment($(e.target));
            domAttachmentLink.find('.attachmentNewName input').val(handle.fileNameNoExtension);
        });
        $('.attachmentNameValue').off().on('mouseenter', function (e) {
            var elem = $(e.target);
            var domAttachmentLink = elem.closest('.jiraAttachmentLink');
            var handle = _this.getCurrentAttachment(elem);
            if (_this.deactivatePreview === false && handle.hasFilePreview()) {
                var timeoutFct = setTimeout(function () {
                    yasoon.io.getFilePreviewPath(handle)
                        .then(function (path) {
                        $('.thumbnail-preview').remove();
                        $('body').append('<img class="thumbnail-preview" src="' + path + '" style="z-index: 100000; cursor: pointer; background-color: white; position: absolute; left: ' + (e.originalEvent['x'] - 50) + 'px; top: ' + (e.originalEvent['y'] - 30) + 'px" />')
                            .find('.thumbnail-preview')
                            .on('mouseleave', function () {
                            $(this).unbind().remove();
                        });
                    });
                }, 500);
                $('.attachmentNameValue').on('mouseleave', function (e) {
                    clearTimeout(timeoutFct);
                });
            }
        });
        $('.attachmentNewName input').off().on('keyup', function (e) {
            e.preventDefault();
            if (e.keyCode == 13) {
                _this.submitRename($(e.target));
            }
            return false;
        });
    };
    AttachmentField.prototype.render = function (container) {
        var _this = this;
        if (!this.attachments)
            return;
        return this.getTemplate
            .then(function (template) {
            _this.attachments.forEach(function (attachment) {
                //Rename FileName if it contains unsupported characters
                var oldFileName = attachment.getFileName() || 'unknown.file';
                var newFileName = oldFileName.replace(/\[/g, '(').replace(/\]/g, ')').replace(/\^/g, '_');
                if (oldFileName != newFileName)
                    attachment.setFileName(newFileName);
                //Set Fields for template
                attachment.fileName = newFileName;
                attachment.extension = newFileName.substring(newFileName.lastIndexOf('.'));
                attachment.fileIcon = attachment.getFileIconPath(true);
                attachment.fileNameNoExtension = newFileName.substring(0, newFileName.lastIndexOf('.'));
            });
            _this.currentParameters = {
                id: _this.id,
                attachments: _this.attachments.filter(function (val) { return !val.blacklisted; }) || [],
                blacklistedAttachments: _this.attachments.filter(function (val) { return val.blacklisted; }) || []
            };
            $(container).html(template(_this.currentParameters));
        })
            .catch(function (e) { _this.handleError(e); });
    };
    ;
    return AttachmentField;
}(Field));
AttachmentField.defaultMeta = { key: FieldController.attachmentFieldId, get name() { return yasoon.i18n('dialog.attachment'); }, required: false, schema: { system: 'attachment', type: '' } };
AttachmentField.uiActionRename = 'renameAttachment';
AttachmentField.uiActionSelect = 'selectAttachment';
AttachmentField.uiActionAddRef = 'addRefAttachment';
/// <reference path="../Field.ts" />
var Select2Field = (function (_super) {
    __extends(Select2Field, _super);
    function Select2Field(id, field, options, multiple, style) {
        if (multiple === void 0) { multiple = false; }
        if (style === void 0) { style = "min-width: 350px; width: 80%;"; }
        var _this = _super.call(this, id, field) || this;
        _this.options = $.extend({ data: [], minimumInputLength: 0, allowClear: true, templateResult: Select2Field.formatIcon, templateSelection: Select2Field.formatIcon }, options);
        _this.styleCss = style;
        _this.multiple = multiple;
        //https://github.com/select2/select2/issues/3497
        //AllowClear needs placeholder
        if (_this.options.allowClear && !_this.options.placeholder) {
            _this.options.placeholder = '';
        }
        return _this;
    }
    Select2Field.prototype.getDomValue = function () {
        return $('#' + this.id).val();
    };
    Select2Field.prototype.getObjectValue = function () {
        var elements = $('#' + this.id)['select2']('data');
        if (elements.length > 0) {
            if (this.multiple) {
                return elements.map(function (p) { return p.data; });
            }
            else {
                return elements[0].data;
            }
        }
    };
    Select2Field.prototype.setData = function (newValues, fromSetValue) {
        if (fromSetValue === void 0) { fromSetValue = false; }
        this.options.data = newValues;
        if (this.isRendered()) {
            //Get selected Properties
            var isDisabled = $('#' + this.id).prop('disabled');
            $('#' + this.id)["select2"]("destroy");
            this.ownContainer.html('');
            this.render(this.ownContainer);
            //Set saved Properties
            $('#' + this.id).prop('disabled', isDisabled);
            this.hookEventHandler();
            //If intial value has been set, we need to set it again now.
            if (this.initialValue && !fromSetValue) {
                this.setValue(this.initialValue);
            }
        }
    };
    Select2Field.prototype.hookEventHandler = function () {
        var _this = this;
        $('#' + this.id).on('change', function (e) { return _this.triggerValueChange(); });
    };
    Select2Field.prototype.render = function (container) {
        container.append($("<select class=\"select input-field\" id=\"" + this.id + "\" name=\"" + this.id + "\" style=\"" + this.styleCss + "\" " + ((this.multiple) ? 'multiple' : '') + ">\n\t\t\t\t\t\t\t" + ((!this.multiple) ? '<option></option>' : '') + "\n\t\t\t\t\t\t\t</select>\n\t\t\t\t\t\t\t<img src=\"images/ajax-loader.gif\" class=\"hidden\" id=\"" + this.id + "-spinner\" />"));
        $('#' + this.id)["select2"](this.options);
    };
    Select2Field.prototype.triggerValueChange = function () {
        var _this = this;
        setTimeout(function () {
            var value = _this.getObjectValue();
            if (!_this.lastValue && !value)
                return;
            if ((_this.lastValue && !value) || (!_this.lastValue && value) || (JSON.stringify(_this.lastValue) != JSON.stringify(value))) {
                FieldController.raiseEvent(EventType.FieldChange, value, _this.id);
                _this.lastValue = value;
            }
        }, 1);
    };
    Select2Field.prototype.convertId = function (id) {
        //Best Guess: Return data object with same "ID" property
        if (typeof id === 'string' && this.options.data.length > 0) {
            var result_1 = null;
            this.options.data.forEach(function (data) {
                if (data.children) {
                    data.children.forEach(function (child) {
                        if (child.id === id)
                            result_1 = child;
                    });
                }
                else if (data.id === id) {
                    result_1 = data;
                }
            });
            var returnValue = ((result_1) ? result_1.data : null);
            return Promise.resolve(returnValue);
        }
        return Promise.resolve(id);
    };
    Select2Field.prototype.showSpinner = function () {
        $('#' + this.id + '-spinner').removeClass('hidden');
    };
    Select2Field.prototype.hideSpinner = function () {
        $('#' + this.id + '-spinner').addClass('hidden');
    };
    Select2Field.prototype.updateFieldMeta = function (newMeta) {
        _super.prototype.updateFieldMeta.call(this, newMeta);
        this.init();
    };
    Select2Field.formatIcon = function (element) {
        if (!element.id)
            return element.text; // optgroup
        if (element.icon)
            return $('<span><img class="select2-icon-size select2-icon-margin" src="' + element.icon + '"  onerror="jiraHandleImageFallback(this)"/>' + element.text + '</span>');
        else if (element.iconClass) {
            return $('<span><i class="select2-icon-margin ' + element.iconClass + '"></i><span>' + element.text + '</span></span>');
        }
        else {
            return element.text;
        }
    };
    return Select2Field;
}(Field));
/// <reference path="../Field.ts" />
/// <reference path="Select2Field.ts" />
/// <reference path="../../../definitions/common.d.ts" />
var CascadedSelectField = (function (_super) {
    __extends(CascadedSelectField, _super);
    function CascadedSelectField(id, field) {
        var _this = _super.call(this, id, field) || this;
        _this.parentField = new JiraSelectField(id + '_parent', field, {}, 'min-width: 150px; width: 45%;');
        FieldController.registerEvent(EventType.FieldChange, _this, id + '_parent');
        var childFieldMeta = JSON.parse(JSON.stringify(field));
        childFieldMeta.allowedValues = [];
        _this.childField = new JiraSelectField(id + '_child', childFieldMeta, {}, 'min-width: 150px; width: 45%;');
        FieldController.registerEvent(EventType.FieldChange, _this, id + '_child');
        return _this;
    }
    CascadedSelectField.prototype.getDomValue = function () {
        return this.getValue();
    };
    CascadedSelectField.prototype.getValue = function (onlyChangedData) {
        if (onlyChangedData === void 0) { onlyChangedData = false; }
        var selectedParentId = this.parentField.getDomValue() || null;
        var selectedChildId = this.childField.getDomValue() || null;
        var resultObj = null;
        if (onlyChangedData) {
            //In edit case: Only send if changed	
            var oldParentValue = (this.initialValue) ? this.initialValue.id : null;
            var oldChildValue = (this.initialValue && this.initialValue.child) ? this.initialValue.child.id : null;
            if (!isEqual(oldParentValue, selectedParentId) ||
                !isEqual(oldChildValue, selectedChildId)) {
                if (selectedParentId) {
                    var childObj = (selectedChildId) ? { id: selectedChildId } : null;
                    return {
                        id: selectedParentId,
                        child: childObj
                    };
                }
                else {
                    return null;
                }
            }
        }
        else {
            //In creation case: Only send if not null
            if (selectedParentId) {
                resultObj = { id: selectedParentId };
                if (selectedChildId) {
                    resultObj.child = { id: selectedChildId };
                }
                return resultObj;
            }
        }
    };
    CascadedSelectField.prototype.setValue = function (value) {
        if (value) {
            this.parentField.setValue(value.id);
            this.parentField.initialValue = value.id;
            if (value.child) {
                this.childField.setValue(value.child.id);
                this.childField.initialValue = value.child.id;
            }
        }
        return Promise.resolve(value);
    };
    CascadedSelectField.prototype.handleEvent = function (type, newValue, source) {
        if (source === this.id + '_parent') {
            //Adjust Child Collection
            var allowedValues = [];
            if (newValue) {
                var currentSelection = this.fieldMeta.allowedValues.filter(function (v) { return v.id == newValue.id; })[0];
                allowedValues = (currentSelection) ? currentSelection.children : [];
            }
            this.childField.setData(allowedValues.map(this.childField.convertToSelect2));
        }
        FieldController.raiseEvent(EventType.FieldChange, this.getValue(false), this.id);
        return null;
    };
    CascadedSelectField.prototype.hookEventHandler = function () { };
    CascadedSelectField.prototype.render = function (container) {
        var parentContainer = $("<div id=\"{this.id}_parent-container\" style=\"display:inline;\"></div>").appendTo(container);
        this.parentField.render(parentContainer);
        this.parentField.hookEventHandler();
        this.parentField.ownContainer = parentContainer;
        container.append('<span style="margin-left: 10px;">&nbsp</span>');
        var childContainer = $("<div id=\"{this.id}_child-container\" style=\"display:inline;\"></div>").appendTo(container);
        this.childField.render(childContainer);
        this.childField.hookEventHandler();
        this.childField.ownContainer = childContainer;
    };
    CascadedSelectField.prototype.updateFieldMeta = function (newMeta) {
        _super.prototype.updateFieldMeta.call(this, newMeta);
        this.parentField.updateFieldMeta(newMeta);
        var childFieldMeta = JSON.parse(JSON.stringify(newMeta));
        childFieldMeta.allowedValues = [];
        this.childField.updateFieldMeta(childFieldMeta);
    };
    return CascadedSelectField;
}(Field));
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetObjectArray.ts" />
/// <reference path="../setter/SetCheckedValues.ts" />
var CheckboxField = (function (_super) {
    __extends(CheckboxField, _super);
    function CheckboxField() {
        return _super.apply(this, arguments) || this;
    }
    CheckboxField.prototype.getDomValue = function () {
        var checkedValues = [];
        $(this.ownContainer).find('input').each(function () {
            if ($(this).is(':checked')) {
                checkedValues.push({ id: $(this).val() });
            }
        });
        return checkedValues;
    };
    CheckboxField.prototype.hookEventHandler = function () {
        var _this = this;
        $("#" + this.id + "-field-group").find('input').change(function (e) { return _this.triggerValueChange(); });
    };
    ;
    CheckboxField.prototype.render = function (container) {
        var _this = this;
        var innerContainer = $('<div class="awesome-wrapper"></div>').appendTo(container);
        this.fieldMeta.allowedValues.forEach(function (option) {
            innerContainer.append($("<div class=\"checkbox awesome\">\n                                    <input type=\"checkbox\" id=\"" + _this.id + "_" + option.id + "\" value=\"" + option.id + "\">\n                                    <label for=\"" + _this.id + "_" + option.id + "\">" + option.value + "</label>\n                                </div>"));
        });
    };
    ;
    return CheckboxField;
}(Field));
CheckboxField = __decorate([
    getter(GetterType.ObjectArray, "id"),
    setter(SetterType.CheckedValues)
], CheckboxField);
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetTextValue.ts" />
/// <reference path="../setter/SetDateValue.ts" />
/// <reference path="../../../definitions/moment.d.ts" />
var DateField = (function (_super) {
    __extends(DateField, _super);
    function DateField() {
        return _super.apply(this, arguments) || this;
    }
    DateField.prototype.getDomValue = function () {
        var date = $('#' + this.id)["datetimepicker"]("getValue");
        if (date) {
            date = moment(date).format('YYYY-MM-DD');
        }
        return date;
    };
    DateField.prototype.hookEventHandler = function () {
        var _this = this;
        $('#' + this.id).change(function (e) { return _this.triggerValueChange(); });
    };
    DateField.prototype.render = function (container) {
        var _this = this;
        container.append($("<input style=\"height: 28px;\" class=\"text long-field\" id=\"" + this.id + "\" name=\"" + this.id + "\" placeholder=\"" + yasoon.i18n('dialog.datePickerFormatTitle') + "\" value=\"\" type=\"text\" >\n\t\t\t\t\t\t\t<a href=\"#\" id=\"" + this.id + "-trigger\" title=\"" + yasoon.i18n('dialog.titleSelectDate') + "\"><span class=\"aui-icon icon-date\">" + yasoon.i18n('dialog.titleSelectDate') + "</span></a>"));
        $('#' + this.id)["datetimepicker"]({
            timepicker: false,
            format: yasoon.i18n('dialog.datePickerDateFormat'),
            scrollInput: false,
            allowBlank: true
        });
        var country = yasoon.setting.getProjectSetting('locale').split('-')[0];
        $["datetimepicker"].setLocale(country);
        $('#' + this.id + '-trigger').off().click(function (e) {
            $('#' + _this.id)["datetimepicker"]("show");
        });
    };
    DateField.prototype.cleanup = function () {
        $('#' + this.id)["datetimepicker"]('destroy');
    };
    return DateField;
}(Field));
DateField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.Date)
], DateField);
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetTextValue.ts" />
/// <reference path="../setter/SetDateTimeValue.ts" />
/// <reference path="../../../definitions/moment.d.ts" />
var DateTimeField = (function (_super) {
    __extends(DateTimeField, _super);
    function DateTimeField() {
        return _super.apply(this, arguments) || this;
    }
    DateTimeField.prototype.getDomValue = function () {
        var date = $('#' + this.id)["datetimepicker"]("getValue");
        if (date) {
            date = moment(date).format('YYYY-MM-DD[T]HH:mm:ss.[000]ZZ');
        }
        return date;
    };
    DateTimeField.prototype.hookEventHandler = function () {
        var _this = this;
        $('#' + this.id).change(function (e) { return _this.triggerValueChange(); });
    };
    DateTimeField.prototype.render = function (container) {
        var _this = this;
        container.append($("<input style=\"height: 28px;\" class=\"text long-field\" id=\"" + this.id + "\" name=\"" + this.id + "\" placeholder=\"" + yasoon.i18n('dialog.dateTimePickerFormatTitle') + "\" value=\"\" type=\"text\" >\n\t\t\t\t\t\t\t<a href=\"#\" id=\"" + this.id + "-trigger\" title=\"" + yasoon.i18n('dialog.titleSelectDate') + "\"><span class=\"aui-icon icon-date\">" + yasoon.i18n('dialog.titleSelectDate') + "</span></a>"));
        var country = yasoon.setting.getProjectSetting('locale').split('-')[0];
        $('#' + this.id)["datetimepicker"]({
            allowTimes: [
                //'00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', '06:30',
                '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
                '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00'
            ],
            format: yasoon.i18n('dialog.dateTimePickerFormat'),
            scrollInput: false,
            allowBlank: true
        });
        $["datetimepicker"].setLocale(country);
        $('#' + this.id + '-trigger').off().click(function (e) {
            $('#' + _this.id)["datetimepicker"]("show");
        });
    };
    DateTimeField.prototype.cleanup = function () {
        $('#' + this.id)["datetimepicker"]('destroy');
    };
    return DateTimeField;
}(Field));
DateTimeField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.DateTime)
], DateTimeField);
/// <reference path="../Field.ts" />
/// <reference path="Select2Field.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
var Select2AjaxField = (function (_super) {
    __extends(Select2AjaxField, _super);
    function Select2AjaxField(id, field, options, multiple, style) {
        if (options === void 0) { options = {}; }
        if (multiple === void 0) { multiple = false; }
        if (style === void 0) { style = "min-width: 350px; width: 80%;"; }
        var _this;
        if (!options.ajax) {
            options.ajax = {
                url: '',
                transport: function (params, success, failure) {
                    _this.currentSearchTerm = '';
                    if (params && params.data && params.data.q) {
                        _this.currentSearchTerm = params.data.q;
                    }
                    var promise;
                    if (_this.currentSearchTerm) {
                        promise = _this.getDataDebounced(_this.currentSearchTerm);
                    }
                    else {
                        promise = _this.getEmptyDataInternal();
                    }
                    _this.showSpinner();
                    promise
                        .spread(function (result, searchTerm) {
                        //This handler is registered multiple times on the same promise.
                        //Check if we are still responsible to make sure we call the correct success function
                        if (searchTerm == _this.currentSearchTerm) {
                            _this.hideSpinner();
                            success(result);
                        }
                    })
                        .catch(function (error) {
                        _this.hideSpinner();
                        console.log('An error occured while fetching select2 data. Field ' + _this.id, error, error.stack);
                        yasoon.util.log('An error occured while fetching select2 data. ' + error.message + ' || Field: ' + _this.id, yasoon.util.severity.warning, getStackTrace(error));
                        success();
                    });
                },
                processResults: function (data, page) {
                    if (!data)
                        data = [];
                    return {
                        results: data
                    };
                }
            };
        }
        _this = _super.call(this, id, field, options, multiple, style) || this;
        _this.debouncedFunction = debounce(function (searchTerm) {
            _this.getData(searchTerm)
                .then(function (result) {
                _this.currentResolve([result, searchTerm]);
            })
                .catch(function (e) {
                _this.currentReject(e);
            });
        }, 500, false);
        return _this;
    }
    Select2AjaxField.prototype.init = function () {
        //Not nessecary if everything is loaded on demand
    };
    Select2AjaxField.prototype.getDataDebounced = function (searchTerm) {
        var _this = this;
        //Complicated...
        //We don'T want to spam Promises that never fullfill...
        //So we only create Promises if the previous one is already fullfilled.
        //But we need to save all Promise Data and call them debounced...
        if (!this.currentPromise || this.currentPromise.isFulfilled()) {
            this.currentPromise = new Promise(function (resolve, reject) {
                _this.currentReject = reject;
                _this.currentResolve = resolve;
                _this.debouncedFunction.call(_this, searchTerm);
            });
            return this.currentPromise;
        }
        this.debouncedFunction.call(this, searchTerm);
        return this.currentPromise;
    };
    Select2AjaxField.prototype.getEmptyDataInternal = function () {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.getEmptyData()];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, [result, '']]; //Keep signature for spread
                }
            });
        });
    };
    Select2AjaxField.prototype.getEmptyData = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (this.emptySearchResult)
                            return [2 /*return*/, this.emptySearchResult];
                        _a = this;
                        return [4 /*yield*/, this.getData("")];
                    case 1:
                        _a.emptySearchResult = _b.sent();
                        return [2 /*return*/, this.emptySearchResult];
                }
            });
        });
    };
    return Select2AjaxField;
}(Select2Field));
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var EpicLinkSelectField = (function (_super) {
    __extends(EpicLinkSelectField, _super);
    function EpicLinkSelectField(id, field) {
        var _this = _super.call(this, id, field) || this;
        //Update Epic JIRA 6.x and 7.0
        _this.updateEpic6 = function (newEpicLink, issueKey) {
            return jiraAjax('/rest/greenhopper/1.0/epics/' + newEpicLink + '/add', yasoon.ajaxMethod.Put, '{ "issueKeys":["' + issueKey + '"] }');
        };
        //Update Epic JIRA > 7.1
        _this.updateEpic7 = function (newEpicLink, issueKey) {
            return jiraAjax('/rest/agile/1.0/epic/' + newEpicLink + '/issue', yasoon.ajaxMethod.Post, '{ "issues":["' + issueKey + '"] }');
        };
        //Delete Epic JIRA 6.x and 7.0
        _this.deleteEpic6 = function (issueKey) {
            return jiraAjax('/rest/greenhopper/1.0/epics/remove', yasoon.ajaxMethod.Put, '{ "issueKeys":["' + issueKey + '"] }');
        };
        //Delete Epic JIRA > 7.1
        _this.deleteEpic7 = function (issueKey) {
            return jiraAjax('/rest/agile/1.0/epic/none/issue', yasoon.ajaxMethod.Post, '{ "issues":["' + issueKey + '"] }');
        };
        _this.options.placeholder = (field.hasDefaultValue && !jira.isEditMode) ? yasoon.i18n('dialog.selectDefault') : yasoon.i18n('dialog.selectNone');
        FieldController.registerEvent(EventType.AfterSave, _this);
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.issueTypeFieldId);
        return _this;
    }
    EpicLinkSelectField.prototype.handleEvent = function (type, newValue, source) {
        //Ticket: https://jira.atlassian.com/browse/GHS-10333
        //Jira till 7.1.4 cannot create / update Epics via the standard REST API
        //There is a workaround --> update it via unofficial greenhopper API
        if (type === EventType.AfterSave) {
            var newEpicLink = this.getDomValue();
            var eventData = newValue;
            if (jira.isEditMode) {
                //We cannot change epic Links via standard API, so trigger the call here
                var oldEpicLink = this.initialValue;
                if (newEpicLink != oldEpicLink) {
                    if (newEpicLink) {
                        //Create or update
                        if (jiraIsVersionHigher(jira.systemInfo, '7.1')) {
                            return this.updateEpic7(newEpicLink, eventData.newData.key);
                        }
                        else {
                            return this.updateEpic6(newEpicLink, eventData.newData.key);
                        }
                    }
                    else {
                        //Delete
                        if (jiraIsVersionHigher(jira.systemInfo, '7.1')) {
                            return this.deleteEpic7(eventData.newData.key);
                        }
                        else {
                            return this.deleteEpic6(eventData.newData.key);
                        }
                    }
                }
            }
            else if (!jira.isEditMode) {
                if (newEpicLink) {
                    if (jiraIsVersionHigher(jira.systemInfo, '7.1'))
                        return this.updateEpic7(newEpicLink, eventData.newData.key);
                    else
                        return this.updateEpic6(newEpicLink, eventData.newData.key);
                }
            }
        }
        else if (type === EventType.FieldChange && source === FieldController.issueTypeFieldId) {
            this.currentIssueType = newValue;
        }
        return null;
    };
    EpicLinkSelectField.prototype.getValue = function (changedDataOnly) {
        if (jiraIsVersionHigher(jira.systemInfo, '7.1.4')) {
            if (changedDataOnly) {
                var newEpicLink = this.getDomValue();
                var oldEpicLink = this.initialValue;
                if (newEpicLink != oldEpicLink) {
                    return this.getDomValue();
                }
            }
            else {
                return this.getDomValue();
            }
        }
    };
    EpicLinkSelectField.prototype.setValue = function (value) {
        //Format in JIRA < 7.0 "key: epicId" , JIRA 7+: just epic Id
        if (!jiraIsVersionHigher(jira.systemInfo, '7')) {
            value = value.replace('key:', '');
        }
        return this.setter.setValue(this, value);
    };
    EpicLinkSelectField.prototype.convertToSelect2 = function (epic) {
        return {
            id: epic.key,
            text: epic.name + ' ( ' + epic.key + ' )',
            data: epic
        };
    };
    EpicLinkSelectField.prototype.convertId = function (id) {
        return this.getData(id)
            .then(function (result) {
            if (result[0].children) {
                return result[0].children[0].data;
            }
            else {
                return result[0].data;
            }
        });
    };
    EpicLinkSelectField.prototype.getData = function (searchTerm) {
        var _this = this;
        //Result of Service
        // JIRA 6.x: {"epicNames":[{"key":"SSP-24","name":"Epic 1"},{"key":"SSP-25","name":"Epic 2"}],"total":2}
        // JIRA 7+:  {"epicLists":[{"listDescriptor":"All epics","epicNames":[{"key":"SSP-24","name":"Epic 1","isDone":false},{"key":"SSP-25","name":"Epic 2","isDone":false},{"key":"SSP-28","name":"Epic New","isDone":false}]}],"total":3}
        var url = '/rest/greenhopper/1.0/epics?maxResults=10&projectKey=' + jira.selectedProject.key + '&searchQuery=' + searchTerm;
        return jiraGet(url)
            .then(function (data) {
            var epics = JSON.parse(data);
            var results = [];
            if (epics && epics.total > 0) {
                if (epics.epicLists) {
                    var epic7 = epics;
                    epic7.epicLists.forEach(function (epicList) {
                        var children = epicList.epicNames.map(_this.convertToSelect2);
                        results.push({
                            id: epicList.listDescriptor,
                            text: epicList.listDescriptor,
                            children: children
                        });
                    });
                }
                else {
                    var epic6 = epics;
                    results = epic6.epicNames.map(_this.convertToSelect2);
                }
            }
            return results;
        });
    };
    EpicLinkSelectField.prototype.render = function (container) {
        if (this.currentIssueType && this.currentIssueType.subtask) {
            container.append('<span class="field-error field-inline ">' + yasoon.i18n('dialog.errorNoEpicForSubtasks') + '</span>');
        }
        else {
            _super.prototype.render.call(this, container);
        }
    };
    return EpicLinkSelectField;
}(Select2AjaxField));
EpicLinkSelectField = __decorate([
    setter(SetterType.Option)
], EpicLinkSelectField);
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var GroupSelectField = (function (_super) {
    __extends(GroupSelectField, _super);
    function GroupSelectField(id, field, options) {
        if (options === void 0) { options = { multiple: false }; }
        var _this;
        var select2Options = {};
        if (!options.multiple) {
            select2Options.placeholder = (field.hasDefaultValue && !jira.isEditMode) ? yasoon.i18n('dialog.selectDefault') : yasoon.i18n('dialog.selectNone');
        }
        _this = _super.call(this, id, field, select2Options, options.multiple) || this;
        return _this;
    }
    GroupSelectField.prototype.convertId = function (id) {
        if (!id['name']) {
            id = { name: id };
        }
        return Promise.resolve(id);
    };
    GroupSelectField.prototype.getData = function (searchTerm) {
        var _this = this;
        var url = '/rest/api/2/groups/picker?maxResults=50&query=' + searchTerm;
        return jiraGet(url)
            .then(function (data) {
            var groupsResult = JSON.parse(data);
            var groupsArray = [];
            groupsResult.groups.forEach(function (group) {
                groupsArray.push(_this.convertToSelect2(group));
            });
            return groupsArray;
        });
    };
    GroupSelectField.prototype.convertToSelect2 = function (group) {
        return {
            id: group.name,
            text: group.name,
            data: group
        };
    };
    return GroupSelectField;
}(Select2AjaxField));
GroupSelectField = __decorate([
    getter(GetterType.Option, "name", null),
    setter(SetterType.Option)
], GroupSelectField);
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var IssueField = (function (_super) {
    __extends(IssueField, _super);
    function IssueField(id, field, excludeSubtasks) {
        var _this;
        var options = {};
        options.placeholder = yasoon.i18n('dialog.placeholderSelectIssue');
        _this = _super.call(this, id, field, options) || this;
        _this.excludeSubtasks = excludeSubtasks;
        _this.recentItems = jira.recentItems;
        _this.emailController = jira.emailController;
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.projectFieldId);
        return _this;
    }
    IssueField.prototype.handleEvent = function (type, newValue, source) {
        if (source === FieldController.projectFieldId) {
            this.setProject(newValue);
            this.setDefaultIssue();
        }
        return null;
    };
    IssueField.prototype.setDefaultIssue = function () {
        if (jira.issue) {
            this.setValue(jira.issue.id);
            return;
        }
        //If mail is provided && subject contains reference to issue, pre-select that
        if (this.emailController) {
            var convData = this.emailController.getConversationData();
            if (convData) {
                //Try to find issue key that is in selected project
                for (var id in convData.issues) {
                    if (convData.issues[id].projectId === this.currentProject.id) {
                        this.setValue(convData.issues[id].key);
                        return;
                    }
                }
            }
            var subject = this.emailController.mail.subject;
            if (subject) {
                //Try to extract issue key from subject
                var regEx = new RegExp(this.currentProject.key + '.[0-9]+', 'g');
                var match = regEx.exec(subject);
                if (match && match.length > 0) {
                    this.setValue(match[0]);
                    return;
                }
            }
        }
    };
    IssueField.prototype.convertId = function (issueIdOrKey) {
        if (issueIdOrKey) {
            return jiraGet('/rest/api/2/issue/' + issueIdOrKey + '?fields=summary,project')
                .then(function (data) {
                return JSON.parse(data);
            });
        }
        return Promise.resolve();
    };
    IssueField.prototype.getReturnStructure = function (issues, queryTerm) {
        var _this = this;
        var result = [];
        //There are search results
        if (issues) {
            //If it has been a real search, we do not want to show any recent items
            if (queryTerm) {
                result.push({
                    id: 'Search',
                    text: yasoon.i18n('dialog.titleSearchResults', { term: queryTerm }),
                    children: issues
                });
            }
            else {
                //In case the project has been selected, only show recent Items of the same project
                var projectIssues = this.recentItems.recentIssues.filter(function (issue) {
                    return (issue.fields['project'] && issue.fields['project'].key == _this.currentProject.key);
                });
                if (projectIssues.length > 0) {
                    result.push({
                        id: 'Suggested',
                        text: yasoon.i18n('dialog.recentIssues'),
                        children: projectIssues.map(this.convertToSelect2),
                    });
                }
                result.push({
                    id: 'Search',
                    text: yasoon.i18n('dialog.projectIssues'),
                    children: issues
                });
            }
        }
        else {
            // Only show recent suggestion
            if (this.recentItems && this.recentItems.recentIssues && !queryTerm) {
                var currentIssues = this.recentItems.recentIssues.map(this.convertToSelect2);
                result.push({
                    id: 'Suggested',
                    text: yasoon.i18n('dialog.recentIssues'),
                    children: currentIssues,
                });
            }
        }
        return result;
    };
    IssueField.prototype.queryData = function (searchTerm) {
        var _this = this;
        //Concat JQL
        var jql = '';
        if (searchTerm) {
            jql += 'key = "' + searchTerm + '" OR ( Summary ~ "' + searchTerm + '"';
        }
        if (this.currentProject) {
            jql += ((jql) ? ' AND' : '') + ' project = "' + this.currentProject.key + '"';
        }
        if (jira.settings.hideResolvedIssues) {
            jql += ((jql) ? ' AND' : '') + ' status != "resolved" AND status != "closed" AND status != "done"';
        }
        if (this.excludeSubtasks) {
            jql += ((jql) ? ' AND' : '') + ' type NOT IN subtaskIssueTypes()';
        }
        //Closing brackets for first Summary
        if (searchTerm) {
            jql += ' )';
        }
        console.log('JQL' + jql);
        return jiraGet('/rest/api/2/search?jql=' + encodeURIComponent(jql) + '&maxResults=20&fields=summary,project&validateQuery=false')
            .then(function (data) {
            var jqlResult = JSON.parse(data);
            var result = [];
            console.log(jqlResult);
            //Transform Data
            result = jqlResult.issues.map(_this.convertToSelect2);
            return result;
        });
    };
    IssueField.prototype.triggerValueChange = function () {
        var issue = this.getObjectValue();
        if ((!this.lastValue && issue) || (this.lastValue && !issue) || (this.lastValue && issue && this.lastValue.id !== issue.id)) {
            FieldController.raiseEvent(EventType.FieldChange, issue, this.id);
            this.lastValue = issue;
        }
    };
    IssueField.prototype.convertToSelect2 = function (issue) {
        return {
            id: issue.id,
            text: issue.fields['summary'] + ' (' + issue.key + ')',
            data: issue
        };
    };
    IssueField.prototype.getData = function (searchTerm) {
        var _this = this;
        return this.queryData(searchTerm)
            .then(function (result) {
            return _this.getReturnStructure(result, searchTerm);
        });
    };
    IssueField.prototype.getEmptyData = function () {
        if (this.currentProject) {
            return this.getProjectIssues;
        }
        else {
            return Promise.resolve(this.getReturnStructure());
        }
    };
    IssueField.prototype.setProject = function (project) {
        var _this = this;
        this.currentProject = project;
        if (this.currentProject) {
            this.getProjectIssues = this.queryData('')
                .then(function (issues) {
                return _this.getReturnStructure(issues);
            });
        }
    };
    return IssueField;
}(Select2AjaxField));
IssueField.defaultMeta = { key: FieldController.issueFieldId, get name() { return yasoon.i18n('dialog.issue'); }, required: true, schema: { system: 'issue', type: '' } };
IssueField = __decorate([
    getter(GetterType.Option, "id"),
    setter(SetterType.Option)
], IssueField);
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var IssueTypeField = IssueTypeField_1 = (function (_super) {
    __extends(IssueTypeField, _super);
    function IssueTypeField(id, field) {
        var _this;
        var options = {};
        options.placeholder = yasoon.i18n('dialog.placeholderIssueType');
        options.allowClear = false;
        _this = _super.call(this, id, field, options) || this;
        _this.emailController = jira.emailController;
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.projectFieldId);
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.requestTypeFieldId);
        FieldController.registerEvent(EventType.UiAction, _this);
        return _this;
    }
    IssueTypeField.prototype.init = function () {
        //Handled in handleEvent when project changes
    };
    IssueTypeField.prototype.hookEventHandler = function () {
        _super.prototype.hookEventHandler.call(this);
        $('#switchServiceMode').click(function (e) {
            //Just raise Event so this can be raised from outside as well.
            //Ui Changes will be done in HandleEvent()
            var eventData = {
                name: IssueTypeField_1.uiActionServiceDesk,
                value: !$('#switchServiceMode').hasClass('active')
            };
            FieldController.raiseEvent(EventType.UiAction, eventData);
            e.preventDefault();
        });
    };
    IssueTypeField.prototype.render = function (container) {
        _super.prototype.render.call(this, container);
        if (!jira.isEditMode) {
            container.append("<br /><a id=\"switchServiceMode\" class=\"hidden\" style=\"cursor:pointer;\" title=\"\">\n                            <span class=\"showPortal\"><i class=\"fa fa-plus\"></i><span data-bind=\"localizedText: 'dialog.SDAssignment'\">Service Desk assignment</span> </span>\n                            <span class=\"hidePortal\"><i class=\"fa fa-minus\"></i><span data-bind=\"localizedText: 'dialog.SDAssignment'\">Service Desk assignment</span> </span>\n                        </a>");
        }
    };
    IssueTypeField.prototype.convertToSelect2 = function (issueType) {
        return {
            id: issueType.id,
            text: issueType.name,
            icon: jira.icons.mapIconUrl(issueType.iconUrl),
            data: issueType
        };
    };
    IssueTypeField.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (type == EventType.FieldChange) {
            if (source === FieldController.projectFieldId && newValue) {
                var project = newValue;
                if (this.currentProject && this.currentProject.id == project.id)
                    return;
                //If project was changed, we always have to throw change event.
                this.lastValue = null;
                var promise = void 0;
                if (!project.issueTypes) {
                    this.showSpinner();
                    promise = jiraGet('/rest/api/2/project/' + project.key)
                        .then(function (data) {
                        _this.hideSpinner();
                        var proj = JSON.parse(data);
                        return proj;
                    });
                }
                else {
                    promise = Promise.resolve(project);
                }
                promise.then(function (proj) {
                    _this.currentProject = proj;
                    var currentIssueType = _this.getObjectValue();
                    var result = proj.issueTypes.map(_this.convertToSelect2);
                    _this.setData(result);
                    //Check Service Desk
                    if (proj.projectTypeKey === "service_desk") {
                        $(_this.ownContainer).find('#switchServiceMode').removeClass('hidden');
                    }
                    else {
                        $(_this.ownContainer).find('#switchServiceMode').addClass('hidden');
                    }
                    var issueType = null;
                    if (_this.initialValue && typeof _this.initialValue === 'string') {
                        //Check if this issue type is still available for this project
                        issueType = proj.issueTypes.filter(function (it) { return it.id === _this.initialValue; })[0];
                    }
                    else if (currentIssueType) {
                        issueType = proj.issueTypes.filter(function (it) { return it.id === currentIssueType.id; })[0];
                    }
                    if (issueType) {
                        return _this.setValue(issueType);
                    }
                    else {
                        return _this.setValue(result[0].data);
                    }
                })
                    .then(function () {
                    _this.triggerValueChange();
                })
                    .catch(function (e) { _this.handleError(e); });
            }
            else if (source === FieldController.requestTypeFieldId) {
                var requestType_1 = newValue;
                var issueType = this.options.data.filter(function (sel) { return sel.id === requestType_1.issueType.toString(); })[0];
                this.setValue(issueType.data);
            }
        }
        else if (type === EventType.UiAction) {
            var eventData = newValue;
            if (eventData.name === IssueTypeField_1.uiActionServiceDesk) {
                if (eventData.value) {
                    //Render Fields
                    if (!FieldController.getField(FieldController.requestTypeFieldId)) {
                        //First time we need the requesttype field --> render
                        var requestTypeField = FieldController.loadField(RequestTypeField.defaultMeta, RequestTypeField);
                        requestTypeField.setProject(this.currentProject);
                        FieldController.render(FieldController.requestTypeFieldId, $('#ServiceAreaRequestField'));
                    }
                    if (!FieldController.getField(FieldController.onBehalfOfFieldId)) {
                        //Create On-Behalf of field
                        var behalfOfField = FieldController.loadField(UserSelectField.reporterDefaultMeta, UserSelectField, { allowNew: true });
                        FieldController.render(FieldController.onBehalfOfFieldId, $('#ServiceAreaReporterField'));
                        if (this.emailController) {
                            if (this.emailController.getSenderUser())
                                behalfOfField.senderUser = this.emailController.getSenderUser();
                            else
                                behalfOfField.senderUser = {
                                    displayName: this.emailController.getSenderEmail() + ' (new)',
                                    emailAddress: this.emailController.getSenderEmail(),
                                    name: '<new>'
                                };
                            behalfOfField.setValue(behalfOfField.senderUser);
                        }
                        else {
                            var reporterField = FieldController.getField(FieldController.reporterFieldId);
                            behalfOfField.setValue(reporterField.getValue());
                        }
                    }
                    //Enable Service mode
                    $('#' + this.id).prop("disabled", true);
                    $('#switchServiceMode').addClass('active');
                    $('#ServiceArea').removeClass('hidden');
                    $('#' + FieldController.reporterFieldId + '-field-group').addClass('hidden');
                }
                else {
                    //Disable Service mode
                    $('#' + this.id).prop("disabled", false);
                    $('#switchServiceMode').removeClass('active');
                    $('#ServiceArea').addClass('hidden');
                    $('#' + FieldController.reporterFieldId + '-field-group').removeClass('hidden');
                }
            }
        }
        return null;
    };
    IssueTypeField.prototype.handleError = function (e) {
        _super.prototype.handleError.call(this, e);
        if (e instanceof jiraSyncError) {
            $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitConnection'));
        }
        else {
            $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitUnknown'));
        }
    };
    return IssueTypeField;
}(Select2Field));
IssueTypeField.defaultMeta = { key: FieldController.issueTypeFieldId, get name() { return yasoon.i18n('dialog.issueType'); }, required: true, schema: { system: 'issue', type: '' } };
IssueTypeField.uiActionServiceDesk = 'ServiceDeskActivated';
IssueTypeField = IssueTypeField_1 = __decorate([
    getter(GetterType.Option, "id"),
    setter(SetterType.Option)
], IssueTypeField);
var IssueTypeField_1;
/// <reference path="../Field.ts" />
/// <reference path="Select2Field.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var JiraSelectField = (function (_super) {
    __extends(JiraSelectField, _super);
    function JiraSelectField(id, field, options, style) {
        if (options === void 0) { options = { multiple: false }; }
        if (style === void 0) { style = 'min-width: 350px; width: 80%;'; }
        var _this = _super.call(this, id, field, options, options.multiple, style) || this;
        _this.init();
        return _this;
    }
    JiraSelectField.prototype.init = function () {
        //Default value or None?
        if (!this.options.multiple) {
            this.options.placeholder = (this.fieldMeta.hasDefaultValue && !jira.isEditMode) ? yasoon.i18n('dialog.selectDefault') : yasoon.i18n('dialog.selectNone');
        }
        this.options.data = (this.fieldMeta.allowedValues) ? this.fieldMeta.allowedValues.map(this.convertToSelect2) : [];
    };
    JiraSelectField.prototype.convertToSelect2 = function (obj) {
        var result = {
            id: obj.id,
            text: obj.name || obj.value,
            data: obj
        };
        if (obj.iconUrl) {
            result.icon = jira.icons.mapIconUrl(obj.iconUrl);
        }
        return result;
    };
    return JiraSelectField;
}(Select2Field));
JiraSelectField = __decorate([
    getter(GetterType.Option, "id"),
    setter(SetterType.Option)
], JiraSelectField);
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../getter/GetArray.ts" />
/// <reference path="../setter/SetTagValue.ts" />
/// <reference path="../../../definitions/common.d.ts" />
var LabelSelectField = (function (_super) {
    __extends(LabelSelectField, _super);
    function LabelSelectField(id, field, options) {
        if (options === void 0) { options = {}; }
        var _this;
        options.tags = true;
        _this = _super.call(this, id, field, options, true) || this;
        return _this;
    }
    LabelSelectField.prototype.getDomValue = function () {
        return $('#' + this.id).val() || [];
    };
    LabelSelectField.prototype.convertToSelect2 = function (label) {
        var jiraLabel;
        if (typeof label === 'string')
            jiraLabel = { label: label };
        else
            jiraLabel = label;
        return {
            id: jiraLabel.label,
            text: jiraLabel.label,
        };
    };
    LabelSelectField.prototype.getObjectValue = function () {
        //Overwritten as the data attribute is not taken over for tags
        var elements = $('#' + this.id)['select2']('data');
        if (this.multiple) {
            return elements.map(function (p) { return p.id; });
        }
        else {
            return elements[0].id;
        }
    };
    LabelSelectField.prototype.getData = function (searchTerm) {
        var _this = this;
        //Damit JIRA!! ... in old JIRA releases the autocomplete URL is wrong :/
        var url = '/rest/api/1.0/labels/suggest?maxResults=50&query=';
        if (this.id !== 'labels') {
            url = '/rest/api/1.0/labels/suggest?maxResults=50&customFieldId=' + this.fieldMeta.schema.customId + '&query=';
        }
        this.lastSearchTerm = searchTerm;
        return jiraGet(url + searchTerm)
            .then(function (data) {
            var labels = JSON.parse(data);
            console.log('SearchTerm ' + searchTerm, labels);
            var labelArray = [];
            if (labels.token === _this.lastSearchTerm && labels.suggestions) {
                labels.suggestions.forEach(function (label) {
                    labelArray.push(_this.convertToSelect2(label));
                });
            }
            return labelArray;
        });
    };
    LabelSelectField.prototype.getEmptyData = function () {
        if (!this.emptyData)
            this.emptyData = this.getData('');
        return this.emptyData;
    };
    return LabelSelectField;
}(Select2AjaxField));
LabelSelectField = __decorate([
    getter(GetterType.Array),
    setter(SetterType.Tag)
], LabelSelectField);
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetTextValue.ts" />
/// <reference path="../setter/SetValue.ts" />
/// <reference path="../Bootbox.ts" />
var MultiLineTextField = (function (_super) {
    __extends(MultiLineTextField, _super);
    function MultiLineTextField(id, field, config) {
        if (config === void 0) { config = { isMainField: false, hasMentions: false }; }
        var _this = _super.call(this, id, field) || this;
        _this.searchJiraUser = function (mode, query, callback) {
            if (_this.currentIssue || _this.currentProject) {
                var queryKey = (_this.currentIssue) ? 'issueKey=' + _this.currentIssue.key : 'projectKey=' + _this.currentProject.key;
                jiraGet('/rest/api/2/user/viewissue/search?' + queryKey + '&maxResults=10&username=' + query)
                    .then(function (usersString) {
                    var data = [];
                    var users = JSON.parse(usersString);
                    users.forEach(function (user) {
                        data.push({ id: user.name, name: user.displayName, type: 'user' });
                    });
                    callback(data);
                });
            }
            else {
                //Show alert
                $('.mentions-input-box + .mentions-help-text').slideDown();
                if (_this.timeoutSearchUser) {
                    clearTimeout(_this.timeoutSearchUser);
                }
                _this.timeoutSearchUser = setTimeout(function () { $('.mentions-input-box + .mentions-help-text').slideUp(); }, 2000);
                callback([]);
            }
        };
        _this.emailController = jira.emailController;
        _this.hasMentions = config.hasMentions;
        _this.isMainField = config.isMainField;
        if (_this.hasMentions) {
            FieldController.registerEvent(EventType.FieldChange, _this, FieldController.projectFieldId);
            FieldController.registerEvent(EventType.FieldChange, _this, FieldController.issueFieldId);
        }
        FieldController.registerEvent(EventType.UiAction, _this);
        return _this;
    }
    MultiLineTextField.prototype.removeAttachmentFromBody = function (handle) {
        var regEx = new RegExp('(\\[\\^|!)' + handle.fileName + '(\\]|!)', 'g');
        var oldDescr = $('#' + this.id).val();
        var newDescr = oldDescr.replace(regEx, '').trim();
        this.setValue(newDescr);
    };
    MultiLineTextField.prototype.hasReference = function (handle) {
        var content = $('#' + this.id).val();
        if (content) {
            return content.indexOf(handle.fileName) >= 0;
        }
        return false;
    };
    MultiLineTextField.prototype.showOptionToolbar = function (useMarkup, showUndo) {
        this.ownContainer.find('#DescriptionOptionToolbar').removeClass('hidden');
        this.ownContainer.find('#DescriptionUseJiraMarkup').prop('checked', useMarkup);
        if (showUndo)
            this.ownContainer.find('#DescriptionUndoAction').removeClass('hidden');
    };
    MultiLineTextField.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (type === EventType.UiAction && this.isMainField) {
            var eventData_1 = newValue;
            if (eventData_1.name === AttachmentField.uiActionRename) {
                //Replace references of this attachment with new name (if necessary)
                var oldText = $('#' + this.id).val();
                if (oldText) {
                    var regEx = new RegExp(eventData_1.value.oldName, 'g');
                    var newText = oldText.replace(regEx, eventData_1.value.newName);
                    this.setValue(newText);
                }
            }
            else if (eventData_1.name === AttachmentField.uiActionSelect) {
                //We currently only care about attachments that have been deselected
                if (!eventData_1.value.selected) {
                    var autoRemove = yasoon.setting.getAppParameter('dialog.autoRemoveAttachmentReference');
                    if (autoRemove && autoRemove === 'true' && !eventData_1.value.selected) {
                        this.removeAttachmentFromBody(eventData_1.value);
                    }
                    else if (!autoRemove && this.hasReference(eventData_1.value)) {
                        Bootbox.confirm({
                            message: yasoon.i18n('dialog.attachmentReferenceStillActive'),
                            checkbox: yasoon.i18n('dialog.rememberDecision'),
                            primary: yasoon.i18n('dialog.yes'),
                            secondary: yasoon.i18n('dialog.no')
                        })
                            .then(function (result) {
                            if (result.ok) {
                                _this.removeAttachmentFromBody(eventData_1.value);
                            }
                            if (result.checkbox) {
                                yasoon.setting.setAppParameter('dialog.autoRemoveAttachmentReference', result.ok.toString());
                            }
                        });
                    }
                }
            }
            else if (eventData_1.name === AttachmentField.uiActionAddRef) {
                var markup = '';
                if (eventData_1.value.hasFilePreview()) {
                    markup = '!' + eventData_1.value.fileName + '!\n';
                }
                else {
                    markup = '[^' + eventData_1.value.fileName + ']\n';
                }
                insertAtCursor($('#' + this.id)[0], markup);
            }
        }
        else if (type === EventType.FieldChange) {
            if (source === FieldController.projectFieldId) {
                this.currentProject = newValue;
            }
            else if (source === FieldController.issueFieldId) {
                this.currentIssue = newValue;
            }
        }
        return null;
    };
    MultiLineTextField.prototype.addMainFieldHtml = function (container) {
        var html = " <div style=\"margin-top:5px; position:relative;\">\n                            <span id=\"DescriptionOptionToolbar\" style=\"padding: 3px;\">\n                                <span title=\"" + yasoon.i18n('dialog.titleToggleJiraMarkup') + "\">\n                                    <input id=\"DescriptionUseJiraMarkup\" class=\"toggle-checkbox\" type=\"checkbox\" checked=\"checked\"/>\n                                    " + yasoon.i18n('dialog.toggleJiraMarkup') + "\n                                </span>\n                                <a style=\"cursor:pointer;\" class=\"hidden\" id=\"DescriptionUndoAction\">\n                                    <i class=\"fa fa-undo\"></i>\n                                    " + yasoon.i18n('dialog.undo') + "\n                                </a>\n                            </span>\n                            <span class=\"dropup pull-right\">\n                                <a style=\"cursor:pointer;\" data-toggle=\"dropdown\" class=\"dropdown-toggle\" title=\"" + yasoon.i18n('dialog.titleReplaceWith') + "\" >\n                                    " + yasoon.i18n('dialog.replaceWith') + "\n                                    <span class=\"caret\"></span>\n                                </a>\n                                <ul class=\"dropdown-menu\">\n                                    <li>\n                                        <span style=\"display: block;padding: 4px 10px;\">\n                                            " + yasoon.i18n('dialog.toggleJiraMarkup') + "\n                                            <input class=\"toggleJiraMarkup toggle-checkbox\" type=\"checkbox\" checked=\"checked\" />\n                                        </span>\n                                    </li>\n                                    <li role=\"separator\" class=\"divider\"></li>\n                                    " + ((jira.selectedText) ? '<li id="DescriptionSelectedText"><a href="#">' + yasoon.i18n('dialog.addSelectedText') + '</a></li>' : '') + "\n                                    " + ((jira.mail) ? '<li id="DescriptionFullMail"><a href="#">' + yasoon.i18n('dialog.addConversation') + '</a></li>' : '') + "\n                \t            </ul>\n                            </span>\n                            <span class=\"dropup pull-right\" style=\"margin-right: 20px;\">\n                                <a style=\"cursor:pointer;\" data-toggle=\"dropdown\" class=\"dropdown-toggle\" title=\"" + yasoon.i18n('dialog.titleReplaceWith') + "\" >\n                                    " + yasoon.i18n('dialog.add') + "\n                                    <span class=\"caret\"></span>\n                                </a>\n                                <ul class=\"dropdown-menu\">\n                                    <li>\n                                        <span style=\"display: block;padding: 4px 10px;\">\n                                            " + yasoon.i18n('dialog.toggleJiraMarkup') + "\n                                            <input class=\"toggleJiraMarkup toggle-checkbox\" type=\"checkbox\" checked=\"checked\" />\n                                        </span>\n                                    </li>\n                                    <li role=\"separator\" class=\"divider\"></li>\n                                    " + ((jira.mail) ? '<li id="DescriptionMailInformation"><a href="#">' + yasoon.i18n('dialog.addMailInformation') + '</a></li>' : '') + "\n                                </ul>\n                            </span>\n                        </div>";
        container.append(html);
    };
    MultiLineTextField.prototype.getDomValue = function () {
        var val = '';
        if (this.hasMentions && this.mentionText) {
            //Parse @mentions
            val = this.mentionText.replace(/@.*?\]\(user:([^\)]+)\)/g, '[~$1]');
        }
        else {
            val = $('#' + this.id).val();
        }
        return val;
    };
    MultiLineTextField.prototype.hookEventHandler = function () {
        var _this = this;
        //Standard Change handler
        $('#' + this.id).change(function (e) { return _this.triggerValueChange(); });
        if (this.isMainField && this.emailController) {
            //Private vars for event Handler
            var useMarkup_1 = true;
            var backup_1 = '';
            var lastAction_1 = this.emailController.type;
            //Static toggle JIRA markup in drop down menus
            this.ownContainer.find('.toggleJiraMarkup').on('click', function (e) {
                useMarkup_1 = e.target['checked'];
                //Make sure all other toggles (even in other fields) have the same state
                $('.toggleJiraMarkup').prop('checked', useMarkup_1);
                e.stopPropagation();
            });
            //Temporary toggle markup button below text field until user changes some content
            this.ownContainer.find('#DescriptionUseJiraMarkup').on("change", function (e) {
                useMarkup_1 = e.target['checked'];
                var newContent;
                //Make sure all other toggles (even in other fields) have the same state
                $('.toggleJiraMarkup').prop('checked', useMarkup_1);
                if (lastAction_1 == 'selectedText') {
                    if (useMarkup_1)
                        newContent = _this.emailController.selectionAsMarkup;
                    else
                        newContent = _this.emailController.selectionPlain;
                }
                else if (lastAction_1 == 'wholeMail') {
                    if (useMarkup_1) {
                        newContent = _this.emailController.bodyAsMarkup;
                    }
                    else {
                        newContent = _this.emailController.bodyPlain;
                    }
                }
                else if (lastAction_1 == 'mailHeader') {
                    newContent = _this.emailController.getMailHeaderText(useMarkup_1) + backup_1;
                }
                _this.setValue(newContent);
                e.preventDefault();
            });
            $('#' + this.id).on("keyup paste", function (e) {
                _this.ownContainer.find('#DescriptionOptionToolbar').addClass('hidden');
            });
            this.ownContainer.find('#DescriptionUndoAction').on('click', function (e) {
                _this.setValue(backup_1);
                _this.ownContainer.find('#DescriptionOptionToolbar').addClass('hidden');
            });
            this.ownContainer.find('#DescriptionSelectedText').on('click', function (e) {
                backup_1 = $('#' + _this.id).val();
                lastAction_1 = 'selectedText';
                var content = (useMarkup_1) ? _this.emailController.selectionAsMarkup : _this.emailController.selectionPlain;
                $('#' + _this.id).val(content);
            });
            this.ownContainer.find('#DescriptionFullMail').on('click', function (e) {
                backup_1 = $('#' + _this.id).val();
                lastAction_1 = 'wholeMail';
                _this.showOptionToolbar(useMarkup_1, true);
                var content = (useMarkup_1) ? _this.emailController.bodyAsMarkup : _this.emailController.bodyPlain;
                $('#' + _this.id).val(content);
            });
            this.ownContainer.find('#DescriptionMailInformation').on('click', function (e) {
                var field = $('#' + _this.id);
                lastAction_1 = 'mailHeader';
                backup_1 = field.val();
                _this.showOptionToolbar(useMarkup_1, true);
                field.val(_this.emailController.getMailHeaderText(useMarkup_1) + backup_1);
            });
        }
        if (this.hasMentions) {
            //Init Mentions
            $('#' + this.id)['mentionsInput']({
                onDataRequest: this.searchJiraUser,
                triggerChar: '@',
                minChars: 2,
                showAvatars: false,
                elastic: false
            });
            $('#' + this.id).on('scroll', function () {
                $(this).prev().scrollTop($(this).scrollTop());
            });
            $('#' + this.id).on('updated', debounce(function () {
                $('#' + _this.id)['mentionsInput']('val', function (content) {
                    _this.mentionText = content;
                });
            }, 250));
        }
    };
    MultiLineTextField.prototype.render = function (container) {
        var height = (this.isMainField) ? '200px' : '100px';
        container.append("<textarea class=\"form-control text\" id=\"" + this.id + "\" name=\"" + this.id + "\" style=\"height:" + height + ";overflow: initial;\"></textarea>\n            <div class=\"mentions-help-text bg-warning\"><span>" + yasoon.i18n('dialog.mentionsAlert') + "</span></div>");
        if (this.isMainField && this.emailController) {
            this.addMainFieldHtml(container);
        }
    };
    return MultiLineTextField;
}(Field));
MultiLineTextField.defaultCommentMeta = { key: FieldController.commentFieldId, get name() { return yasoon.i18n('dialog.comment'); }, required: false, schema: { system: 'description', type: '' } };
MultiLineTextField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.Text)
], MultiLineTextField);
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetTextValue.ts" />
/// <reference path="../setter/SetValue.ts" />
var NumberField = (function (_super) {
    __extends(NumberField, _super);
    function NumberField() {
        return _super.apply(this, arguments) || this;
    }
    NumberField.prototype.getDomValue = function () {
        var domValue = $('#' + this.id).val();
        if (domValue !== '') {
            return parseFloat(domValue);
        }
        else {
            return null;
        }
    };
    NumberField.prototype.hookEventHandler = function () {
        var _this = this;
        $('#' + this.id).change(function (e) { return _this.triggerValueChange(); });
    };
    ;
    NumberField.prototype.render = function (container) {
        container.append($("<input class=\"text long-field\" id=\"" + this.id + "\" name=\"" + this.id + "\" type=\"number\" />"));
    };
    ;
    return NumberField;
}(Field));
NumberField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.Text)
], NumberField);
/// <reference path="../Field.ts" />
/// <reference path="../FieldController.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetTextValue.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var OrganizationField = (function (_super) {
    __extends(OrganizationField, _super);
    function OrganizationField(id, field, options) {
        if (options === void 0) { options = {}; }
        var _this;
        options.multiple = true;
        options.allowClear = true;
        _this = _super.call(this, id, field, options, true) || this;
        _this.serviceDeskController = jira.serviceDeskController;
        _this.init();
        return _this;
    }
    OrganizationField.prototype.init = function () {
        var _this = this;
        this.getData()
            .then(function (elements) {
            _this.setData(elements);
        });
    };
    OrganizationField.prototype.convertToSelect2 = function (obj) {
        return {
            id: obj.id,
            text: obj.name,
            data: obj
        };
    };
    OrganizationField.prototype.convertId = function (id) {
        if (id['id']) {
            return Promise.resolve(id);
        }
        else {
            return this.getOrganizationsPromise
                .then(function (organizations) {
                return organizations.filter(function (org) { return org.id == id; })[0];
            });
        }
    };
    OrganizationField.prototype.getData = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var serviceDeskKeys;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.serviceDeskController.getCurrentServiceDeskKey()];
                    case 1:
                        serviceDeskKeys = _a.sent();
                        this.getOrganizationsPromise = jiraGetAll('/rest/servicedeskapi/servicedesk/' + serviceDeskKeys.id + '/organization')
                            .then(function (organizations) {
                            return organizations.values.sort(function (a, b) { return (a.name.toLowerCase() > b.name.toLowerCase()) ? 1 : -1; });
                        });
                        return [2 /*return*/, this.getOrganizationsPromise
                                .then(function (organizations) {
                                return organizations.map(_this.convertToSelect2);
                            })];
                }
            });
        });
    };
    return OrganizationField;
}(Select2Field));
OrganizationField = __decorate([
    getter(GetterType.Option, "id"),
    setter(SetterType.Option)
], OrganizationField);
/// <reference path="../Field.ts" />
/// <reference path="../FieldController.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var ProjectField = (function (_super) {
    __extends(ProjectField, _super);
    function ProjectField(id, field, fieldOptions) {
        if (fieldOptions === void 0) { fieldOptions = { cache: [], allowClear: false, showTemplates: false, isMainProjectField: false }; }
        var _this;
        var options = {};
        options.placeholder = yasoon.i18n('dialog.placeholderSelectProject');
        options.allowClear = fieldOptions.allowClear;
        _this = _super.call(this, id, field, options) || this;
        _this.emailController = jira.emailController;
        _this.recentItems = jira.recentItems;
        _this.templateController = jira.templateController;
        _this.isMainProjectField = fieldOptions.isMainProjectField;
        _this.showTemplates = fieldOptions.showTemplates && !!_this.templateController;
        if (fieldOptions.cache) {
            _this.projectCache = fieldOptions.cache;
        }
        //Start Getting Data
        _this.showSpinner();
        _this.getData()
            .then(function (data) {
            _this.hideSpinner();
            _this.setData(data);
            if (_this.isMainProjectField) {
                _this.setDefaultProject();
                $('#' + _this.id).next().find('.select2-selection').first().focus();
            }
        })
            .catch(function (e) { _this.handleError(e); });
        return _this;
    }
    ProjectField.prototype.init = function () {
        //Init is called automatically for each new meta --> not necessary for projects
    };
    ProjectField.prototype.setDefaultProject = function () {
        if (this.initialValue)
            return;
        //Applications like tasks may insert 
        if (jira.issue && jira.issue.fields && jira.issue.fields.project) {
            this.setValue(jira.issue.fields.project);
            return;
        }
        // Mail may already contain a conversation. Should this also be valid for newIssue?!
        if (this.emailController) {
            var convData = this.emailController.getConversationData();
            if (convData) {
                var _loop_2 = function (id) {
                    var intId = parseInt(id);
                    var issue = convData.issues[id];
                    if (this_2.projectCache.filter(function (el) { return el.id === issue.projectId; }).length > 0) {
                        this_2.setValue(issue.projectId);
                        return { value: void 0 };
                    }
                };
                var this_2 = this;
                //Try to find project that matches
                //We could just lookup the first issue and directly select the projectId.
                //However, we want to support longterm enhancements where conversationData could be shared with others and then the project might not exist for this user.
                for (var id in convData.issues) {
                    var state_1 = _loop_2(id);
                    if (typeof state_1 === "object")
                        return state_1.value;
                }
            }
        }
        //If mail is provided && subject contains reference to project, pre-select that
        if (this.emailController && this.emailController.mail && this.emailController.mail.subject && this.projectCache && this.projectCache.length > 0) {
            //Sort projects by key length descending, so we will match the following correctly:
            // Subject: This is for DEMODD project
            // Keys: DEMO, DEMOD, DEMODD
            var projectsByKeyLength = this.projectCache.sort(function (a, b) {
                return b.key.length - a.key.length; // ASC -> a - b; DESC -> b - a
            });
            for (var i = 0; i < projectsByKeyLength.length; i++) {
                var curProj = projectsByKeyLength[i];
                if (this.emailController.mail.subject.indexOf(curProj.key) >= 0) {
                    this.setValue(curProj);
                    return;
                }
            }
        }
    };
    ProjectField.prototype.convertToSelect2 = function (project) {
        return {
            id: project.id,
            text: project.name,
            icon: getProjectIcon(project),
            data: project
        };
    };
    ProjectField.prototype.handleError = function (e) {
        _super.prototype.handleError.call(this, e);
        if (e instanceof jiraSyncError) {
            $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitConnection'));
        }
        else {
            $('#MainAlert').removeClass('hidden').find('.error-text').text(yasoon.i18n('dialog.errorInitUnknown'));
        }
    };
    ProjectField.prototype.hookEventHandler = function () {
        var _this = this;
        _super.prototype.hookEventHandler.call(this);
        if (this.showTemplates) {
            this.ownContainer.find('.show-template-modal').click(function (e) {
                console.log('Triggered Call Dialog');
                _this.templateController.showTemplateSelection();
            });
        }
    };
    ProjectField.prototype.render = function (container) {
        _super.prototype.render.call(this, container);
        if (this.showTemplates) {
            container.append('<div style="display:inline-block; margin-left: 5px;"><a class="show-template-modal"><i class="fa fa-magic"></i></a></div>');
        }
    };
    ProjectField.prototype.getReturnStructure = function (projects, queryTerm) {
        var _this = this;
        var result = [];
        //1. Recent Projects
        if (this.recentItems && this.recentItems.recentProjects) {
            //2.1 Filter
            var currentRecent = projects.filter(function (p) {
                return _this.recentItems.recentProjects.filter(function (recent) { return p.id === recent.id; }).length > 0;
            });
            if (currentRecent.length > 0) {
                //2.2 Map and Add
                result.push({
                    id: 'recent',
                    text: yasoon.i18n('dialog.recentProjects'),
                    children: currentRecent
                });
            }
        }
        //2. All Projects
        var sortedProjects = projects.sort(function (a, b) { return ((a.text.toLowerCase() > b.text.toLowerCase()) ? 1 : -1); });
        result.push({
            id: 'all',
            text: yasoon.i18n('dialog.allProjects'),
            children: sortedProjects
        });
        return result;
    };
    ProjectField.prototype.queryData = function () {
        var _this = this;
        if (this.projectCache && this.projectCache.length > 0) {
            return Promise.resolve(this.projectCache.map(this.convertToSelect2));
        }
        return jiraGet('/rest/api/2/project')
            .then(function (data) {
            var projects = JSON.parse(data);
            _this.projectCache = projects;
            return projects.map(_this.convertToSelect2);
        });
    };
    ProjectField.prototype.getData = function () {
        var _this = this;
        if (this.returnStructure) {
            return Promise.resolve(this.returnStructure);
        }
        return this.queryData()
            .then(function (projects) {
            _this.returnStructure = _this.getReturnStructure(projects);
            return _this.returnStructure;
        });
    };
    return ProjectField;
}(Select2Field));
ProjectField.defaultMeta = { key: FieldController.projectFieldId, get name() { return yasoon.i18n('dialog.project'); }, required: true, schema: { system: 'project', type: '' } };
ProjectField = __decorate([
    getter(GetterType.Option, "id"),
    setter(SetterType.Option)
], ProjectField);
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetObject.ts" />
/// <reference path="../setter/SetCheckedValues.ts" />
var RadioField = (function (_super) {
    __extends(RadioField, _super);
    function RadioField() {
        return _super.apply(this, arguments) || this;
    }
    RadioField.prototype.getDomValue = function () {
        return $(this.ownContainer).find('input:checked').first().val();
    };
    ;
    RadioField.prototype.hookEventHandler = function () {
        var _this = this;
        $("#" + this.id + "-field-group").find('input').change(function (e) { return _this.triggerValueChange(); });
    };
    ;
    RadioField.prototype.render = function (container) {
        var _this = this;
        var innerContainer = $('<div class="awesome-wrapper"></div>').appendTo(container);
        if (!this.fieldMeta.required) {
            //If it isn't required we should allow a None option
            innerContainer.append($("<div class=\"radio awesome\">\n                                    <input type=\"radio\" id=\"" + this.id + "_none\" name=\"" + this.id + "\" value=\"\" checked>\n                                    <label for=\"" + this.id + "_none\">" + yasoon.i18n('dialog.selectNone') + "</label>\n                                </div>"));
        }
        this.fieldMeta.allowedValues.forEach(function (option) {
            innerContainer.append($("<div class=\"radio awesome\">\n                                    <input type=\"radio\" id=\"" + _this.id + "_" + option.id + "\" name=\"" + _this.id + "\" value=\"" + option.id + "\">\n                                    <label for=\"" + _this.id + "_" + option.id + "\">" + option.value + "</label>\n                                </div>"));
        });
    };
    ;
    return RadioField;
}(Field));
RadioField = __decorate([
    getter(GetterType.Object, "id"),
    setter(SetterType.CheckedValues)
], RadioField);
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
/// <reference path="../ServiceDeskController.ts" />
var RequestTypeField = (function (_super) {
    __extends(RequestTypeField, _super);
    function RequestTypeField(id, field) {
        var _this;
        var options = {};
        options.placeholder = yasoon.i18n('dialog.placeholderRequestType');
        options.allowClear = false;
        _this = _super.call(this, id, field, options) || this;
        _this.serviceDeskController = jira.serviceDeskController;
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.projectFieldId);
        return _this;
    }
    RequestTypeField.prototype.init = function () {
        //Not necessary--> handled in handleEvent
    };
    RequestTypeField.prototype.triggerValueChange = function () {
        var requestType = this.getObjectValue();
        FieldController.raiseEvent(EventType.FieldChange, requestType, this.id);
    };
    RequestTypeField.prototype.handleEvent = function (type, newValue, source) {
        if (type === EventType.FieldChange) {
            if (source === FieldController.projectFieldId && newValue.projectTypeKey === 'service_desk') {
                this.setProject(newValue);
            }
        }
        return null;
    };
    RequestTypeField.prototype.convertToSelect2 = function (requestType) {
        var data = {
            id: requestType.id.toString(),
            text: requestType.name,
            data: requestType
        };
        //Das klappt, aber bin zu blöd das Font Icon zu alignen.
        //if (requestType.icon - 10500 > 36) {
        data.icon = jira.icons.mapIconUrl(jira.settings.baseUrl + '/servicedesk/customershim/secure/viewavatar?avatarType=SD_REQTYPE&avatarId=' + requestType.icon);
        // } else {
        //     data.iconClass = 'vp-rq-icon vp-rq-icon-' + (requestType.icon - 10500);
        // }
        return data;
    };
    RequestTypeField.prototype.getReturnStructure = function (requestTypes) {
        var _this = this;
        //First we need to gather all groups
        var result = [];
        requestTypes.forEach(function (rt) {
            if (!rt.groups)
                return;
            rt.groups.forEach(function (group) {
                //First check if group does already exist in result structure
                var parent = result.filter(function (elem) { return elem.id == group.id.toString(); })[0];
                if (!parent) {
                    parent = {
                        id: group.id.toString(),
                        text: group.name,
                        children: []
                    };
                    result.push(parent);
                }
                //Now add requestType to this group
                parent.children.push(_this.convertToSelect2(rt));
            });
        });
        result.sort(sortByText);
        return result;
    };
    RequestTypeField.prototype.setProject = function (project) {
        var _this = this;
        this.currentProject = project;
        this.showSpinner();
        this.serviceDeskController.getServiceDeskKey(this.currentProject.id, this.currentProject.key)
            .then(function (serviceDeskKey) {
            return _this.serviceDeskController.getRequestTypes(serviceDeskKey);
        })
            .then(function (requestTypes) {
            _this.hideSpinner();
            _this.setData(_this.getReturnStructure(requestTypes));
        })
            .catch(function (e) {
            console.log('Error while loading request types', e);
            yasoon.util.log('Error while loading request types: ' + e.message, yasoon.util.severity.warning, getStackTrace(e));
            _this.hideSpinner();
        });
    };
    return RequestTypeField;
}(Select2Field));
RequestTypeField.defaultMeta = { key: FieldController.requestTypeFieldId, get name() { return yasoon.i18n('dialog.requestType'); }, required: true, schema: { system: 'requesttype', type: '' } };
RequestTypeField = __decorate([
    getter(GetterType.Option, "id"),
    setter(SetterType.Option)
], RequestTypeField);
/// <reference path="../Field.ts" />
/// <reference path="../getter/GetTextValue.ts" />
/// <reference path="../setter/SetValue.ts" />
var SingleTextField = (function (_super) {
    __extends(SingleTextField, _super);
    function SingleTextField() {
        return _super.apply(this, arguments) || this;
    }
    SingleTextField.prototype.getDomValue = function () {
        return $('#' + this.id).val();
    };
    SingleTextField.prototype.hookEventHandler = function () {
        var _this = this;
        $('#' + this.id).change(function (e) { return _this.triggerValueChange(); });
    };
    ;
    SingleTextField.prototype.render = function (container) {
        container.append($("<input class=\"text long-field\" id=\"" + this.id + "\" name=\"" + this.id + "\" type=\"text\" />"));
    };
    ;
    return SingleTextField;
}(Field));
SingleTextField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.Text)
], SingleTextField);
/// <reference path="../Field.ts" />
/// <reference path="Select2Field.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var SprintSelectField = (function (_super) {
    __extends(SprintSelectField, _super);
    function SprintSelectField(id, field) {
        var _this = _super.call(this, id, field, {}) || this;
        _this.options.placeholder = (field.hasDefaultValue && !jira.isEditMode) ? yasoon.i18n('dialog.selectDefault') : yasoon.i18n('dialog.selectNone');
        FieldController.registerEvent(EventType.BeforeSave, _this);
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.issueTypeFieldId);
        _this.init();
        return _this;
    }
    SprintSelectField.prototype.init = function () {
        var _this = this;
        this.getData()
            .then(function (data) {
            _this.setData(data);
        });
    };
    SprintSelectField.prototype.handleEvent = function (type, newValue, source) {
        if (type === EventType.BeforeSave && jira.isEditMode) {
            var eventData = newValue;
            var oldSprintId = '';
            if (this.initialValue)
                oldSprintId = this.parseSprintId(this.initialValue);
            var newSprintId = this.getValue(false);
            if (oldSprintId != newSprintId) {
                if (newSprintId) {
                    return jiraAjax('/rest/greenhopper/1.0/sprint/rank', yasoon.ajaxMethod.Put, '{"idOrKeys":["' + jira.currentIssue.key + '"],"sprintId":' + newSprintId + ',"addToBacklog":false}');
                }
                else {
                    return jiraAjax('/rest/greenhopper/1.0/sprint/rank', yasoon.ajaxMethod.Put, '{"idOrKeys":["' + jira.currentIssue.key + '"],"sprintId":"","addToBacklog":true}');
                }
            }
        }
        else if (type === EventType.FieldChange && source === FieldController.issueTypeFieldId) {
            this.currentIssueType = newValue;
        }
        return null;
    };
    SprintSelectField.prototype.getValue = function (changedDataOnly) {
        //Only for creation as Epic links cannot be changed via REST APi --> Status code 500
        //Ticket: https://jira.atlassian.com/browse/GHS-10333
        //There is a workaround --> update it via unofficial greenhopper API --> For update see handleEvent
        //We aren't sure with which version this change happened. 7.0.0 definitely requires a string, 7.1.6. requires an int :)
        if (!changedDataOnly) {
            var stringValue = this.getDomValue();
            if (stringValue) {
                if (jiraIsVersionHigher(jira.systemInfo, '7.1')) {
                    return parseInt(stringValue);
                }
                else {
                    return stringValue;
                }
            }
        }
    };
    SprintSelectField.prototype.setValue = function (value) {
        if (value && value.length > 0) {
            var sprintId = this.parseSprintId(value[0]);
            return this.setter.setValue(this, sprintId);
        }
        return Promise.resolve(value);
    };
    SprintSelectField.prototype.convertToSelect2 = function (sprint) {
        return {
            id: sprint.id.toString(),
            text: sprint.name,
            data: sprint
        };
    };
    SprintSelectField.prototype.getData = function () {
        var _this = this;
        return jiraGet('/rest/greenhopper/1.0/sprint/picker')
            .then(function (data) {
            //{"suggestions":[{"name":"Sample Sprint 2","id":1,"stateKey":"ACTIVE"}],"allMatches":[]}
            var sprints = JSON.parse(data);
            var result = [];
            if (sprints && sprints.suggestions.length > 0) {
                var suggestions = sprints.suggestions.map(_this.convertToSelect2);
                result.push({
                    id: 'suggestions',
                    text: yasoon.i18n('dialog.sprintSuggestion'),
                    children: suggestions
                });
            }
            if (sprints && sprints.allMatches && sprints.allMatches.length > 0) {
                var matches = sprints.allMatches.map(_this.convertToSelect2);
                result.push({
                    id: 'allMatches',
                    text: yasoon.i18n('dialog.sprintAll'),
                    children: matches
                });
            }
            return result;
        });
    };
    SprintSelectField.prototype.render = function (container) {
        if (this.currentIssueType && this.currentIssueType.subtask) {
            container.append('<span class="field-inline">' + yasoon.i18n('dialog.warningSprintInherited') + '</span>');
        }
        else {
            _super.prototype.render.call(this, container);
        }
    };
    SprintSelectField.prototype.parseSprintId = function (input) {
        //Wierd --> it's an array of strings with following structure:  "com.atlassian.greenhopper.service.sprint.Sprint@7292f4[rapidViewId=<null>,state=ACTIVE,name=Sample Sprint 2,startDate=2015-04-09T01:54:26.773+02:00,endDate=2015-04-23T02:14:26.773+02:00,completeDate=<null>,sequence=1,id=1]"
        //First get content of array (everything between [])
        //Then split at ,
        //Then find id
        var result = '';
        var matches = /\[(.+)\]/g.exec(input);
        if (matches.length > 0) {
            var splitResult = matches[1].split(',');
            var idObj = splitResult.filter(function (elem) { return elem.indexOf('id') === 0; });
            if (idObj.length > 0) {
                result = idObj[0].split('=')[1];
            }
        }
        return result;
    };
    return SprintSelectField;
}(Select2Field));
SprintSelectField = __decorate([
    setter(SetterType.Option)
], SprintSelectField);
/// <reference path="../Field.ts" />
var TimeTrackingField = (function (_super) {
    __extends(TimeTrackingField, _super);
    function TimeTrackingField(id, field) {
        var _this = _super.call(this, id, field) || this;
        var origFieldMeta = JSON.parse(JSON.stringify(field));
        var remainingFieldMeta = JSON.parse(JSON.stringify(field));
        origFieldMeta.name = yasoon.i18n('dialog.timetrackingOriginal');
        origFieldMeta.description = yasoon.i18n('dialog.timetrackingDescrOriginal');
        remainingFieldMeta.name = yasoon.i18n('dialog.timetrackingRemaining');
        remainingFieldMeta.description = yasoon.i18n('dialog.timetrackingDescrRemain');
        _this.origField = new SingleTextField(id + '_originalestimate', origFieldMeta);
        _this.remainingField = new SingleTextField(id + '_remainingestimate', remainingFieldMeta);
        return _this;
    }
    TimeTrackingField.prototype.getValue = function (onlyChangedData) {
        if (onlyChangedData === void 0) { onlyChangedData = false; }
        var origVal = this.origField.getDomValue();
        var remainVal = this.remainingField.getDomValue();
        //JIRA timetracking legacy mode
        // --> it's not allowed to set orig and remainaing Estimate during creation
        // --> it's not allowed to change original estimate.
        var result = {};
        //Edit Case
        if (onlyChangedData) {
            if ((!this.initialValue && origVal) || (this.initialValue && this.initialValue.originalEstimate != origVal)) {
                result.originalEstimate = origVal;
            }
            if ((!this.initialValue && remainVal) || (this.initialValue && this.initialValue.remainingEstimate != remainVal)) {
                result.remainingEstimate = remainVal;
            }
        }
        else {
            if (origVal) {
                result.originalEstimate = origVal;
            }
            if (remainVal) {
                result.remainingEstimate = remainVal;
            }
        }
        //Only return an object if it's not empty;
        return (Object.keys(result).length > 0) ? result : undefined;
    };
    TimeTrackingField.prototype.setValue = function (value) {
        if (value) {
            this.origField.setValue(value.originalEstimate);
            this.remainingField.setValue(value.remainingEstimate);
        }
        return Promise.resolve(value);
    };
    TimeTrackingField.prototype.getDomValue = function () {
        return "";
    };
    TimeTrackingField.prototype.hookEventHandler = function () {
        var _this = this;
        $('#' + this.id).change(function (e) { return _this.triggerValueChange(); });
    };
    ;
    TimeTrackingField.prototype.renderField = function (container) {
        return Promise.all([
            this.origField.renderField(container),
            this.remainingField.renderField(container)
        ]);
    };
    TimeTrackingField.prototype.render = function (container) {
        //Not nessecary as we redefine renderField
    };
    ;
    return TimeTrackingField;
}(Field));
/// <reference path="../Field.ts" />
/// <reference path="Select2AjaxField.ts" />
/// <reference path="../../../definitions/bluebird.d.ts" />
/// <reference path="../../../definitions/common.d.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var UserSelectField = (function (_super) {
    __extends(UserSelectField, _super);
    function UserSelectField(id, field, options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, id, field, options, options.multiple) || this;
        _this.ownUser = jira.ownUser;
        _this.allowNew = options.allowNew;
        _this.avatarPath = yasoon.io.getLinkPath('Images/useravatar.png');
        _this.recentItems = jira.recentItems;
        FieldController.registerEvent(EventType.SenderLoaded, _this);
        FieldController.registerEvent(EventType.FieldChange, _this, FieldController.projectFieldId);
        return _this;
    }
    UserSelectField.prototype.handleEvent = function (type, newValue, source) {
        if (type == EventType.SenderLoaded) {
            if (newValue) {
                this.senderUser = newValue;
            }
        }
        else if (type === EventType.FieldChange && source === FieldController.projectFieldId) {
            this.currentProject = newValue;
        }
        return null;
    };
    UserSelectField.prototype.hookEventHandler = function () {
        var _this = this;
        _super.prototype.hookEventHandler.call(this);
        this.ownContainer.find('.assign-to-me-trigger').click(function (e) {
            if (_this.ownUser) {
                _this.setValue(_this.ownUser);
            }
            e.preventDefault();
        });
        this.ownContainer.find('.add-myself-trigger').click(function (e) {
            e.preventDefault();
            if (_this.ownUser) {
                var currentValues = _this.getObjectValue() || [];
                if (currentValues.filter(function (user) { return user.name === _this.ownUser.name; }).length > 0) {
                    //Check if own user is already added
                    return;
                }
                currentValues.push(_this.ownUser);
                _this.setValue(currentValues);
            }
        });
    };
    //Overwrite:
    UserSelectField.prototype.triggerValueChange = function () {
        var lastValue = this.lastValue;
        _super.prototype.triggerValueChange.call(this);
        // Save recent user
        var value = this.getObjectValue();
        if (Array.isArray(value)) {
            var users = value;
            var lastUsers = lastValue;
            if (!lastUsers || users.length > lastUsers.length) {
                //Only necessary if user was added
                this.recentItems.addRecentUser(users[users.length - 1]);
            }
        }
        else {
            var user = value;
            this.recentItems.addRecentUser(user);
        }
    };
    UserSelectField.prototype.render = function (container) {
        //If assignee, preselect 
        if (this.id === "assignee" && !this.options.data) {
            this.options.data = [{
                    id: -1,
                    'icon': this.avatarPath,
                    'text': 'Automatic'
                }];
        }
        _super.prototype.render.call(this, container);
        if (this.options.multiple) {
            container.append("<span style=\"display:block; padding: 5px 0px;\">\n\t\t\t\t            <a href=\"#" + this.id + "\" class=\"add-myself-trigger\" title=\"" + yasoon.i18n('dialog.addMyselfTitle') + "\">" + yasoon.i18n('dialog.addMyself') + "</a>\n                        </span>");
        }
        else {
            container.append("<span style=\"display:block; padding: 5px 0px;\">\n\t\t\t\t            <a href=\"#" + this.id + "\" class=\"assign-to-me-trigger\" title=\"" + yasoon.i18n('dialog.assignMyselfTitle') + "\">" + yasoon.i18n('dialog.assignMyself') + "</a>\n                        </span>");
        }
        if (this.id === "assignee") {
            $('#' + this.id).val('-1').trigger('change');
        }
    };
    UserSelectField.prototype.convertToSelect2 = function (user) {
        var result = {
            id: user.name,
            text: user.displayName,
            data: user
        };
        if (this.senderUser && user.name == this.senderUser.name) {
            result.iconClass = 'fa fa-envelope';
        }
        if (user.name == this.ownUser.name) {
            result.iconClass = 'fa fa-user';
        }
        return result;
    };
    UserSelectField.prototype.getReturnStructure = function (users) {
        var _this = this;
        var result = [];
        if (users) {
            result.push({
                id: 'Search',
                text: yasoon.i18n('dialog.userSearchResult'),
                children: users
            });
        }
        else {
            //Build common suggestion
            var suggestions_1 = [];
            if (this.id === 'assignee') {
                suggestions_1.push({
                    'id': '-1',
                    'icon': this.avatarPath,
                    'text': 'Automatic'
                });
            }
            suggestions_1.push(this.convertToSelect2(this.ownUser));
            if (this.senderUser) {
                suggestions_1.push(this.convertToSelect2(this.senderUser));
            }
            if (this.recentItems && this.recentItems.recentUsers) {
                var recentUsers = this.recentItems.recentUsers.map(function (item) { return _this.convertToSelect2(item); });
                //Only add recentUser if it is not senderUser;
                if (this.senderUser) {
                    recentUsers.forEach(function (user) {
                        if (user.id != _this.senderUser.name) {
                            suggestions_1.push(user);
                        }
                    });
                }
            }
            result.push({
                id: 'Suggested',
                text: yasoon.i18n('dialog.suggested'),
                children: suggestions_1
            });
        }
        return result;
    };
    UserSelectField.prototype.convertId = function (user) {
        if (!user.displayName) {
            var name_1 = (typeof user === 'string') ? user : user.name;
            return this.getData(name_1)
                .then(function (result) {
                if (result[0].children[0])
                    return result[0].children[0].data;
                else {
                    yasoon.util.log('Invalid Username: ' + user, yasoon.util.severity.warning);
                    return null;
                }
            });
        }
        return Promise.resolve(user);
    };
    UserSelectField.prototype.getData = function (searchTerm) {
        var _this = this;
        var url = '/rest/api/2/user/picker?query=' + searchTerm + '&maxResults=50';
        if (this.id === 'assignee' && this.currentProject) {
            //Only get assignable users
            url = '/rest/api/2/user/assignable/search?project=' + this.currentProject.key + '&username=' + searchTerm + '&maxResults=50';
        }
        return jiraGet(url)
            .then(function (data) {
            var users = JSON.parse(data);
            //1. Build User Result Array
            var result = [];
            //Yay, Jira change of return structure....
            var userArray = [];
            if (users && users.users && users.users.length > 0) {
                userArray = users.users;
            }
            else if (users && users.length > 0) {
                userArray = users;
            }
            userArray.forEach(function (user) {
                result.push(_this.convertToSelect2(user));
            });
            if (_this.allowNew && searchTerm.indexOf('@') > 0) {
                result.push(_this.convertToSelect2({
                    name: '<new>',
                    displayName: searchTerm + ' (new)',
                    emailAddress: searchTerm
                }));
            }
            return _this.getReturnStructure(result);
        });
    };
    UserSelectField.prototype.getEmptyData = function () {
        return Promise.resolve(this.getReturnStructure());
    };
    return UserSelectField;
}(Select2AjaxField));
UserSelectField.reporterDefaultMeta = { key: FieldController.onBehalfOfFieldId, get name() { return yasoon.i18n('dialog.behalfOf'); }, required: true, schema: { system: 'user', type: '' } };
UserSelectField = __decorate([
    getter(GetterType.Option, "name", null),
    setter(SetterType.Option)
], UserSelectField);
/// <reference path="../Field.ts" />
/// <reference path="Select2Field.ts" />
/// <reference path="../getter/GetOption.ts" />
/// <reference path="../setter/SetOptionValue.ts" />
var VersionSelectField = (function (_super) {
    __extends(VersionSelectField, _super);
    function VersionSelectField(id, field, config) {
        var _this;
        var options = {
            data: []
        };
        _this = _super.call(this, id, field, options, config.multiSelect) || this;
        _this.releasedFirst = config.releasedFirst;
        _this.init();
        return _this;
    }
    VersionSelectField.prototype.init = function () {
        var allowedValues = this.fieldMeta.allowedValues;
        var releasedVersions = allowedValues
            .filter(function (option) { return option.released && !option.archived; })
            .map(this.convertToSelect2);
        var unreleasedVersions = allowedValues
            .filter(function (option) { return !option.released && !option.archived; })
            .map(this.convertToSelect2);
        var releasedOptGroup = {
            id: 'releasedVersions',
            text: yasoon.i18n('dialog.releasedVersions'),
            children: releasedVersions
        };
        var unreleasedOptGroup = {
            id: 'unreleasedVersions',
            text: yasoon.i18n('dialog.unreleasedVersions'),
            children: unreleasedVersions
        };
        this.options.data = [];
        if (this.releasedFirst) {
            if (releasedOptGroup.children.length > 0)
                this.options.data.push(releasedOptGroup);
            if (unreleasedOptGroup.children.length > 0)
                this.options.data.push(unreleasedOptGroup);
        }
        else {
            if (unreleasedOptGroup.children.length > 0)
                this.options.data.push(unreleasedOptGroup);
            if (releasedOptGroup.children.length > 0)
                this.options.data.push(releasedOptGroup);
        }
    };
    VersionSelectField.prototype.convertToSelect2 = function (version) {
        var result = {
            id: version.id,
            text: version.name || version.value,
            data: version
        };
        if (version.iconUrl) {
            result.icon = jira.icons.mapIconUrl(version.iconUrl);
        }
        return result;
    };
    return VersionSelectField;
}(Select2Field));
VersionSelectField = __decorate([
    getter(GetterType.Option, "id", null),
    setter(SetterType.Option)
], VersionSelectField);
/// <reference path="../../JiraSelectField.ts" />
var TeamLeadCompanyField = (function (_super) {
    __extends(TeamLeadCompanyField, _super);
    function TeamLeadCompanyField(id, field, options) {
        if (options === void 0) { options = { multiple: false }; }
        var _this;
        //Filter empty element & sort
        field.allowedValues = field.allowedValues.filter(function (e) { return e.value !== 'Not defined'; }).sort(function (a, b) { return (a.value.toLowerCase() > b.value.toLowerCase()) ? 1 : -1; });
        _this = _super.call(this, id, field, options) || this;
        _this.apiKey = jira.settings.teamlead.apiKey;
        _this.ownUserKey = jira.ownUser.key || jira.ownUser.name; //Depending on version >.<
        //Start sync - don't know what it does but it sounds usefull :D
        jiraGet('/plugins/servlet/crm/api?apiKey=' + _this.apiKey + '&userName=' + _this.ownUserKey + '&command=sync');
        return _this;
    }
    TeamLeadCompanyField.prototype.getCompanyName = function (id) {
        var company = this.fieldMeta.allowedValues.filter(function (value) { return value.id === id; })[0];
        return (company) ? company.value : '';
    };
    return TeamLeadCompanyField;
}(JiraSelectField));
/// <reference path="../../JiraSelectField.ts" />
var TeamLeadContactField = (function (_super) {
    __extends(TeamLeadContactField, _super);
    function TeamLeadContactField(id, field, options) {
        if (options === void 0) { options = { multiple: false }; }
        var _this;
        field.allowedValues = field.allowedValues.sort(function (a, b) { return (a.value.toLowerCase() > b.value.toLowerCase()) ? 1 : -1; });
        _this = _super.call(this, id, field, options) || this;
        _this.apiKey = jira.settings.teamlead.apiKey;
        _this.ownUserKey = jira.ownUser.key || jira.ownUser.name; //Depending on version >.<
        //Start sync - don't know what it does but it sounds usefull :D
        jiraGet('/plugins/servlet/crm/api?apiKey=' + _this.apiKey + '&userName=' + _this.ownUserKey + '&command=sync');
        //Check if we have a dependency to a company field
        if (jira.settings.teamlead.mapping[_this.id]) {
            FieldController.registerEvent(EventType.FieldChange, _this, jira.settings.teamlead.mapping[_this.id]);
        }
        return _this;
    }
    TeamLeadContactField.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (type === EventType.FieldChange) {
            var field = FieldController.getField(source);
            var companyName = (newValue) ? field.getCompanyName(newValue.id) : '';
            return this.getContacts(companyName)
                .then(function (contacts) {
                _this.setData(contacts.map(_this.convertToSelect2));
            });
        }
        return Promise.resolve();
    };
    TeamLeadContactField.prototype.getContacts = function (companyName) {
        var _this = this;
        if (companyName) {
            return jiraGet('/plugins/servlet/crm/api?command=searchEntities&crm_param_1=Company&crm_param_1_value=' + companyName + '&tableName=CONTACTS&userName=' + this.ownUserKey + '&apiKey=' + this.apiKey)
                .then(function (contactsString) {
                var returnValue = JSON.parse(contactsString);
                var contacts = returnValue.records || [];
                var result = [];
                contacts.forEach(function (contact) {
                    var jiraContact = _this.fieldMeta.allowedValues.filter(function (element) { return element.value == contact.name; })[0];
                    if (jiraContact) {
                        result.push(jiraContact);
                    }
                });
                return result;
            });
        }
        else {
            return Promise.resolve(this.fieldMeta.allowedValues);
        }
    };
    return TeamLeadContactField;
}(JiraSelectField));
/// <reference path="../../JiraSelectField.ts" />
//In contrast to other TeamLead Fields, this one is just a string field requires contact ids in format: (id) for single fields or (id),(id), ... for multi
var TeamLeadOldContactField = (function (_super) {
    __extends(TeamLeadOldContactField, _super);
    function TeamLeadOldContactField(id, field, options) {
        if (options === void 0) { options = { multiple: false }; }
        var _this = _super.call(this, id, field, null, options.multiple) || this;
        _this.options.placeholder = (field.hasDefaultValue && !jira.isEditMode) ? yasoon.i18n('dialog.selectDefault') : yasoon.i18n('dialog.selectNone');
        _this.apiKey = jira.settings.teamlead.apiKey;
        _this.ownUserKey = jira.ownUser.key || jira.ownUser.name; //Depending on version >.<
        //Start sync - don't know what it does but it sounds usefull :D
        jiraGet('/plugins/servlet/crm/api?apiKey=' + _this.apiKey + '&userName=' + _this.ownUserKey + '&command=sync');
        _this.getContacts('')
            .then(function (contacts) {
            _this.setData(contacts.map(_this.convertToSelect2));
        });
        //Check if we have a dependency to a company field
        if (jira.settings.teamlead.mapping[_this.id]) {
            FieldController.registerEvent(EventType.FieldChange, _this, jira.settings.teamlead.mapping[_this.id]);
        }
        return _this;
    }
    TeamLeadOldContactField.prototype.init = function () {
        //Init is called automatically for each new meta --> not necessary for projects
    };
    TeamLeadOldContactField.prototype.handleEvent = function (type, newValue, source) {
        var _this = this;
        if (type === EventType.FieldChange) {
            var field = FieldController.getField(source);
            var companyName = (newValue) ? field.getCompanyName(newValue.id) : '';
            return this.getContacts(companyName)
                .then(function (contacts) {
                _this.setData(contacts.map(_this.convertToSelect2));
            });
        }
        return Promise.resolve();
    };
    TeamLeadOldContactField.prototype.getDomValue = function () {
        var result = '';
        if (this.multiple) {
            var ids = $('#' + this.id).val() || [];
            ids.forEach(function (id) {
                result = result + '(' + id + '),';
            });
        }
        else {
            var id = $('#' + this.id).val();
            if (id) {
                result = '(' + id + ')';
            }
        }
        return result;
    };
    TeamLeadOldContactField.prototype.setValue = function (value) {
        var valueString = value.replace(/\(/g, '').replace(/\)/g, '');
        if (this.multiple) {
            var ids = valueString.split(',');
            $('#' + this.id).val(ids).trigger('change');
        }
        else {
            $('#' + this.id).val(valueString).trigger('change');
        }
        return Promise.resolve();
    };
    TeamLeadOldContactField.prototype.convertToSelect2 = function (contact) {
        return {
            id: contact.id,
            text: contact.name,
            data: contact
        };
    };
    TeamLeadOldContactField.prototype.getContacts = function (companyName) {
        var prom;
        if (companyName) {
            prom = jiraGet('/plugins/servlet/crm/api?command=searchEntities&crm_param_1=Company&crm_param_1_value=' + companyName + '&tableName=CONTACTS&userName=' + this.ownUserKey + '&apiKey=' + this.apiKey)
                .then(function (contactsString) {
                var returnValue = JSON.parse(contactsString);
                var contacts = returnValue.records || [];
                return contacts;
            });
        }
        else {
            prom = jiraGet('/plugins/servlet/crm/api?apiKey=' + this.apiKey + '&userName=' + this.ownUserKey + '&command=getcontacts')
                .then(function (contactsString) {
                var returnValue = JSON.parse(contactsString);
                var contacts = returnValue.contacts || [];
                return contacts;
            });
        }
        return prom.then(function (contacts) {
            return contacts.sort(function (a, b) { return (a.name.toLowerCase() > b.name.toLowerCase()) ? 1 : -1; });
        });
    };
    return TeamLeadOldContactField;
}(Select2Field));
TeamLeadOldContactField = __decorate([
    getter(GetterType.Text)
], TeamLeadOldContactField);
/// <reference path="../../JiraSelectField.ts" />
var TeamLeadProductField = (function (_super) {
    __extends(TeamLeadProductField, _super);
    function TeamLeadProductField(id, field, options) {
        if (options === void 0) { options = { multiple: false }; }
        var _this;
        field.allowedValues = field.allowedValues.sort(function (a, b) { return (a.value.toLowerCase() > b.value.toLowerCase()) ? 1 : -1; });
        _this = _super.call(this, id, field, options) || this;
        return _this;
    }
    return TeamLeadProductField;
}(JiraSelectField));
/// <reference path="../../../Field.ts" />
/// <reference path="../../Select2AjaxField.ts" />
/// <reference path="../../../../../definitions/common.d.ts" />
/// <reference path="../../../../../definitions/bluebird.d.ts" />
/// <reference path="../../../getter/GetTextValue.ts" />
/// <reference path="../../../setter/SetOptionValue.ts" />
var TempoAccountField = (function (_super) {
    __extends(TempoAccountField, _super);
    function TempoAccountField(id, field, options) {
        if (options === void 0) { options = {}; }
        var _this;
        options.placeholder = yasoon.i18n('dialog.selectNone');
        options.allowClear = true;
        _this = _super.call(this, id, field, options) || this;
        _this.init();
        return _this;
    }
    TempoAccountField.prototype.init = function () {
        var _this = this;
        this.getData()
            .then(function (elements) {
            _this.setData(elements);
        });
    };
    TempoAccountField.prototype.convertToSelect2 = function (obj) {
        return {
            id: obj.id.toString(),
            text: obj.name,
            data: obj
        };
    };
    TempoAccountField.prototype.convertId = function (id) {
        if (id['id']) {
            return Promise.resolve(id);
        }
        else {
            return this.getAccountPromise
                .spread(function (accountData, projectAccounts) {
                var result = accountData.filter(function (acc) { return acc.id == id; });
                if (result.length === 0) {
                    result = projectAccounts.filter(function (acc) { return acc.id == id; });
                }
                return result[0];
            });
        }
    };
    TempoAccountField.prototype.getData = function () {
        var _this = this;
        this.getAccountPromise = Promise.all([
            jiraGet('/rest/tempo-accounts/1/account'),
            jiraGet('/rest/tempo-accounts/1/account/project/' + jira.selectedProject.id)
        ])
            .spread(function (accountDataString, projectAccountsString) {
            var accountData = JSON.parse(accountDataString);
            var projectAccounts = JSON.parse(projectAccountsString);
            return [accountData, projectAccounts];
        });
        return this.getAccountPromise
            .spread(function (accountData, projectAccounts) {
            var result = [];
            if (projectAccounts && projectAccounts.length > 0) {
                var childs = projectAccounts.map(_this.convertToSelect2);
                result.push({
                    id: 'projectAccounts',
                    text: yasoon.i18n('dialog.projectAccounts'),
                    children: childs
                });
            }
            if (accountData && accountData.length > 0) {
                accountData = accountData.filter(function (acc) { return acc.global; });
                if (accountData.length > 0) {
                    var accChilds = accountData.map(_this.convertToSelect2);
                    result.push({
                        id: 'globalAccounts',
                        text: yasoon.i18n('dialog.globalAccounts'),
                        children: accChilds
                    });
                }
            }
            return result;
        })
            .catch(this.handleError);
    };
    return TempoAccountField;
}(Select2Field));
TempoAccountField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.Option)
], TempoAccountField);
/// <reference path="../../../Field.ts" />
/// <reference path="../../Select2AjaxField.ts" />
/// <reference path="../../../../../definitions/common.d.ts" />
/// <reference path="../../../../../definitions/bluebird.d.ts" />
/// <reference path="../../../getter/GetTextValue.ts" />
/// <reference path="../../../setter/SetOptionValue.ts" />
var TempoTeamField = (function (_super) {
    __extends(TempoTeamField, _super);
    function TempoTeamField(id, field, options) {
        if (options === void 0) { options = {}; }
        var _this;
        options.placeholder = yasoon.i18n('dialog.selectNone');
        options.allowClear = true;
        _this = _super.call(this, id, field, options) || this;
        _this.init();
        return _this;
    }
    TempoTeamField.prototype.init = function () {
        var _this = this;
        this.getData()
            .then(function (elements) {
            _this.setData(elements);
        });
    };
    TempoTeamField.prototype.convertId = function (id) {
        return this.getTeamsPromise
            .then(function (teams) {
            return teams.filter(function (team) { return team.id == id; })[0];
        });
    };
    TempoTeamField.prototype.convertToSelect2 = function (obj) {
        return {
            id: obj.id.toString(),
            text: obj.name,
            data: obj
        };
    };
    TempoTeamField.prototype.getData = function () {
        var _this = this;
        this.getTeamsPromise = jiraGet('/rest/tempo-teams/1/team')
            .then(function (teamString) {
            var teamData = JSON.parse(teamString);
            return teamData;
        });
        return this.getTeamsPromise
            .then(function (teamData) {
            var result = [];
            if (teamData && teamData.length > 0) {
                result = teamData.map(_this.convertToSelect2);
            }
            return result;
        })
            .catch(this.handleError);
    };
    return TempoTeamField;
}(Select2Field));
TempoTeamField = __decorate([
    getter(GetterType.Text),
    setter(SetterType.Option)
], TempoTeamField);
