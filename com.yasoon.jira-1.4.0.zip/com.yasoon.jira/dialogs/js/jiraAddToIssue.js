/// <reference path="../../definitions/bluebird.d.ts" />
/// <reference path="../../definitions/jira.d.ts" />
/// <reference path="../../definitions/common.d.ts" />
/// <reference path="../../definitions/yasoon.d.ts" />
/// <reference path="./../renderer/FieldController.ts" />
/// <reference path="./../renderer/EmailController.ts" />
/// <reference path="./../renderer/RecentItemController.ts" />
/// <reference path="./../renderer/Field.ts" />
/// <reference path="./../renderer/fields/AttachmentField.ts" />
/// <reference path="./../renderer/fields/MultiLineTextField.ts" />
/// <reference path="./../renderer/fields/IssueField.ts" />
/// <reference path="./../renderer/fields/ProjectField.ts" />
var jira = null;
var AddToIssueDialog = (function () {
    function AddToIssueDialog() {
        var _this = this;
        this.icons = new JiraIconController();
        this.settings = null;
        this.mail = null;
        this.selectedText = '';
        this.cacheProjects = [];
        this.issue = null;
        this.ownUser = null;
        this.type = '';
        this.currentProject = null;
        this.currentIssue = null;
        this.init = function (initParams) {
            jira = _this; //Legacy
            _this.mail = initParams.mail;
            _this.settings = initParams.settings;
            _this.selectedText = initParams.text;
            _this.cacheProjects = initParams.projects;
            _this.issue = initParams.issue;
            _this.type = initParams.type;
            _this.ownUser = initParams.ownUser;
            //Register Close Handler
            yasoon.dialog.onClose(_this.cleanup);
            resizeWindowComment();
            setTimeout(function () { _this.initDelayed(); }, 1);
        };
        this.cleanup = function () {
            //Invalidate dialog events so the following won't throw any events => will lead to errors
            // due to pending dialog.close
            yasoon.dialog.clearEvents();
            FieldController.raiseEvent(EventType.Cleanup, null);
        };
    }
    AddToIssueDialog.prototype.initDelayed = function () {
        var _this = this;
        //Popover for Service Desk Warning
        $('.servicedesk-popover')['popover']({
            content: yasoon.i18n('dialog.serviceDeskWarningBody'),
            title: yasoon.i18n('dialog.serviceDeskWarning'),
            placement: 'top',
            html: true,
            template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title" style="background-color:#fcf8e3;"></h3><div class="popover-content"></div></div>',
            trigger: 'click' //'click'
        });
        if (this.mail) {
            this.emailController = new EmailController(this.mail, this.type, this.settings, this.ownUser);
        }
        this.recentItems = new RecentItemController(this.ownUser);
        //Render Header fields
        var projectDefaultMeta = ProjectField.defaultMeta;
        projectDefaultMeta.required = false;
        var projParams = {
            cache: this.cacheProjects,
            allowClear: false,
            isMainProjectField: true,
            showTemplates: false
        };
        FieldController.loadField(projectDefaultMeta, ProjectField, projParams);
        FieldController.render(FieldController.projectFieldId, $('#HeaderArea'));
        FieldController.loadField(IssueField.defaultMeta, IssueField);
        FieldController.render(FieldController.issueFieldId, $('#IssueArea'));
        //Render Content fields
        var commentParams = {
            hasMentions: true,
            isMainField: true
        };
        FieldController.loadField(MultiLineTextField.defaultCommentMeta, MultiLineTextField, commentParams);
        FieldController.render(FieldController.commentFieldId, $('#ContentArea'));
        var attachments = [];
        if (this.emailController) {
            attachments = this.emailController.getAttachmentFileHandles(true);
        }
        FieldController.loadField(AttachmentField.defaultMeta, AttachmentField, attachments);
        FieldController.render(FieldController.attachmentFieldId, $('#ContentArea')).then(function () { return resizeWindowComment(); });
        //Hook up events
        FieldController.registerEvent(EventType.FieldChange, this, FieldController.projectFieldId);
        FieldController.registerEvent(EventType.FieldChange, this, FieldController.issueFieldId);
        if (this.emailController) {
            this.emailController.getCurrentMailContent(true)
                .then(function (markup) {
                FieldController.setValue(FieldController.commentFieldId, markup, true);
            });
        }
        // Resize Window to maximize Comment field
        FieldController.raiseEvent(EventType.AfterRender, {});
        //Submit Button - (Create & Edit)
        $('.submit-button').off().click(function (e) { _this.submitForm(e); });
        $('#add-issue-cancel').off().click(function () {
            yasoon.dialog.close({ action: 'cancel' });
        });
    };
    AddToIssueDialog.prototype.handleEvent = function (type, newValue, source) {
        if (source === FieldController.projectFieldId) {
            this.currentProject = newValue;
        }
        else if (source === FieldController.issueFieldId) {
            this.currentIssue = newValue;
            if (newValue) {
                this.currentProject = newValue.fields.project;
            }
            $('.buttons').removeClass('servicedesk');
            $('.buttons').removeClass('no-requesttype');
            if (this.currentIssue && this.currentIssue.fields['project'] && this.currentIssue.fields['project'].projectTypeKey === 'service_desk') {
                //We have a service Project... Check if it is a service request
                jiraGet('/rest/servicedeskapi/request/' + this.currentIssue.id)
                    .then(function (data) {
                    $('.buttons').addClass('servicedesk');
                    $('.buttons').removeClass('no-requesttype');
                })
                    .catch(function (e) {
                    $('.buttons').addClass('no-requesttype');
                    $('.buttons').removeClass('servicedesk');
                });
            }
        }
        return null;
    };
    AddToIssueDialog.prototype.submitForm = function (e) {
        var _this = this;
        if (!this.currentIssue) {
            yasoon.dialog.showMessageBox(yasoon.i18n('dialog.errorSelectIssue'));
            return;
        }
        var comment = FieldController.getValue(FieldController.commentFieldId, false);
        console.log('Kommentar:', comment);
        var attachmentField = FieldController.getField(FieldController.attachmentFieldId);
        var attachments = attachmentField.getSelectedAttachments();
        if (!comment && (!attachments || attachments.length === 0)) {
            yasoon.dialog.showMessageBox(yasoon.i18n('dialog.errorNoData'));
            return;
        }
        //Prepare UI
        $('#MainAlert').addClass('hidden');
        $('#add-issue-submit').prop('disabled', true);
        $('#JiraSpinner').removeClass('hidden');
        //Todo: Add Recent Issue
        //Add Recent Project
        Promise.resolve()
            .then(function () {
            // Pre Save Event
            var lifecycleData = {
                data: {
                    comment: comment
                }
            };
            return FieldController.raiseEvent(EventType.BeforeSave, lifecycleData);
        })
            .then(function () {
            //Saving... (and AfterSave Event)
            var promises = [];
            var url = '';
            var body = null;
            var type = $(e.target).data('type'); //Type of submit button 
            if (type == 'submit') {
                url = '/rest/api/2/issue/' + _this.currentIssue.id + '/comment';
                body = { body: comment };
            }
            else if (type == 'submitCustomer') {
                url = '/rest/servicedeskapi/request/' + _this.currentIssue.key + '/comment';
                body = { body: comment, "public": true };
            }
            else if (type == 'submitInternal') {
                url = '/rest/servicedeskapi/request/' + _this.currentIssue.key + '/comment';
                body = { body: comment, "public": false };
            }
            if (comment) {
                //Upload comment
                promises.push(jiraAjax(url, yasoon.ajaxMethod.Post, JSON.stringify(body))
                    .catch(jiraSyncError, function (e) {
                    $('#MainAlert .errorText').text(yasoon.i18n('dialog.errorSubmitComment', { error: e.getUserFriendlyError() }));
                    $('#MainAlert').show();
                    yasoon.util.log('Error on sending a comment: ' + e.getUserFriendlyError(), yasoon.util.severity.info);
                    throw e;
                }));
            }
            var lifecycleData = {
                newData: _this.currentIssue
            };
            //Hmm... breaks a little the concept that attachments gets uploaded with AfterSave Event as we can do both together here in AddToIssue 
            var eventPromise = FieldController.raiseEvent(EventType.AfterSave, lifecycleData);
            if (eventPromise) {
                promises.push(eventPromise);
            }
            return Promise.all(promises);
        })
            .then(function () {
            var closeParams = {
                action: 'success',
                issueKey: _this.currentIssue.key,
                changeType: 'updated'
            };
            if (_this.mail) {
                closeParams.mail = {
                    entryId: _this.mail.entryId,
                    storeId: _this.mail.storeId
                };
            }
            yasoon.dialog.close(closeParams);
        })
            .catch(function (e) {
            console.log('Exception occured', e);
            if (e.name === 'SyncError') {
                yasoon.util.log(e.message + ' || ' + e.statusCode + ' || ' + e.errorText + ' || ' + e.result + ' || ' + e.data, yasoon.util.severity.warning);
            }
        }).finally(function () {
            $('#add-issue-submit').prop('disabled', false);
            $('#JiraSpinner').addClass('hidden');
        });
        e.preventDefault();
    };
    return AddToIssueDialog;
}());
yasoon.dialog.load(new AddToIssueDialog());
function resizeWindowComment() {
    var bodyHeight = $('body').height();
    if (bodyHeight > 584) {
        console.log('setting form body height', bodyHeight - 162);
        $('.form-body').height(bodyHeight - 162);
        //164 => Difference between Body und form-body
        //Space for project, issue and attachment field (in maximum)
        var restHeight = $('#formContent').height() - $('#comment').height() + 2;
        //200 => Min height of comment field
        //If the rest has 270 pixel, only increase the comment field
        if ($('.form-body').height() - restHeight >= 200) {
            $('#comment').height($('.form-body').height() - restHeight);
        }
    }
    else {
        $('.form-body').height(414);
        $('#comment').height(200);
    }
}
$(function () {
    $('body').css('overflow-y', 'hidden');
    $('form').on('submit', function (e) {
        e.preventDefault();
        return false;
    });
});
$(window).resize(resizeWindowComment);
//@ sourceURL=http://Jira/Dialog/jiraAddCommentDialog.js 
