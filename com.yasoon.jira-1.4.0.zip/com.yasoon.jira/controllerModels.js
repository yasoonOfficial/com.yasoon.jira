var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/// <reference path="../definitions/yasoon.d.ts" />
/// <reference path="../definitions/jira.d.ts" />
var JiraContactController = (function () {
    function JiraContactController() {
        this.buffer = [];
    }
    JiraContactController.prototype.update = function (actor) {
        if (!actor.name || !actor.displayName || !actor.emailAddress)
            return;
        var c = yasoon.contact.get(actor.name);
        var dbContact = null;
        var avatarUrl = null;
        if (actor.avatarUrls && actor.avatarUrls['48x48']) {
            avatarUrl = actor.avatarUrls['48x48'].replace('size=large', 'size=xlarge');
        }
        if (!c) {
            var newContact = {
                contactId: actor.name,
                contactLastName: actor.displayName,
                contactEmail: actor.emailAddress,
                externalData: JSON.stringify(actor),
                externalAvatarUrl: avatarUrl,
                useAuthedDownloadService: jira.settings.currentService
            };
            jiraLog('New Contact created: ', newContact);
            dbContact = yasoon.contact.add(newContact);
            this.buffer.push(dbContact);
        }
        else {
            //We don't want to override an existing avatrUrl with null
            if (!avatarUrl)
                avatarUrl = c.externalAvatarUrl;
            if (c.contactId != actor.name ||
                c.contactLastName != actor.displayName ||
                c.contactEmail != actor.contactEmailAddress ||
                c.externalAvatarUrl != avatarUrl) {
                var updContact = {
                    contactId: actor.name,
                    contactLastName: actor.displayName,
                    contactEmailAddress: actor.emailAddress,
                    externalData: JSON.stringify(actor),
                    externalAvatarUrl: avatarUrl,
                    useAuthedDownloadService: jira.settings.currentService
                };
                yasoon.contact.save(updContact);
            }
        }
    };
    JiraContactController.prototype.updateOwn = function (ownUser) {
        var avatarUrl = null;
        if (ownUser.avatarUrls && ownUser.avatarUrls['48x48']) {
            avatarUrl = ownUser.avatarUrls['48x48'].replace('size=large', 'size=xlarge');
        }
        var c = yasoon.contact.getOwnUser();
        if (!c)
            return;
        //We don't want to override an existing avatrUrl with null
        if (!avatarUrl)
            avatarUrl = c.externalAvatarUrl;
        var oldOwnUser = {};
        if (c.externalData)
            oldOwnUser = JSON.parse(c.externalData);
        if (ownUser.displayName != oldOwnUser.displayName || c.externalAvatarUrl != avatarUrl) {
            //Admins may have [Administrator] added to their name. Maybe there are more roles
            var cleanName = ownUser.displayName.replace(/\[.*\]/g, '').trim();
            var nameParts = cleanName.split(' ');
            var firstName = '';
            var lastName = '';
            if (nameParts.length === 1) {
                lastName = cleanName;
            }
            else {
                lastName = nameParts[nameParts.length - 1];
                firstName = cleanName.replace(lastName, '').trim();
            }
            c.externalAvatarUrl = avatarUrl;
            c.useAuthedDownloadService = jira.settings.currentService;
            c.contactFirstName = firstName;
            c.contactLastName = lastName;
            c.externalData = JSON.stringify(ownUser);
            yasoon.contact.updateOwnUser(c);
            yasoon.setup.updateProfile(JSON.stringify({ firstName: firstName, lastName: lastName }));
        }
    };
    JiraContactController.prototype.get = function (id) {
        var result = this.buffer.filter(function (c) { return c.contactId === id; });
        if (result.length === 1) {
            return result[0];
        }
        else {
            var res = yasoon.contact.get(id);
            if (res && res.contactId) {
                this.buffer.push(res);
            }
            return res;
        }
    };
    return JiraContactController;
}());
var JiraFilterController = (function () {
    function JiraFilterController() {
        var _this = this;
        this.values = {};
        this.filterObj = [];
        this.allFilters = [];
        this.getLabel = function (name, id, path) {
            return (_this.values[path] && _this.values[path][id]) ? _this.values[path][id] : null;
        };
    }
    JiraFilterController.prototype.register = function () {
        var _this = this;
        var backendFilterObj = [];
        this.filterObj.forEach(function (f) {
            if (_this.getSelectedFilters().indexOf(f.key) > -1) {
                var getLabelFct = (f.label) ? f.label : _this.getLabel;
                backendFilterObj.push({
                    name: f.name,
                    jsonPath: f.key,
                    label: getLabelFct
                });
            }
        });
        yasoon.feed.addFilter(backendFilterObj);
    };
    JiraFilterController.prototype.getSelectedFilters = function () {
        return jira.settings.activeFilters.split(',');
    };
    JiraFilterController.prototype.load = function () {
        var _this = this;
        var string = yasoon.setting.getAppParameter('filter');
        if (string)
            this.values = JSON.parse(string);
        this.filterObj = [
            {
                name: yasoon.i18n('filter.projectFilter'),
                key: 'fields.project.id',
                value: { type: 'json', path: 'fields.project.name' }
            },
            {
                name: yasoon.i18n('filter.typeFilter'),
                key: 'fields.issuetype.id',
                value: { type: 'json', path: 'fields.issuetype.name' }
            },
            {
                name: yasoon.i18n('filter.reporterFilter'),
                key: 'fields.reporter.emailAddress',
                value: { type: 'json', path: 'fields.reporter.displayName' }
            },
            {
                name: yasoon.i18n('filter.statusFilter'),
                key: 'fields.status.id',
                value: { type: 'json', path: 'fields.status.name' }
            },
            {
                name: yasoon.i18n('filter.priorityFilter'),
                key: 'fields.priority.id',
                value: { type: 'json', path: 'fields.priority.name' }
            },
            {
                name: yasoon.i18n('filter.assigneeFilter'),
                key: 'fields.assignee.emailAddress',
                value: { type: 'json', path: 'fields.assignee.displayName' }
            },
            {
                name: yasoon.i18n('filter.fixVersionFilter'),
                key: 'fields.fixVersions[*].id',
                value: { type: 'json', path: 'fields.fixVersions[*].name' }
            },
            {
                name: yasoon.i18n('filter.versionFilter'),
                key: 'fields.versions[*].id',
                value: { type: 'json', path: 'fields.fixVersions[*].name' }
            },
            {
                name: yasoon.i18n('filter.labelFilter'),
                key: 'fields.labels'
            },
            {
                name: yasoon.i18n('filter.componentFilter'),
                key: 'fields.components[*].id',
                value: { type: 'json', path: 'fields.components[*].name' }
            }
        ];
        //Determine allFilters
        this.filterObj.forEach(function (f) {
            _this.allFilters.push(f.key);
        });
    };
    JiraFilterController.prototype.save = function () {
        yasoon.model.feeds.updateFilter();
        yasoon.setting.setAppParameter('filter', JSON.stringify(this.values));
    };
    JiraFilterController.prototype.getJsonPathElement = function (obj, jsonPath) {
        var _this = this;
        var path = jsonPath.split('.');
        var currentObj = obj;
        //Use some so it stops after any element has returned true
        path.some(function (currentPath, i) {
            if (!currentObj)
                return true;
            //Add support for Arrays
            //Check if it has element selector [1] or all [*]
            var regex = /(.+)\[(.+)\]/;
            var regexResult = regex.exec(currentPath);
            if (regexResult) {
                //It should be an array, but it isn't
                var arrayData = currentObj[regexResult[1]];
                if (!$.isArray(arrayData)) {
                    currentObj = null;
                    return true;
                }
                if (regexResult[2] === '*') {
                    currentObj = [];
                    //Get remaining path
                    var remainingPath = '';
                    path.forEach(function (remPath, index) {
                        if (index > i) {
                            if (remainingPath)
                                remainingPath += '.';
                            remainingPath += remPath;
                        }
                    });
                    arrayData.forEach(function (o) {
                        var data = _this.getJsonPathElement(o, remainingPath);
                        if (data)
                            currentObj.push(data);
                    });
                    return true;
                }
                else {
                    //Get requested element
                    currentObj = currentObj[regexResult[1]];
                }
            }
            else {
                currentObj = currentObj[currentPath];
            }
        });
        return currentObj;
    };
    JiraFilterController.prototype.addNotif = function (obj) {
        var _this = this;
        //Go through each filter 
        var saveNeeded = false;
        this.getSelectedFilters().forEach(function (filterKey) {
            var filter = _this.filterObj.filter(function (f) { return f.key === filterKey; })[0];
            //Get Key Value for current filter
            var currentKeyObj = _this.getJsonPathElement(obj, filter.key);
            if (currentKeyObj) {
                //Get Value for current Filter
                var currentValueObj = currentKeyObj;
                if (filter.value) {
                    if (filter.value.type !== 'json') {
                        throw 'Filter Types other than json are currently not supported';
                    }
                    currentValueObj = _this.getJsonPathElement(obj, filter.value.path);
                }
                //Update Buffer
                if (!_this.values[filter.key])
                    _this.values[filter.key] = {};
                if ($.isArray(currentKeyObj)) {
                    //Add Each currentValueObj as seperate entry
                    currentKeyObj.forEach(function (key, i) {
                        if (_this.values[filter.key][key] != currentValueObj[i]) {
                            _this.values[filter.key][key] = currentValueObj[i];
                            saveNeeded = true;
                        }
                    });
                }
                else if (_this.values[filter.key][currentKeyObj] != currentValueObj) {
                    _this.values[filter.key][currentKeyObj] = currentValueObj;
                    saveNeeded = true;
                }
            }
        });
        if (saveNeeded)
            this.save();
    };
    JiraFilterController.prototype.indexPages = function (page) {
        var _this = this;
        //Add Promise to make it async. We want only want to sync 1 page and let other tasks  a chance to do something as well.
        return new Promise(function (resolve, reject) {
            setTimeout(function () {
                if (page.Items) {
                    page.Items.forEach(function (item) {
                        _this.addNotif(JSON.parse(item.externalData));
                    });
                    if (page.CurrentPage < page.TotalPages) {
                        _this.indexPages(page.nextPage())
                            .then(function () {
                            resolve();
                        });
                    }
                    else {
                        resolve();
                    }
                }
                else {
                    resolve();
                }
            }, 1);
        });
    };
    JiraFilterController.prototype.reIndex = function () {
        var _this = this;
        var newValues = {};
        return Promise.resolve()
            .then(function () {
            var page = yasoon.notification.getAll();
            return _this.indexPages(page);
        });
    };
    return JiraFilterController;
}());
/// <reference path="../definitions/common.d.ts" />
/// <reference path="../definitions/moment.d.ts" />
var JiraIssueController = (function () {
    function JiraIssueController() {
        this.issues = [];
    }
    JiraIssueController.prototype.refreshBuffer = function () {
        var _this = this;
        //Reset Buffer
        this.issues = [];
        var getIssueData = function (jql, startAt) {
            return jiraGet('/rest/api/2/search?jql=' + jql + '&fields=*all&startAt=' + startAt + '&expand=transitions,renderedFields')
                .then(function (issueData) {
                //This is one of the first calls. We may have a proxy (like starbucks) returning an XML.
                jiraCheckProxyError(issueData);
                var result = JSON.parse(issueData);
                if (result.issues && result.issues.length > 0) {
                    _this.issues = _this.issues.concat(result.issues);
                }
                if (result.total > (result.maxResults + result.startAt)) {
                    return getIssueData(jql, (result.maxResults + result.startAt));
                }
            });
        };
        //Download issues since last sync
        var lastSync = moment(jira.settings.lastSync).format('YYYY/MM/DD HH:mm');
        var jql = encodeURIComponent('updated > "' + lastSync + '"');
        return getIssueData(jql, 0)
            .catch(function (e) {
            console.log('Error:', e);
            jiraLog('Refresh Buffer Error:', e);
        });
    };
    ;
    JiraIssueController.prototype.get = function (id, bypassBuffer) {
        var _this = this;
        if (!bypassBuffer) {
            var result = this.issues.filter(function (issue) { return (issue.id === id || issue.key === id); });
            if (result.length > 0) {
                return Promise.resolve(result[0]);
            }
        }
        return jiraGet('/rest/api/2/issue/' + id + '?expand=transitions,renderedFields') //,schema,editmeta,names
            .then(function (issueData) {
            var issue = JSON.parse(issueData);
            if (!bypassBuffer)
                _this.issues.push(issue);
            return issue;
        });
    };
    ;
    JiraIssueController.prototype.all = function () {
        return this.issues;
    };
    JiraIssueController.prototype.isResolved = function (issue) {
        if (issue.fields && issue.fields.resolution) {
            return true;
        }
        return false;
    };
    return JiraIssueController;
}());
var JiraNotification = (function () {
    function JiraNotification() {
    }
    JiraNotification.prototype.createNotification = function () {
    };
    return JiraNotification;
}());
//@ sourceURL=http://Jira/controllerModels.js 
// Type definitions for Bootstrap 3.3.5
// Project: http://twitter.github.com/bootstrap/
// Definitions by: Boris Yankov <https://github.com/borisyankov/>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
/// <reference path="../definitions/functions.d.ts" />
/// <reference path="../definitions/yasoon.d.ts" />
var JiraIssueAppointment = (function () {
    function JiraIssueAppointment(issue) {
        this.issue = issue;
    }
    JiraIssueAppointment.prototype.save = function () {
        var _this = this;
        if (!jira.settings.syncCalendar)
            return Promise.resolve();
        if (!this.issue.fields.duedate)
            return Promise.resolve();
        //Check if it's an update or creation
        return jiraGetCalendarItem(this.issue.id)
            .then(function (dbItem) {
            var creation = false;
            if (!dbItem) {
                //Creation
                creation = true;
                dbItem = { categories: ['Jira', _this.issue.fields.project.name] };
            }
            dbItem.subject = _this.issue.fields.summary;
            dbItem.body = _this.issue.this + ' \n\r ' + (_this.issue.fields.description || '');
            //Even though "normal" js date supports conversion for full dates with timezone,
            // it messes up dates without any time (all day events)
            //CustomField: customfield_10201
            //Estimate: timtracking.remainingEstimateSeconds
            dbItem.endDate = moment(_this.issue.fields.duedate).add(17, 'hour').toDate();
            //Calc Startdate
            var startDate = moment(_this.issue.fields.duedate).add(16, 'hour').toDate(); //Default 1 hour
            if (_this.issue.fields.timetracking && _this.issue.fields.timetracking.remainingEstimateSeconds) {
                //Split into full Working days (8 hours) and single hours
                var fullDays = Math.floor(_this.issue.fields.timetracking.remainingEstimateSeconds / 28800);
                var hours = (_this.issue.fields.timetracking.remainingEstimateSeconds % 28800) / 3600;
                if (hours > 0) {
                    startDate = moment(_this.issue.fields.duedate).add((17 - hours), 'hour').subtract(fullDays, 'days').toDate();
                }
                else {
                    startDate = moment(_this.issue.fields.duedate).add(9, 'hour').subtract(fullDays - 1, 'days').toDate();
                }
            }
            else if (_this.issue.fields.customfield_10201) {
                startDate = moment(_this.issue.fields.customfield_10201).add(9, 'hour').toDate();
            }
            dbItem.startDate = startDate;
            dbItem.isHtmlBody = false;
            dbItem.externalId = _this.issue.id;
            //Really needed?!
            dbItem.externalData = JSON.stringify(_this.issue);
            if (creation)
                return jiraAddCalendarItem(dbItem);
            else
                return jiraSaveCalendarItem(dbItem);
        });
    };
    return JiraIssueAppointment;
}());
/// <reference path="notification.ts" />
/// <reference path="../definitions/common.d.ts" />
/// <reference path="../definitions/moment.d.ts" />
/// <reference path="../definitions/bootstrap.ts" />
/// <reference path="../definitions/yasoon.d.ts" />
/// <reference path="issueAppointment.ts" />
var JiraIssueNotification = (function (_super) {
    __extends(JiraIssueNotification, _super);
    function JiraIssueNotification(issue) {
        var _this = _super.call(this) || this;
        _this.issue = issue;
        _this.worklogOpenInProgress = false;
        _this.searchUser = function (mode, query, callback) {
            //console.log('Search User');
            jiraGet('/rest/api/2/user/viewissue/search?issueKey=' + _this.issue.key + '&projectKey=' + _this.issue.fields.project.key + '&maxResults=10&username=' + query)
                .then(function (userJson) {
                //console.log('Result:',users);
                var data = [];
                var users = JSON.parse(userJson);
                users.forEach(function (user) {
                    data.push({ id: user.name, name: user.displayName, type: 'user' });
                });
                callback(data);
            });
        };
        _this.addAttachment = function () {
            if (!jiraIsLicensed(true)) {
                return;
            }
            yasoon.view.fileChooser.open(function (selectedFiles) {
                var formData = [];
                jiraLog('Jira: ', selectedFiles);
                $.each(selectedFiles, function (i, file) {
                    formData.push({
                        type: yasoon.formData.File,
                        name: 'file',
                        value: file
                    });
                });
                jiraAjax('/rest/api/2/issue/' + _this.issue.id + '/attachments', yasoon.ajaxMethod.Post, null, formData)
                    .then(function () {
                    jira.sync();
                })
                    .catch(jiraSyncError, jira.notifications.handleAttachmentError);
            });
        };
        _this.editIssue = function (callback) {
            if (!jiraIsLicensed(true)) {
                return;
            }
            var cbk = callback || jira.ribbons.ribbonOnCloseNewIssue;
            yasoon.dialog.open({
                width: 725,
                height: 700,
                title: yasoon.i18n('dialog.editJiraIssueDialogTitle'),
                resizable: true,
                htmlFile: 'dialogs/jiraNewEditIssue.html',
                initParameter: {
                    'settings': jira.settings,
                    'ownUser': jira.data.ownUser,
                    'editIssueId': _this.issue.id,
                    'systemInfo': jira.sysInfo,
                    'projects': jira.data.projects
                },
                closeCallback: cbk
            });
        };
        _this.logWork = function () {
            if (_this.worklogOpenInProgress)
                return;
            _this.worklogOpenInProgress = true;
            jira.notifications.loadWorklogTemplate(_this.issue.key, _this.issue.id, _this.openLogWorkDialog);
        };
        return _this;
    }
    JiraIssueNotification.prototype.isSyncNeeded = function () {
        var _this = this;
        var found = false;
        //Do not sync 
        if (jira.settings.syncFeed == 'off')
            return false;
        //Do not sync epics
        if (this.issue.fields.issuetype && this.issue.fields.issuetype.iconUrl.indexOf('ico_epic.png') > -1) {
            return false; //Do not sync Epics
        }
        //Check if Issue is relevant
        //Check if issue exist
        var issue = yasoon.notification.getByExternalId(this.issue.id);
        if (issue) {
            jiraLog('Issue already exist');
            return true;
        }
        //Check if I'm creator , reporter or assignee
        if (this.issue.fields.creator && this.issue.fields.creator.name === jira.data.ownUser.name && jira.settings.showFeedCreator) {
            jiraLog('creator equals');
            return true;
        }
        if (this.issue.fields.reporter && this.issue.fields.reporter.name === jira.data.ownUser.name && jira.settings.showFeedReporter) {
            jiraLog('reporter equals');
            return true;
        }
        if (this.issue.fields.assignee && this.issue.fields.assignee.name === jira.data.ownUser.name && jira.settings.showFeedAssignee) {
            jiraLog('assignee equals');
            return true;
        }
        //Am I watcher?
        if (this.issue.fields.watches && this.issue.fields.watches.isWatching && jira.settings.showFeedWatcher) {
            jiraLog('Found in Watchers');
            return true;
        }
        //Is it my own project? --> find project in buffer
        if (jira.data.projects && jira.settings.showFeedProjectLead) {
            var proj = jira.data.projects.filter(function (project) { return _this.issue.fields.project.id === project.id; })[0];
            if (proj && proj.lead && proj.lead.name === jira.data.ownUser.name) {
                jiraLog('Project Lead equals');
                return true;
            }
        }
        //Did I make a comment or have I been mentioned in a comment?
        if (this.issue.fields.comment && this.issue.fields.comment.comments) {
            found = false;
            this.issue.fields.comment.comments.forEach(function (comment) {
                if (comment.author && comment.author.name === jira.data.ownUser.name && jira.settings.showFeedComment) {
                    found = true;
                    return false;
                }
                if (comment.body && comment.body.indexOf('[~' + jira.data.ownUser.name + ']') > -1 && jira.settings.showFeedMentioned) {
                    found = true;
                    return false;
                }
            });
            if (found) {
                jiraLog('Found in Comments');
                return true;
            }
        }
        return false;
    };
    JiraIssueNotification.prototype.renderTitle = function (feed) {
        var html = '<span>';
        if (this.issue.fields.priority) {
            var icon = jira.icons.mapIconUrl(this.issue.fields.priority.iconUrl);
            html += '<img style="margin-right: 5px; width: 16px;" src="' + icon + '" /> ';
        }
        html += this.issue.key + ': ' + this.issue.fields.summary + '</span>';
        feed.setTitle(html);
    };
    JiraIssueNotification.prototype.renderBody = function (feed) {
        //Transform data
        if (this.issue.fields.attachment) {
            this.issue.fields.attachment.forEach(function (att) {
                att.fileIcon = yasoon.io.getFileIconPath(att.mimeType);
            });
        }
        //Map known images
        if (this.issue.fields.issuetype) {
            this.issue.fields.issuetype.iconUrl = jira.icons.mapIconUrl(this.issue.fields.issuetype.iconUrl);
        }
        if (this.issue.fields.priority) {
            this.issue.fields.priority.iconUrl = jira.icons.mapIconUrl(this.issue.fields.priority.iconUrl);
        }
        if (this.issue.fields.status) {
            this.issue.fields.status.iconUrl = jira.icons.mapIconUrl(this.issue.fields.status.iconUrl);
        }
        //Get Contacts
        var assignee, creator;
        if (this.issue.fields.assignee)
            assignee = jira.contacts.get(this.issue.fields.assignee.name);
        if (this.issue.fields.creator)
            creator = jira.contacts.get(this.issue.fields.creator.name);
        //Transform Dates
        if (this.issue.renderedFields.duedate)
            this.issue.renderedFields.duedate = moment(new Date(this.issue.fields.duedate)).format('L');
        if (this.issue.renderedFields.resolutiondate)
            this.issue.renderedFields.resolutiondate = moment(new Date(this.issue.fields.resolutiondate)).format('L');
        //Start rendering
        feed.setTemplate('templates/issueNotification.handlebars', {
            fields: this.issue.fields,
            renderedFields: this.issue.renderedFields,
            assignee: {
                avatarUrl: (assignee) ? assignee.ImageURL : yasoon.io.getLinkPath('Images\\useravatar.png'),
                displayName: (this.issue.fields.assignee) ? this.issue.fields.assignee.displayName : yasoon.i18n('notification.nobody')
            },
            creator: {
                avatarUrl: (creator) ? creator.ImageURL : yasoon.io.getLinkPath('Images\\useravatar.png'),
                displayName: (this.issue.fields.creator) ? this.issue.fields.creator.displayName : '-'
            },
            baseUrl: jira.settings.baseUrl
        });
    };
    JiraIssueNotification.prototype.setProperties = function (feed) {
        var _this = this;
        feed.properties.actionComment = { type: "plain", attachments: false, mentions: this.searchUser };
        feed.properties.customActions = [];
        feed.properties.customLabels = [{ description: this.issue.fields.project.name, labelColor: '#D87F47', url: jira.settings.baseUrl + '/browse/' + this.issue.fields.project.key }];
        //Add Components
        if (this.issue.fields.components) {
            this.issue.fields.components.forEach(function (comp) {
                feed.properties.customLabels.push({ description: comp.name, labelColor: '#0B96AA', url: jira.settings.baseUrl + '/issues/?jql=project+%3D+' + _this.issue.fields.project.key + '+AND+component+%3D+' + comp.id });
            });
        }
        //Add Labels
        if (this.issue.fields.labels) {
            this.issue.fields.labels.forEach(function (label) {
                feed.properties.customLabels.push({ description: label });
            });
        }
        //Add Actions
        feed.properties.customActions.push({
            description: '<span><i class="fa fa-external-link"></i> ' + yasoon.i18n('notification.openAction') + '</span>',
            url: jira.settings.baseUrl + '/browse/' + this.issue.key
        });
        var changeStatusHtml = '' +
            '<span style="position:relative;">' +
            '   <span class="dropdown-toggle" data-toggle="dropdown">' +
            '       <span><i class="fa fa-sign-in"></i> <span class="transitionChangeLabel">' + yasoon.i18n('notification.setStatusAction') + '</span></span>' +
            '       <span class="caret"></span>' +
            '   </span>' +
            '   <ul class="dropdown-menu" role="menu">';
        this.issue.transitions.forEach(function (transition) {
            changeStatusHtml += '<li><a class="jiraStatusChangeLink" data-transition="' + transition.id + '" data-key="' + _this.issue.key + '" data-issue-id="' + _this.issue.id + '">' + transition.name + '</a></li>';
        });
        changeStatusHtml += '' +
            '   </ul>' +
            '</span>';
        feed.properties.customActions.push({ description: changeStatusHtml, eventHandler: function () { } });
        feed.properties.customActions.push({ description: '<span><i class="fa fa-paperclip"></i> ' + yasoon.i18n('notification.addFileAction') + '</span>', eventHandler: this.addAttachment });
        feed.properties.customActions.push({ description: '<span><i class="fa fa-pencil"></i> ' + yasoon.i18n('notification.editAction') + '</span>', eventHandler: this.editIssue });
        feed.properties.customActions.push({ description: '<span data-key="' + this.issue.key + '" ><i class="fa fa-clock-o"></i> ' + yasoon.i18n('notification.logWorkAction') + '</span>', eventHandler: this.logWork, issueKey: this.issue.key });
        feed.properties.baseUrl = jira.settings.baseUrl;
        feed.setProperties(feed.properties);
        var icon_url = yasoon.io.getLinkPath('Task-03.png');
        //In JIRA 7 issue types icons are svg so we can display them in the feed
        if (jiraIsVersionHigher(jira.sysInfo, '7')) {
            icon_url = jira.icons.mapIconUrl(this.issue.fields.issuetype.iconUrl);
        }
        feed.setIconHtml('<img src="' + icon_url + '" title="' + this.issue.fields.issuetype.name + '" ></i>');
        feed.afterRenderScript(function () {
            $('[data-feed-id=' + feed.feedId + ']').find('.jiraStatusChangeLink').off().click(function () {
                if (!jiraIsLicensed(true)) {
                    return;
                }
                var element = $(this);
                //Get all data
                var transitionId = element.data('transition');
                var bodyObj = {
                    "transition": {
                        "id": transitionId
                    }
                };
                var key = element.data('key');
                var id = element.data('issueId');
                var body = JSON.stringify(bodyObj);
                //Show user something is happening...
                $('[data-feed-id=' + feed.feedId + ']').find('.transitionChangeLabel').text(yasoon.i18n('notification.updating')).prop('disabled', true);
                //Get latest transition information
                jiraGet('/rest/api/2/issue/' + key + '/transitions?transitionId=' + transitionId)
                    .then(function (data) {
                    var transObj = JSON.parse(data);
                    if (transObj.transitions && transObj.transitions.length === 0) {
                        yasoon.alert.add({ type: yasoon.alert.alertType.error, message: yasoon.i18n('notification.changeStatusNotPossible', { error: 'Transition does not exist in current context anymore! Refresh the feed.' }) });
                        yasoon.util.log('Transition not found for transition Id ' + transitionId + ' || ' + JSON.stringify(transObj), yasoon.util.severity.warning);
                        return;
                    }
                    if (transObj.transitions[0].hasScreen) {
                        yasoon.openBrowser(jira.settings.baseUrl + '/login.jsp?os_destination=' + encodeURIComponent('/secure/CommentAssignIssue!default.jspa?id=' + id + '&action=' + transitionId));
                    }
                    else {
                        return jiraAjax('/rest/api/2/issue/' + key + '/transitions', yasoon.ajaxMethod.Post, body)
                            .then(function () {
                            yasoon.feed.allowUpdate(feed.feedId);
                            return jira.sync();
                        });
                    }
                })
                    .catch(function (error) {
                    var msg = (error.getUserFriendlyError) ? error.getUserFriendlyError() : error;
                    yasoon.alert.add({ type: yasoon.alert.alertType.error, message: yasoon.i18n('notification.changeStatusNotPossible', { error: msg }) });
                    yasoon.util.log('Unexpected error in Set Status Feed Action: ' + error, yasoon.util.severity.error, getStackTrace(error));
                })
                    .finally(function () {
                    $('[data-feed-id=' + feed.feedId + ']').find('.transitionChangeLabel').text(yasoon.i18n('notification.setStatusAction')).prop('disabled', false);
                });
            });
            $('[data-feed-id=' + feed.feedId + ']').find('.jiraFeedExpand').off().click(function () {
                $(this).parents('.body-collapsed').hide();
                $(this).parents('.jiraContainer').find('.body-open').show();
            });
            $('[data-feed-id=' + feed.feedId + ']').find('.jiraFeedClose').off().click(function () {
                $(this).parents('.body-open').hide();
                $(this).parents('.jiraContainer').find('.body-collapsed').show();
            });
        });
    };
    JiraIssueNotification.prototype.save = function () {
        var _this = this;
        if (!this.isSyncNeeded()) {
            return;
        }
        //Save contacts
        if (this.issue.fields.assignee)
            jira.contacts.update(this.issue.fields.assignee);
        if (this.issue.fields.creator)
            jira.contacts.update(this.issue.fields.creator);
        if (this.issue.fields.reporter)
            jira.contacts.update(this.issue.fields.reporter);
        //Download icons if necessary
        if (this.issue.fields.issuetype) {
            jira.icons.addIcon(this.issue.fields.issuetype.iconUrl);
        }
        if (this.issue.fields.priority) {
            jira.icons.addIcon(this.issue.fields.priority.iconUrl);
        }
        return jiraGetNotification(this.issue.id)
            .then(function (yEvent) {
            var creation = false;
            if (!yEvent) {
                //New Notification
                yEvent = {};
                creation = true;
            }
            else if (yEvent.createdAt.getTime() >= new Date(_this.issue.fields.updated).getTime()) {
                //not new and no update needed
                return yEvent;
            }
            else {
                _this.issue.childrenLoaded = JSON.parse(yEvent.externalData).childrenLoaded; // Take over childrenLoaded flag from old Entity
            }
            //Description is sometimes an object. WTF?! check for it and log so we can probably figure out what's inside
            var content = yasoon.i18n('notification.noContent');
            if (_this.issue.fields.description && typeof _this.issue.fields.description != 'string') {
                try {
                    yasoon.util.log('Description Object found:' + JSON.stringify(_this.issue.fields.description) + ' --> Rendered Description: ' + JSON.stringify(_this.issue.renderedFields.description));
                }
                catch (e) {
                }
            }
            else {
                if (_this.issue.fields.description && _this.issue.fields.description.trim()) {
                    content = _this.issue.fields.description.trim();
                }
            }
            yEvent.content = content;
            yEvent.title = _this.issue.fields.summary;
            yEvent.type = 1;
            yEvent.createdAt = new Date(_this.issue.fields.updated);
            yEvent.contactId = ((_this.issue.fields.creator) ? _this.issue.fields.creator.name : ((_this.issue.fields.reporter) ? _this.issue.fields.reporter.name : ''));
            yEvent.externalId = _this.issue.id;
            yEvent.isRead = true;
            _this.issue.type = 'issue';
            /* Clean up data to save DB space */
            yEvent.externalData = JSON.stringify(jiraMinimizeIssue(_this.issue));
            jira.filter.addNotif(_this.issue);
            if (creation) {
                return jiraAddNotification(yEvent)
                    .then(function (newNotif) {
                    jira.notifications.queueChildren(_this.issue); // Trigger Sync of all children. If successfull it will set childrenLoaded!
                    //return newNotif;
                    return new JiraIssueAppointment(_this.issue).save()
                        .then(function () {
                        return newNotif;
                    });
                });
            }
            else {
                return jiraSaveNotification(yEvent)
                    .then(function (newNotif) {
                    if (!_this.issue.childrenLoaded)
                        jira.notifications.queueChildren(_this.issue); // Trigger Sync of all children. If successfull it will set childrenLoaded!
                    //return newNotif;
                    return new JiraIssueAppointment(_this.issue).save()
                        .then(function () {
                        return newNotif;
                    });
                });
            }
        });
    };
    JiraIssueNotification.prototype.openLogWorkDialog = function () {
        this.worklogOpenInProgress = false;
        $('#jiraAddWorklog').modal('show');
        $('#jiraAddWorklog').on('shown.bs.modal', function () {
            var contentHeight = $('#jiraAddWorklog').find('.modal-content').height();
            contentHeight = contentHeight - 56 - 74 - 25; //Height of header / footer;
            $('#jiraAddWorklog').find('.modal-body').height(contentHeight);
        });
    };
    return JiraIssueNotification;
}(JiraNotification));
/// <reference path="../definitions/yasoon.d.ts" />
/// <reference path="notification.ts" />
var JiraIssueActionNotification = (function (_super) {
    __extends(JiraIssueActionNotification, _super);
    function JiraIssueActionNotification(event) {
        var _this = _super.call(this) || this;
        _this.event = event;
        return _this;
    }
    JiraIssueActionNotification.prototype.isSyncNeeded = function () {
        return true;
    };
    JiraIssueActionNotification.prototype.renderBody = function (feed) {
        var html;
        if (this.event.type === 'IssueComment') {
            html = '<span>' + this.event.renderedComment.body + '</span>';
        }
        else if (this.event.title) {
            html = '<span>' + this.event.title['#text'] + '</span>';
            var title = null;
            if (this.event.content) {
                title = $('<div></div>').html(this.event.content['#text']).text().trim().replace(/>/g, '&gt;');
                if (!title && this.event['activity:object']) {
                    if ($.isArray(this.event['activity:object'])) {
                        //Can be an array (e.g. if mutiple files has been uploaded at once.
                        title = '';
                        this.event['activity:object'].forEach(function (elem) {
                            if (title)
                                title += ', ';
                            title += elem.title['#text'].trim();
                        });
                    }
                    else {
                        title = this.event['activity:object'].title['#text'].trim();
                    }
                }
            }
            if (title)
                html += '<span class="small yasoon-tooltip" style="cursor:pointer;" data-toggle="tooltip" data-html="true" title="' + title + '">( <i class="fa fa-exclamation-circle"></i> ' + yasoon.i18n('feed.more') + ')</span>';
        }
        else {
            yasoon.util.log('Coulnd\'t determine title for:' + JSON.stringify(this.event), yasoon.util.severity.error);
        }
        feed.setContent(html);
    };
    JiraIssueActionNotification.prototype.setProperties = function (feed) {
        var iconHtml = null;
        var obj = JSON.parse(feed.externalData);
        if (obj.category) {
            if (obj.category['@attributes'].term === 'created') {
                iconHtml = '<i class="fa fa-plus-circle" style="color:grey;"></i>';
            }
            else if (obj.category['@attributes'].term === 'started') {
                iconHtml = '<i class="fa fa-caret-square-o-right" style="color:grey;"></i>';
            }
            else if (obj.category['@attributes'].term === 'started') {
                iconHtml = '<i class="fa fa-caret-square-o-right" style="color:grey;"></i>';
            }
        }
        if (!iconHtml && obj['activity:verb']) {
            var activityLookup = {};
            //Convert Datatstructure. Can be either a single object or array :(
            if (obj['activity:verb'].length > 1) {
                for (var i = 0, len = obj['activity:verb'].length; i < len; i++) {
                    activityLookup[obj['activity:verb'][i]['#text']] = obj['activity:verb'][i];
                }
            }
            else if (obj['activity:verb'].length === 1) {
                activityLookup[obj['activity:verb']['#text']] = obj['activity:verb'];
            }
            //Now check for value
            if (activityLookup['http://streams.atlassian.com/syndication/verbs/jira/transition']) {
                iconHtml = '<i class="fa fa-cog" style="color:grey;"></i>';
            }
            else if (activityLookup['http://activitystrea.ms/schema/1.0/update'] && obj['activity:verb'].length === 1) {
                iconHtml = '<i class="fa fa-pencil" style="color:grey;"></i>';
            }
        }
        if (!iconHtml) {
            iconHtml = '<i class="fa fa-info-circle" style="color:grey;"></i>';
        }
        feed.setIconHtml(iconHtml);
    };
    JiraIssueActionNotification.prototype.renderTitle = function (feed) {
    };
    JiraIssueActionNotification.prototype.save = function () {
        var _this = this;
        return Promise.resolve()
            .then(function () {
            //Get issue
            var issueKey = '';
            if (_this.event.type === 'IssueComment')
                issueKey = _this.event.issue.id;
            else
                issueKey = (_this.event['activity:target']) ? _this.event['activity:target'].title['#text'] : _this.event['activity:object'].title['#text'];
            return jira.issues.get(issueKey);
        })
            .then(function (issue) {
            _this.event.issue = issue;
            if (!_this.isSyncNeeded()) {
                return;
            }
            //Save Issue first
            return jira.notifications.createNotification(_this.event.issue).save();
        })
            .then(function (notif) {
            if (!notif) {
                return;
            }
            //Save Activity Notification
            var isComment = (_this.event.category && _this.event.category['@attributes'].term === 'comment');
            var comment = null;
            if (isComment && _this.event.issue.fields.comment) {
                comment = _this.event.issue.fields.comment.comments.filter(function (c) {
                    //Fake Action has commentId Attribute
                    if (_this.event.commentId) {
                        return _this.event.commentId === c.id;
                    }
                    else {
                        //Standard ones only have them in the URL!
                        return (_this.event['activity:object'].link['@attributes'].href.indexOf('comment-' + c.id) > -1);
                    }
                })[0];
            }
            //this.event.id can be null :o 
            var externalId = '';
            if (comment && comment.id) {
                externalId = 'c' + comment.id;
            }
            else if (_this.event.id) {
                externalId = _this.event.id['#text'];
            }
            else {
                var logObj = JSON.parse(JSON.stringify(_this.event));
                delete logObj.issue;
                yasoon.util.log('Action found that is neither an comment, nor an normal activity:' + JSON.stringify(logObj), yasoon.util.severity.error);
                return;
            }
            return jiraGetNotification(externalId)
                .then(function (yEvent) {
                if (isComment) {
                    jiraLog('Save Comment');
                    return _this.saveComment(yEvent, notif, comment);
                }
                else {
                    jiraLog('Save Action');
                    return _this.saveAction(yEvent, notif);
                }
            });
        });
    };
    JiraIssueActionNotification.prototype.saveComment = function (yEvent, parent, comment) {
        var _this = this;
        var creation = false;
        if (!comment) {
            //Timing Issue! Comment has been retrieved via feed, but not via Rest API.
            yasoon.util.log('Comments inconsistency! Comment retrieved by feed but not via REST API.', yasoon.util.severity.error);
            return;
        }
        jiraLog('Comment Save', { event: yEvent, parent: parent });
        if (!yEvent && parent) {
            //New Notification
            yEvent = {};
            creation = true;
        }
        else {
            //not new - update needed?
            if (!comment || yEvent.createdAt >= new Date(comment.updated)) {
                return;
            }
        }
        ////Update Author
        jira.contacts.update(comment.updateAuthor);
        //Determine Renderd Comment
        var renderedComment = this.event.issue.renderedFields.comment.comments.filter(function (c) { return c.id === comment.id; })[0];
        yEvent.parentNotificationId = parent.notificationId;
        yEvent.externalId = 'c' + comment.id;
        //"Render" title for desktop notification
        yEvent.title = yasoon.i18n('notification.commentedOn', {
            name: comment.updateAuthor.displayName,
            text: this.event.issue.fields.summary
        });
        yEvent.content = (renderedComment.body) ? renderedComment.body : yasoon.i18n('notification.noContent');
        yEvent.contactId = comment.updateAuthor.name;
        yEvent.createdAt = new Date(comment.updated);
        yEvent.type = 1;
        yEvent.externalData = JSON.stringify({
            comment: comment,
            renderedComment: renderedComment,
            type: 'IssueComment'
        });
        if (creation) {
            return jiraAddNotification(yEvent)
                .then(function (newNotif) {
                jira.notifications.addDesktopNotification(newNotif, _this.event);
            });
        }
        else {
            return jiraSaveNotification(yEvent)
                .then(function (newNotif) {
                jira.notifications.addDesktopNotification(newNotif, _this.event);
            });
        }
    };
    ;
    JiraIssueActionNotification.prototype.saveAction = function (yEvent, parent) {
        var creation = false;
        if (!yEvent && parent) {
            //New Notification
            yEvent = {};
            creation = true;
        }
        else if (yEvent.createdAt >= new Date(this.event.updated['#text'])) {
            return;
        }
        //Update Author
        jira.contacts.update({
            displayName: (this.event.author.name) ? this.event.author.name['#text'] : '',
            name: (this.event.author['usr:username']) ? this.event.author['usr:username']['#text'] : '',
            emailAddress: (this.event.author.email) ? this.event.author.email['#text'] : '',
            avatarUrls: { '48x48': ((this.event.author.link && this.event.author.link[1]) ? this.event.author.link[1].href : '') }
        });
        yEvent.parentNotificationId = parent.notificationId;
        yEvent.externalId = this.event.id['#text'];
        yEvent.title = $('<div>' + this.event.title['#text'] + '</div>').text();
        yEvent.content = (yEvent.title) ? yEvent.title : yasoon.i18n('notification.noContent');
        yEvent.contactId = (this.event.author['usr:username']) ? this.event.author['usr:username']['#text'] : '';
        yEvent.createdAt = new Date(this.event.updated['#text']);
        yEvent.type = 2;
        yEvent.isRead = (yEvent.contactId == jira.data.ownUser.key);
        this.event.type = 'IssueAction';
        ///* Clear unused data to save DB space*/
        var minEvent = jiraMinimizeIssue(this.event); // Performance Intensive but nessecary. Never change original object
        delete minEvent.issue.fields;
        delete minEvent.issue.renderedFields;
        delete minEvent.issue.transitions;
        delete minEvent.link;
        yEvent.externalData = JSON.stringify(minEvent);
        if (creation) {
            return jiraAddNotification(yEvent)
                .then(function (newNotif) {
                jira.notifications.addDesktopNotification(newNotif, minEvent);
            });
        }
        else {
            return jiraSaveNotification(yEvent)
                .then(function (newNotif) {
                jira.notifications.addDesktopNotification(newNotif, minEvent);
            });
        }
    };
    return JiraIssueActionNotification;
}(JiraNotification));
/// <reference path="../definitions/jira.d.ts" />
/// <reference path="../definitions/common.d.ts" />
/// <reference path="../definitions/functions.d.ts" />
/// <reference path="../models/issueNotification.ts" />
/// <reference path="../models/issueActionNotification.ts" />
var JiraNotificationController = (function () {
    function JiraNotificationController() {
        var _this = this;
        this.notificationCounter = 0;
        this.notification = null;
        this.notificationEvent = null;
        this.queueProcessingRunning = false;
        this.childQueue = [];
        this.worklogTemplateLoaded = false;
        this.worklogTemplate = null;
        this.addComment = function (parent, comment, successCbk, attachments, errorCbk) {
            if (!jiraIsLicensed(true)) {
                return errorCbk();
            }
            try {
                //check comment for mention
                comment = comment.replace(/@.*?\]\(user:([^\)]+)\)/g, '[~$1]');
                var body = JSON.stringify({
                    "body": comment
                });
                var issue = JSON.parse(parent.externalData);
                return jiraAjax('/rest/api/2/issue/' + issue.key + '/comment', yasoon.ajaxMethod.Post, body)
                    .then(function (data) {
                    successCbk();
                    yasoon.feed.allowUpdate(parent.feedId);
                    jira.sync();
                })
                    .catch(function (e) {
                    _this.handleCommentError(e);
                    if (errorCbk)
                        errorCbk();
                });
            }
            catch (e) {
                if (errorCbk)
                    errorCbk();
                throw e;
            }
        };
        this.renderNotification = function (feed) {
            var event = _this.createNotification(JSON.parse(feed.externalData));
            if (event) {
                event.renderBody(feed);
                event.renderTitle(feed);
                event.setProperties(feed);
            }
        };
    }
    JiraNotificationController.prototype.handleCommentError = function (error) {
        var errorMessage = (error.statusCode === 500) ? yasoon.i18n('feed.connectionToJiraNotPossible') : error.errorText;
        yasoon.alert.add({ type: yasoon.alert.alertType.error, message: yasoon.i18n('feed.couldNotCreateComment') + ': ' + errorMessage });
    };
    JiraNotificationController.prototype.handleAttachmentError = function (error) {
        var errorMessage = (error.statusCode === 500) ? yasoon.i18n('feed.connectionToJiraNotPossible') : error.errorText;
        yasoon.alert.add({ type: yasoon.alert.alertType.error, message: yasoon.i18n('feed.couldNotUploadAttachments') + ': ' + errorMessage });
    };
    JiraNotificationController.prototype.createNotification = function (event) {
        var result = null;
        if (event.type) {
            if (event.type === 'issue') {
                result = new JiraIssueNotification(event);
            }
            else if (event.type === 'IssueAction') {
                result = new JiraIssueActionNotification(event);
            }
            else if (event.type === 'IssueComment') {
                result = new JiraIssueActionNotification(event);
            }
        }
        else {
            if (event['activity:target']) {
                if (event['activity:target']['activity:object-type'] && event['activity:target']['activity:object-type']['#text'] === 'http://streams.atlassian.com/syndication/types/issue') {
                    result = new JiraIssueActionNotification(event);
                }
            }
            else if (event['activity:object']) {
                if (event['activity:object']['activity:object-type'] && event['activity:object']['activity:object-type']['#text'] === 'http://streams.atlassian.com/syndication/types/issue') {
                    result = new JiraIssueActionNotification(event);
                }
            }
            else if (event.fields) {
                result = new JiraIssueNotification(event);
            }
        }
        return result;
    };
    JiraNotificationController.prototype.addDesktopNotification = function (notif, event) {
        if (jira.settings.showDesktopNotif && notif.contactId != jira.data.ownUser.key && !this.queueProcessingRunning) {
            yasoon.notification.incrementCounter();
            this.notificationCounter++;
            this.notification = notif;
            this.notificationEvent = event;
        }
    };
    JiraNotificationController.prototype.showDesktopNotif = function () {
        if (!this.notification)
            return;
        var content = "";
        var title = "";
        if (this.notificationCounter === 1) {
            //jiraLog('Single Desktop Notification shown: ', notification);
            var type = '';
            var verbs = [];
            if (this.notificationEvent['activity:object'] && this.notificationEvent['activity:object']['activity:object-type'])
                type = this.notificationEvent['activity:object']['activity:object-type']['#text'];
            if (this.notificationEvent['activity:verb'])
                verbs = this.notificationEvent['activity:verb'].map(function (el) { return el['#text']; });
            if (type === 'http://streams.atlassian.com/syndication/types/issue' && verbs.indexOf('http://streams.atlassian.com/syndication/verbs/jira/transition') > -1) {
                var issueSummary = this.notificationEvent['activity:object']['summary']['#text'];
                content = $('<div>' + this.notification.content + ' </div>').text().replace(/\s\s+/g, ' ').replace('- ' + issueSummary, '').replace(/\s\s+/g, ' ');
                title = yasoon.i18n('feed.jiraDesktopNotifTransition', { key: this.notificationEvent.issue.key, title: issueSummary });
                yasoon.notification.showPopup({ title: title, text: content, contactId: this.notification.contactId });
            }
            else if (type === 'http://activitystrea.ms/schema/1.0/comment') {
                content = $('<div>' + this.notification.content + ' </div>').text();
                title = yasoon.i18n('feed.jiraDesktopNotifNewCommentTitle', { key: this.notificationEvent.issue.key, title: this.notificationEvent.issue.fields.summary });
                yasoon.notification.showPopup({ title: title, text: content, contactId: this.notification.contactId });
            }
            else {
                content = $('<div>' + this.notification.title + ' </div>').text().replace(/\s\s+/g, ' ');
                yasoon.notification.showPopup({ title: yasoon.i18n('feed.jiraNewsDesktopNotifTitle'), text: content, contactId: this.notification.contactId });
            }
        }
        else if (this.notificationCounter === 2 && this.notificationEvent && this.notificationEvent.category && this.notificationEvent.category['@attributes'].term === 'created') {
            //Handle the single issue creation case (we want to show a single desktop nofif
            //jiraLog('Single Desktop Notification shown: ', notification);
            content = $('<div>' + this.notification.title + ' </div>').text();
            yasoon.notification.showPopup({ title: yasoon.i18n('feed.jiraNewsDesktopNotifTitle'), text: content, contactId: this.notification.contactId });
        }
        else {
            jiraLog('Multiple Desktop Notification shown!');
            yasoon.notification.showPopup({ title: yasoon.i18n('feed.jiraNewsDesktopNotifTitle'), text: yasoon.i18n('feed.jiraNewsDesktopNotifMultiple') });
        }
        this.notificationCounter = 0;
        this.notification = null;
    };
    ;
    JiraNotificationController.prototype.queueChildren = function (issue) {
        var results = $.grep(this.childQueue, function (i) { return issue.key === i.key; });
        if (results.length === 0) {
            //console.log('Queue Child - Add to Array ' + issue.key);
            this.childQueue.push(issue);
        }
    };
    JiraNotificationController.prototype.processChildren = function () {
        var _this = this;
        //If a new Issue is added, we need to make sure all children are loaded! This is done here via the feed.
        jiraLog('ProcessChildren');
        if (this.childQueue.length === 0) {
            return;
        }
        this.queueProcessingRunning = true;
        return Promise.resolve(this.childQueue)
            .each(function (entry) {
            return jira.syncStream('/activity?streams=issue-key+IS+' + entry.key, 500)
                .then(function () {
                //Update flag on DB, so we know that children are completely loaded
                var notif = yasoon.notification.getByExternalId(entry.id);
                var data = JSON.parse(notif.externalData);
                data.childrenLoaded = true;
                notif.externalData = JSON.stringify(data);
                //console.log('Queue Successfully processed for: ' + data.key);
                return jiraSaveNotification(notif);
            });
        })
            .then(function () {
            _this.queueProcessingRunning = false;
            _this.childQueue = [];
        });
    };
    JiraNotificationController.prototype.processCommentEdits = function () {
        /* Editing a comment does not affect the acitivity stream - JIRA BUG!
            Issue is open since 2007, so we do not expect a quick fix and we create a workaround.
            We check manually all changed issues and check if update date is newer than last sync
        */
        var _this = this;
        /* Second Bug - If you upload files and add a comment this is shown as one entry in the activity stream.
        --> find comments that are not in Database yet and add them manually
        */
        jiraLog('ProcessComments');
        //Find comments in all chnaged issues that changed since last Sync date
        var issues = jira.issues.all();
        return Promise.resolve(issues)
            .each(function (issue) {
            if (issue.fields.comment && issue.fields.comment.comments && issue.fields.comment.comments.length > 0) {
                return Promise.resolve(issue.fields.comment.comments)
                    .each(function (comment) {
                    var event = null;
                    if (new Date(comment.updated) >= jira.settings.lastSync && comment.updated != comment.created) {
                        //This is an updated comment --> update
                        event = _this.createCommentAction(comment, issue);
                        return _this.createNotification(event).save();
                    }
                    else if (new Date(comment.created) >= jira.settings.lastSync) {
                        //This is a new comment. It may has been created with attachments --> check if it's already on database
                        return jiraGetNotification('c' + comment.id)
                            .then(function (yEvent) {
                            if (!yEvent) {
                                event = _this.createCommentAction(comment, issue);
                                return _this.createNotification(event).save();
                            }
                        });
                    }
                });
            }
        });
    };
    JiraNotificationController.prototype.createCommentAction = function (comment, issue) {
        return {
            category: {
                '@attributes': {
                    'term': 'comment'
                }
            }, commentId: comment.id,
            issue: issue,
            type: 'IssueComment'
        };
    };
    JiraNotificationController.prototype.loadWorklogTemplate = function (issueKey, issueId, cbk) {
        var _this = this;
        if (!this.worklogTemplateLoaded) {
            var path = yasoon.io.getLinkPath('templates/addWorklog.js');
            $.getScript(path, function (template) {
                _this.worklogTemplateLoaded = true;
                _this.worklogTemplate = jira.templates.addWorklog;
                $('body').append(_this.worklogTemplate());
                $('#jiraAddWorklog').data('key', issueKey);
                //Create Datetime Picker
                $('#jiraInputDateStarted').datetimepicker({
                    allowTimes: [
                        //'00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', '06:30',
                        '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
                        '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00'
                    ]
                });
                //Selection changed
                $('input[name=jiraOptionsRadios]').change(function () {
                    //Make inputFields read-only
                    $('#jiraRemainingEstimateSetInput').prop('disabled', true);
                    $('#jiraRemainingEstimateReduceInput').prop('disabled', true);
                    if ($(this).attr('id') === 'jiraRemainingEstimateSet')
                        $('#jiraRemainingEstimateSetInput').prop('disabled', false);
                    if ($(this).attr('id') === 'jiraRemainingEstimateReduce')
                        $('#jiraRemainingEstimateReduceInput').prop('disabled', false);
                });
                //Submit
                var saveInProgress = false;
                $('#LogWorkSave').click(function () {
                    saveInProgress = true;
                    $('#LogWorkSave').removeClass('btn-primary').addClass('btn-default');
                    //Reset UI states
                    $('#jiraAddWorklog').find('form-group').remove('has-error');
                    //Check Mandatory fields
                    var dataTimeSpent = $('#jiraInputTimeSpent').val();
                    var dataWorkStarted = $('#jiraInputDateStarted').val();
                    var dataSetTimeInput = $('#jiraRemainingEstimateSetInput').val();
                    var dataReduceTimeInput = $('#jiraRemainingEstimateReduceInput').val();
                    var dataIssueKey = $('#jiraAddWorklog').data('key');
                    var dataOptionValue = $('input[name=jiraOptionsRadios]:checked').val();
                    var dataComment = $('#jiraInputComment').val();
                    if (!dataWorkStarted) {
                        $('#jiraInputDateStarted').closest('.form-group').addClass('has-error');
                        return;
                    }
                    if (!dataTimeSpent) {
                        $('#jiraInputTimeSpent').closest('.form-group').addClass('has-error');
                        return;
                    }
                    if (dataOptionValue === 'new' && !dataSetTimeInput) {
                        $('#jiraRemainingEstimateSetInput').closest('.form-group').addClass('has-error');
                        return;
                    }
                    if (dataOptionValue === 'manual' && !dataReduceTimeInput) {
                        $('#jiraRemainingEstimateReduceInput').closest('.form-group').addClass('has-error');
                        return;
                    }
                    //Parse date --> it's in format YYYY/MM/DD hh:mm --> Date can parse it automcatically
                    var dateString = new Date(dataWorkStarted).toISOString();
                    //WTF... JIRA accepts 2015-09-25T09:56:18.082+0000 but not 2015-09-25T09:56:18Z
                    dateString = dateString.replace('Z', '+0000');
                    //Set Data
                    var data = {
                        comment: dataComment,
                        timeSpent: $('#jiraInputTimeSpent').val(),
                        started: dateString
                    };
                    //Build url
                    var url = '/rest/api/2/issue/' + dataIssueKey + '/worklog?adjustEstimate=' + dataOptionValue;
                    if (dataOptionValue === 'new')
                        url += '&newEstimate=' + dataSetTimeInput;
                    if (dataOptionValue === 'manual')
                        url += '&newEstimate=' + dataReduceTimeInput;
                    //Dirty dirty dirty
                    var token = yasoon.app.enterContext('com.yasoon.jira');
                    jiraAjax(url, yasoon.ajaxMethod.Post, JSON.stringify(data))
                        .then(function () {
                        $('#jiraAddWorklog').modal('hide');
                        return jiraGetNotification(issueId);
                    })
                        .then(function (notif) {
                        yasoon.feed.allowUpdate(notif.feedId);
                        jira.sync();
                    })
                        .finally(function () {
                        $('#LogWorkSave').addClass('btn-primary').removeClass('btn-default');
                        saveInProgress = false;
                    });
                    yasoon.app.leaveContext(token);
                });
                cbk();
            });
        }
        else {
            $('#jiraAddWorklog').data('key', issueKey);
            //Clear input fields
            $('#jiraInputTimeSpent, #jiraInputDateStarted, #jiraRemainingEstimateSetInput, #jiraRemainingEstimateReduceInput,#jiraInputComment').val('');
            $('input[name=jiraOptionsRadios]').first().prop('checked', true);
            cbk();
        }
    };
    return JiraNotificationController;
}());
/// <reference path="../definitions/yasoon.d.ts" />
var JiraIssueTask = (function () {
    function JiraIssueTask(issue) {
        this.issue = issue;
    }
    JiraIssueTask.prototype.isSyncNeeded = function () {
        var _this = this;
        if (!jira.settings.syncTask)
            return false;
        if (!this.issue.fields.assignee || jira.data.ownUser.name != this.issue.fields.assignee.name)
            return false;
        if (jira.issues.isResolved(this.issue) && jira.settings.deleteCompletedTasks)
            return false;
        if (!jira.settings.tasksSyncAllProjects) {
            if (!jira.settings.tasksActiveProjects)
                return false;
            var activeProjects = jira.settings.tasksActiveProjects.split(',');
            if (activeProjects.filter(function (key) { return key == _this.issue.fields.project.key; }).length === 0)
                return false;
        }
        return true;
    };
    JiraIssueTask.prototype.getDbItem = function (dbItem) {
        dbItem.externalId = this.issue.key;
        dbItem.subject = this.issue.key + ': ' + this.issue.fields.summary;
        dbItem.body = this.issue.renderedFields.description.replace(/\s*\<br\/\>/g, '<br>'); //jshint ignore:line
        //dbItem.body = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' + dbItem.body + '</body></html>';
        dbItem.isHtmlBody = true;
        if (jira.issues.isResolved(this.issue)) {
            dbItem.completionState = yasoon.outlook.task.completionState.Completed;
            dbItem.completionPercent = 100;
        }
        else if (dbItem.completionState == yasoon.outlook.task.completionState.Completed) {
            //Do not always overwrite the status --> User may have set it to "pending" or similar to track the status
            //Better: Only reset status to NotStarted if it is an old task AND this task was completed
            dbItem.completionState = yasoon.outlook.task.completionState.NotStarted;
            dbItem.completionPercent = 0;
        }
        if (this.issue.fields.duedate) {
            //We need to use momentJS to parse the date correctly
            // Wunderlist JSON contains "2014-04-14"
            // If using new Date(json), this will result in a date:
            //     14.04.2014 00:00 UTC!
            // but we actually need 00:00 local time (moment does that)
            dbItem.dueDate = moment(this.issue.fields.duedate).toDate();
        }
        else {
            dbItem.dueDate = new Date(0);
        }
        if (this.issue.fields.assignee)
            dbItem.owner = this.issue.fields.assignee.displayName;
        else
            delete dbItem.owner;
        dbItem.externalData = JSON.stringify(jiraMinimizeIssue(this.issue));
        return dbItem;
    };
    JiraIssueTask.prototype.save = function (forceSync) {
        var _this = this;
        //Is sync nessecary?
        if (!forceSync && !this.isSyncNeeded())
            return Promise.resolve();
        return jiraGetTask(this.issue.key)
            .then(function (dbItem) {
            //Check if it's an update or creation
            var creation = false;
            if (!dbItem) {
                //Creation
                creation = true;
                dbItem = { categories: ['JIRA'] };
            }
            else if (!forceSync && _this.issue.fields.updated) {
                var oldIssue = JSON.parse(dbItem.externalData);
                if (new Date(oldIssue.fields.updated).getTime() >= new Date(_this.issue.fields.updated).getTime()) {
                    //not new and no update needed
                    return dbItem;
                }
            }
            dbItem = _this.getDbItem(dbItem);
            //Does folder exist?
            return jiraGetFolder(_this.issue.fields.project.key)
                .then(function (folder) {
                if (!folder)
                    return jiraAddFolder(_this.issue.fields.project.key, _this.issue.fields.project.name, JSON.stringify(_this.issue.fields.project));
            })
                .then(function () {
                if (creation)
                    return jiraAddTask(dbItem, _this.issue.fields.project.key);
                else
                    return jiraSaveTask(dbItem);
            });
        });
    };
    JiraIssueTask.prototype.saveInspector = function (inspectorItem) {
        var item = this.getDbItem({});
        inspectorItem.setSubject(item.subject);
        //inspectorItem.setBody(item.body);
        inspectorItem.setCompletionPercentage(item.completionPercent);
        inspectorItem.setCompletionState(item.completionState);
        inspectorItem.setOwner(item.owner);
        inspectorItem.setDueDate(new Date(item.dueDate));
        inspectorItem.setExternalData(item.externalData);
        inspectorItem.save(function () { }, function () { });
    };
    return JiraIssueTask;
}());
/// <reference path="../definitions/bluebird.d.ts" />
/// <reference path="../definitions/jira.d.ts" />
/// <reference path="../definitions/common.d.ts" />
/// <reference path="../definitions/yasoon.d.ts" />
/// <reference path="../models/issueTask.ts" />
var JiraRibbonController = (function () {
    function JiraRibbonController() {
        var _this = this;
        this.createRibbon = function (ribbonFactory) {
            jira.ribbonFactory = ribbonFactory;
            //Add Ribbon in top toolbar Ribbon on new Item
            var contextMenuItems = [{
                    type: 'contextMenu',
                    idMso: 'MenuMailNewItem',
                    items: [{
                            type: 'button',
                            id: 'newIssue',
                            insertAfterMso: 'NewTaskCompact',
                            label: yasoon.i18n('ribbon.newIssue'),
                            image: 'logo_icon1.png',
                            onAction: _this.ribbonOnNewIssue
                        }]
                },
                {
                    type: 'contextMenu',
                    idMso: 'ContextMenuMailItem',
                    items: [{
                            id: 'newIssueFullMail',
                            type: 'button',
                            image: 'logo_icon1.png',
                            label: yasoon.i18n('ribbon.newIssue'),
                            onAction: _this.ribbonOnNewIssue
                        }, {
                            id: 'addToIssueFullMail',
                            type: 'button',
                            image: 'logo_icon1.png',
                            label: yasoon.i18n('ribbon.addToIssue'),
                            onAction: _this.ribbonOnAddToIssue
                        }]
                }, {
                    type: 'contextMenu',
                    idMso: 'ContextMenuAttachments',
                    items: [{
                            type: 'button',
                            id: 'uploadAttachmentToIssue',
                            label: yasoon.i18n('ribbon.uploadToIssue'),
                            enabled: false,
                            image: 'logo_icon1.png',
                            onAction: _this.uploadAttachment
                        }, {
                            type: 'dynamicMenu',
                            id: 'uploadAttachmentDynamicMenu',
                            label: yasoon.i18n('ribbon.uploadToIssues'),
                            image: 'logo_icon1.png',
                            visible: false,
                            items: [{
                                    type: 'menu',
                                    id: 'uploadAttachmentMenu',
                                    items: []
                                }]
                        }]
                }];
            //Add New Issue Ribbons in email
            var newIssueRibbons = _this.createContextRibbonItems(yasoon.i18n('ribbon.newIssue'), 'newIssueFromText', _this.ribbonOnNewIssue);
            contextMenuItems = contextMenuItems.concat(newIssueRibbons);
            var addToIssueRibbons = _this.createContextRibbonItems(yasoon.i18n('ribbon.addToIssue'), 'addToIssueFromText', _this.ribbonOnAddToIssue);
            contextMenuItems = contextMenuItems.concat(addToIssueRibbons);
            //Add main menu ribbon
            ribbonFactory.create({
                type: 'ribbon',
                renderTo: [
                    'Microsoft.Outlook.Explorer'
                ],
                items: [{
                        type: 'tabs',
                        items: [{
                                type: 'tab',
                                idMso: 'TabMail',
                                items: [{
                                        type: 'group',
                                        id: 'jiraMailExplorerGroup',
                                        insertAfterMso: 'GroupMailRespond',
                                        label: 'JIRA',
                                        image: 'brandedlogo-64',
                                        items: _this.createJiraRibbonGroup('MailMain')
                                    }]
                            },
                            {
                                type: 'tab',
                                idMso: 'TabTasks',
                                items: [{
                                        type: 'group',
                                        id: 'jiraTaskExplorerGroup',
                                        insertAfterMso: 'GroupTaskRespond',
                                        label: 'JIRA',
                                        image: 'brandedlogo-64',
                                        items: [{
                                                type: 'splitButton',
                                                id: 'jiraTaskSync',
                                                size: 'large',
                                                items: [{
                                                        type: 'button',
                                                        id: 'jiraTaskRefresh',
                                                        label: yasoon.i18n('ribbon.syncTasks'),
                                                        screentip: yasoon.i18n('ribbon.syncTasks'),
                                                        image: 'images/ribbonSyncing.png',
                                                        supertip: yasoon.i18n('ribbon.syncTasksScreenTip'),
                                                        enabled: true,
                                                        onAction: _this.ribbonRefreshTasks
                                                    }, {
                                                        type: 'menu',
                                                        id: 'RefreshMenu',
                                                        items: [{
                                                                type: 'button',
                                                                id: 'jiraTaskForceRefresh',
                                                                label: yasoon.i18n('ribbon.forceSyncTasks'),
                                                                onAction: _this.ribbonRefreshTasks
                                                            }]
                                                    }]
                                            }]
                                    }]
                            }]
                    }]
            });
            //Add Mail Read
            ribbonFactory.create({
                type: 'ribbon',
                renderTo: [
                    'Microsoft.Outlook.Mail.Read'
                ],
                items: [{
                        type: 'tabs',
                        items: [{
                                type: 'tab',
                                idMso: 'TabReadMessage',
                                items: [{
                                        type: 'group',
                                        id: 'jiraMailReadGroup',
                                        insertAfterMso: 'GroupShow',
                                        label: 'JIRA',
                                        image: 'brandedlogo-64',
                                        items: _this.createJiraRibbonGroup('MailRead')
                                    }]
                            }]
                    }]
            });
            //Add Context Menus
            ribbonFactory.create({
                type: 'contextMenus',
                renderTo: [
                    'Microsoft.Outlook.Explorer',
                    'Microsoft.Outlook.Mail.Read'
                ],
                items: contextMenuItems
            });
            //Add Task Ribbon
            ribbonFactory.create({
                type: 'ribbon',
                renderTo: [
                    'Microsoft.Outlook.Task'
                ],
                items: [{
                        type: 'tabs',
                        items: [{
                                type: 'tab',
                                idMso: 'TabTask',
                                items: [{
                                        type: 'group',
                                        id: 'buttonGroupTask',
                                        insertAfterMso: 'GroupActions',
                                        label: 'JIRA',
                                        items: [{
                                                type: 'button',
                                                id: 'jiraOpenTask',
                                                size: 'large',
                                                label: 'Open Issue',
                                                image: 'images/ribbonOpen.png',
                                                visible: 'appItem',
                                                onAction: _this.ribbonOpenIssue
                                            }, {
                                                type: 'button',
                                                id: 'jiraEditTask',
                                                size: 'large',
                                                label: 'Edit Issue',
                                                image: 'brandedlogo-64',
                                                visible: 'appItem',
                                                onAction: _this.ribbonEditIssue
                                            }, {
                                                id: 'jiraAddTask',
                                                type: 'button',
                                                size: 'large',
                                                image: 'images/ribbonAdd.png',
                                                visible: 'appItem',
                                                label: yasoon.i18n('ribbon.addToIssue'),
                                                onAction: _this.ribbonOnAddToIssue
                                            }, {
                                                type: 'dynamicMenu',
                                                id: 'jiraTransitionDynamicMenu',
                                                size: 'large',
                                                label: yasoon.i18n('ribbon.changeTransition'),
                                                image: 'images/ribbonTransition.png',
                                                visible: 'appItem',
                                                items: [{
                                                        type: 'menu',
                                                        id: 'jiraTransitionMenu',
                                                        items: []
                                                    }]
                                            }]
                                    }]
                            }]
                    }]
            });
        };
        this.ribbonExecuteTransition = function (ribbonId, ribbonCtx) {
            if (!jiraIsLicensed(true)) {
                return;
            }
            var extData = JSON.parse(ribbonCtx.externalData);
            var issue = ribbonCtx.items[0];
            var issueKey = extData.issueKey;
            var issueId = extData.issueId;
            var transitionId = extData.transitionId;
            var body = JSON.stringify({
                "transition": {
                    "id": transitionId
                }
            });
            jira.ribbonFactory.updateSingle('jiraTransitionDynamicMenu', {
                enabled: false
            }, issue.inspectorId);
            jiraGet('/rest/api/2/issue/' + issueKey + '/transitions?transitionId=' + transitionId)
                .then(function (data) {
                var transObj = JSON.parse(data);
                if (transObj.transitions[0].hasScreen) {
                    yasoon.openBrowser(jira.settings.baseUrl + '/login.jsp?os_destination=' + encodeURIComponent('/secure/CommentAssignIssue!default.jspa?id=' + issueId + '&action=' + transitionId));
                }
                else {
                    return jiraAjax('/rest/api/2/issue/' + issueKey + '/transitions', yasoon.ajaxMethod.Post, body)
                        .then(function () {
                        return jira.issues.get(issueKey, true);
                    })
                        .then(function (newIssue) {
                        jira.ribbonFactory.updateSingle('jiraTransitionDynamicMenu', {
                            enabled: true
                        }, issue.inspectorId);
                        _this.updateRibbons(newIssue, issue.inspectorId);
                        new JiraIssueTask(newIssue).saveInspector(issue);
                        jira.sync();
                    });
                }
            })
                .catch(function (error) {
                var msg = (error.getUserFriendlyError) ? error.getUserFriendlyError() : error;
                yasoon.dialog.showMessageBox(yasoon.i18n('notification.changeStatusNotPossible', { error: msg }));
                yasoon.util.log('Unexpected error in Set Transition in Task: ' + error, yasoon.util.severity.error, getStackTrace(error));
                jira.ribbonFactory.updateSingle('jiraTransitionDynamicMenu', {
                    enabled: true
                }, issue.inspectorId);
            });
        };
        this.ribbonOnNewIssue = function (ribbonId, ribbonCtx) {
            if (!jiraIsLicensed(true)) {
                return;
            }
            if (!jira.settings.currentService || !yasoon.app.isOAuthed(jira.settings.currentService)) {
                yasoon.dialog.showMessageBox(yasoon.i18n('general.loginFirst'));
                return;
            }
            var initParams = {
                'settings': jira.settings,
                'ownUser': jira.data.ownUser,
                'userMeta': jira.cache.userMeta,
                'createMetas': jira.cache.createMetas,
                'projects': jira.data.projects,
                'systemInfo': jira.sysInfo
            };
            var dialogOptions = {
                width: 735,
                height: 700,
                title: yasoon.i18n('dialog.newIssueDialogTitle'),
                resizable: true,
                htmlFile: 'dialogs/jiraNewEditIssue.html',
                initParameter: initParams,
                closeCallback: _this.ribbonOnCloseNewIssue
            };
            if (ribbonId == 'newIssueFullMail' || ribbonId == 'newIssueFromMailMain' || ribbonId == 'newIssueFromMailRead') {
                //Ribbon on Mail Item
                initParams.mail = ribbonCtx.items[ribbonCtx.readingPaneItem];
                initParams.type = 'wholeMail';
            }
            else if (ribbonId == 'newIssue') {
                //Ribbon in Standard New EMail Dropdown
                initParams.type = '';
            }
            else {
                var selection = '';
                try {
                    selection = ribbonCtx.items[ribbonCtx.readingPaneItem].getSelection(0);
                }
                catch (e) {
                    yasoon.dialog.showMessageBox(yasoon.i18n('general.couldNotDetectEmail'));
                    return;
                }
                if (!selection || !selection.trim()) {
                    yasoon.dialog.showMessageBox(yasoon.i18n('general.selectTextFirst'));
                    return;
                }
                initParams.mail = ribbonCtx.items[ribbonCtx.readingPaneItem];
                initParams.type = 'selectedText';
            }
            yasoon.dialog.open(dialogOptions);
            return;
        };
        this.ribbonOnAddToIssue = function (ribbonId, ribbonCtx) {
            if (!jiraIsLicensed(true)) {
                return;
            }
            if (!jira.settings.currentService || !yasoon.app.isOAuthed(jira.settings.currentService)) {
                yasoon.dialog.showMessageBox(yasoon.i18n('general.loginFirst'));
                return;
            }
            var initParams = {
                settings: jira.settings,
                ownUser: jira.data.ownUser,
                projects: jira.data.projects,
                systemInfo: jira.sysInfo
            };
            var dialogOptions = {
                width: 610,
                height: 625,
                title: yasoon.i18n('dialog.addToIssueDialogTitle'),
                resizable: true,
                htmlFile: 'Dialogs/jiraAddToIssue.html',
                initParameter: initParams,
                closeCallback: _this.ribbonOnCloseAddToIssue
            };
            if (ribbonId == 'addToIssueFullMail' || ribbonId == 'addToIssueFromMailMain' || ribbonId == 'addToIssueFromMailRead') {
                initParams.mail = ribbonCtx.items[ribbonCtx.readingPaneItem];
                initParams.type = 'wholeMail';
            }
            else if (ribbonId == 'jiraAddTask') {
                var task = ribbonCtx.items[ribbonCtx.readingPaneItem];
                initParams.issue = JSON.parse(task.externalData);
            }
            else {
                var selection = '';
                try {
                    selection = ribbonCtx.items[ribbonCtx.readingPaneItem].getSelection(0);
                }
                catch (e) {
                    yasoon.dialog.showMessageBox(yasoon.i18n('general.couldNotDetectEmail'));
                    return;
                }
                if (!selection || !selection.trim()) {
                    yasoon.dialog.showMessageBox(yasoon.i18n('general.selectTextFirst'));
                    return;
                }
                initParams.mail = ribbonCtx.items[ribbonCtx.readingPaneItem];
                initParams.type = 'selectedText';
            }
            yasoon.dialog.open(dialogOptions);
        };
    }
    JiraRibbonController.prototype.createContextRibbonItems = function (label, id, action) {
        var result = [];
        //var mailContextMenuMso = [
        //	'ContextMenuHeading',
        //	'ContextMenuHeadingLinked',
        //	'ContextMenuReadOnlyMailText',
        //	'ContextMenuReadOnlyMailList',
        //	'ContextMenuReadOnlyMailTable',
        //	'ContextMenuReadOnlyMailTableCell',
        //	'ContextMenuReadOnlyMailListTable',
        //	'ContextMenuReadOnlyMailPictureTable',
        //	'ContextMenuReadOnlyMailTableWhole',
        //	'ContextMenuReadOnlyMailTextTable',
        //	'ContextMenuReadOnlyMailHyperlink'
        //];
        var mailContextMenuMso = [
            'ContextMenuReadOnlyMailText',
            'ContextMenuReadOnlyMailTable',
            'ContextMenuReadOnlyMailTableCell',
            'ContextMenuReadOnlyMailListTable',
            'ContextMenuReadOnlyMailPictureTable',
            'ContextMenuReadOnlyMailTextTable',
            'ContextMenuReadOnlyMailTableWhole',
            'ContextMenuReadOnlyMailList',
            'ContextMenuReadOnlyMailHyperlink',
            'ContextMenuHeading',
            'ContextMenuHeadingLinked',
            'ContextMenuFieldDisplay'
        ];
        mailContextMenuMso.forEach(function (mso, i) {
            var counter = i + 1;
            result.push({
                type: 'contextMenu',
                idMso: mso,
                items: [{
                        type: 'button',
                        id: id + '' + ((counter != 1) ? counter : ''),
                        label: label,
                        image: 'logo_icon1.png',
                        onAction: action
                    }]
            });
        });
        return result;
    };
    ;
    JiraRibbonController.prototype.createJiraRibbonGroup = function (id) {
        return [{
                type: 'button',
                id: 'newIssueFrom' + id,
                size: 'large',
                label: yasoon.i18n('ribbon.newIssue'),
                image: 'images/ribbonNew.png',
                onAction: this.ribbonOnNewIssue
            }, {
                type: 'button',
                id: 'addToIssueFrom' + id,
                size: 'large',
                label: yasoon.i18n('ribbon.addToIssue'),
                image: 'images/ribbonAdd.png',
                onAction: this.ribbonOnAddToIssue
            }, {
                type: 'button',
                id: 'openIssueFrom' + id,
                enabled: false,
                size: 'large',
                label: yasoon.i18n('ribbon.openIssue'),
                image: 'images/ribbonOpen.png',
                onAction: this.ribbonOpenIssue
            }, {
                type: 'dynamicMenu',
                id: 'openIssueDynamicMenuFrom' + id,
                size: 'large',
                label: yasoon.i18n('ribbon.openIssues'),
                image: 'images/ribbonOpen.png',
                visible: false,
                items: [{
                        type: 'menu',
                        id: 'openIssueMenuFrom' + id,
                        items: []
                    }]
            }];
    };
    JiraRibbonController.prototype.updateRibbons = function (item, inspectorId) {
        var _this = this;
        if (!item)
            return;
        var parameters = (inspectorId) ? inspectorId : true;
        var method = (inspectorId) ? 'updateSingle' : 'update';
        if (jiraIsTask(item) || item.fields) {
            var issue = item;
            if (!issue.fields)
                issue = JSON.parse(item.externalData);
            if (issue.transitions) {
                var transitionItems = [];
                issue.transitions.forEach(function (t) {
                    transitionItems.push({
                        type: 'button',
                        id: 'transition-' + t.id,
                        label: t.name,
                        externalData: JSON.stringify({ transitionId: t.id, issueKey: issue.key, issueId: issue.id }),
                        onAction: _this.ribbonExecuteTransition
                    });
                });
                jira.ribbonFactory[method]('jiraTransitionMenu', {
                    items: transitionItems
                }, parameters);
                jira.ribbonFactory[method]('jiraTransitionDynamicMenu', {
                    visible: 'appItem'
                }, parameters);
            }
            else {
                jira.ribbonFactory[method]('jiraTransitionDynamicMenu', {
                    visible: false
                }, parameters);
            }
        }
        else {
            if (!item.getConversationData)
                return;
            //This method can be called with or without inspector. In inspector it has another method to call(updateSingle instead of update) and different Ids
            var where = (inspectorId) ? 'MailRead' : 'MailMain';
            var ribbonButton = 'openIssueFrom' + where;
            var ribbonDynamicMenu = 'openIssueDynamicMenuFrom' + where;
            var ribbonInnerMenu = 'openIssueMenuFrom' + where;
            var convData = item.getConversationData();
            if (convData) {
                convData = JSON.parse(convData);
                if (convData.issues) {
                    if (Object.keys(convData.issues).length > 1) {
                        //Create Items for Dyn Menu
                        var convItems = [];
                        Object.keys(convData.issues).forEach(function (key) {
                            var currentItem = convData.issues[key];
                            convItems.push({
                                type: 'button',
                                id: 'openIssueMenu-' + currentItem.id,
                                label: yasoon.i18n('ribbon.openIssueWithKey', { key: currentItem.key }),
                                externalData: currentItem.key,
                                image: 'images/ribbonOpen.png',
                                onAction: _this.ribbonOpenIssue
                            });
                        });
                        jira.ribbonFactory[method](ribbonButton, {
                            visible: false
                        }, parameters);
                        jira.ribbonFactory[method](ribbonDynamicMenu, {
                            visible: true
                        }, parameters);
                        jira.ribbonFactory[method](ribbonInnerMenu, {
                            items: convItems
                        }, parameters);
                    }
                    else {
                        var key = convData.issues[Object.keys(convData.issues)[0]].key;
                        jira.ribbonFactory[method](ribbonButton, {
                            label: yasoon.i18n('ribbon.openIssueWithKey', { key: key }),
                            externalData: key,
                            enabled: true,
                            visible: true
                        }, parameters);
                        jira.ribbonFactory[method](ribbonDynamicMenu, {
                            visible: false
                        }, parameters);
                    }
                    return;
                }
            }
            jira.ribbonFactory[method](ribbonButton, {
                label: yasoon.i18n('ribbon.openIssue'),
                enabled: false,
                visible: true
            }, parameters);
            jira.ribbonFactory[method](ribbonDynamicMenu, {
                visible: false
            }, parameters);
        }
    };
    JiraRibbonController.prototype.updateAttachmentRibbons = function (item, inspectorId) {
        var _this = this;
        var ribbonButton = 'uploadAttachmentToIssue';
        var ribbonDynamicMenu = 'uploadAttachmentDynamicMenu';
        var ribbonInnerMenu = 'uploadAttachmentMenu';
        var parameters = (inspectorId) ? inspectorId : true;
        var method = (inspectorId) ? 'updateSingle' : 'update';
        var convData = item.getConversationData();
        if (convData) {
            convData = JSON.parse(convData);
            if (convData.issues) {
                if (Object.keys(convData.issues).length > 1) {
                    //Create Items for Dyn Menu
                    var convItems = [];
                    Object.keys(convData.issues).forEach(function (key) {
                        var currentItem = convData.issues[key];
                        convItems.push({
                            type: 'button',
                            id: 'uploadToIssue-' + currentItem.id,
                            label: yasoon.i18n('ribbon.uploadToIssueWithKey', { key: currentItem.key }),
                            externalData: currentItem.key,
                            image: 'images/ribbonOpen.png',
                            onAction: _this.uploadAttachment
                        });
                    });
                    jira.ribbonFactory[method](ribbonButton, {
                        visible: false
                    }, parameters);
                    jira.ribbonFactory[method](ribbonDynamicMenu, {
                        visible: true
                    }, parameters);
                    jira.ribbonFactory[method](ribbonInnerMenu, {
                        items: convItems
                    }, parameters);
                }
                else {
                    var key = convData.issues[Object.keys(convData.issues)[0]].key;
                    jira.ribbonFactory[method](ribbonButton, {
                        label: yasoon.i18n('ribbon.uploadToIssueWithKey', { key: key }),
                        externalData: key,
                        enabled: true,
                        visible: true
                    }, parameters);
                    jira.ribbonFactory[method](ribbonDynamicMenu, {
                        visible: false
                    }, parameters);
                }
                return;
            }
        }
        jira.ribbonFactory[method](ribbonButton, {
            label: yasoon.i18n('ribbon.uploadToIssue'),
            enabled: false,
            visible: true
        }, parameters);
        jira.ribbonFactory[method](ribbonDynamicMenu, {
            visible: false
        }, parameters);
    };
    JiraRibbonController.prototype.ribbonOpenIssue = function (ribbonId, ribbonCtx) {
        console.log(arguments);
        var issueKey = null;
        if (ribbonCtx.externalData)
            issueKey = ribbonCtx.externalData;
        else if (ribbonCtx.items && ribbonCtx.items.length > 0)
            issueKey = ribbonCtx.items[0].externalId;
        if (issueKey) {
            try {
                yasoon.openBrowser(jira.settings.baseUrl + '/browse/' + issueKey);
            }
            catch (e) {
                yasoon.util.log('Error in ribbonOpenIssue' + e.message, yasoon.util.severity.warning);
            }
        }
        else
            yasoon.dialog.showMessageBox(yasoon.i18n('general.couldNotOpenIssue'));
    };
    ;
    JiraRibbonController.prototype.ribbonEditIssue = function (ribbonId, ribbonCtx) {
        if (!jiraIsLicensed(true)) {
            return;
        }
        if (!ribbonCtx.items && ribbonCtx.items.length === 0) {
            yasoon.dialog.showMessageBox(yasoon.i18n('general.couldNotOpenIssue'));
            return;
        }
        var outlookTask = ribbonCtx.items[0];
        var issue = JSON.parse(outlookTask.externalData);
        new JiraIssueNotification(issue).editIssue(function (type, data) {
            if (data && data.action === 'success') {
                return jira.issues.get(issue.key, true)
                    .then(function (newIssue) {
                    new JiraIssueTask(newIssue).saveInspector(outlookTask);
                    jira.sync();
                });
            }
        });
    };
    JiraRibbonController.prototype.uploadAttachment = function (ribbonId, ribbonCtx) {
        if (ribbonCtx.items && ribbonCtx.items.length > 0) {
            //Upload every file to the issue and show Loader
            var formData = [];
            ribbonCtx.items.forEach(function (file) {
                formData.push({
                    type: yasoon.formData.File,
                    name: 'file',
                    value: file.getFileHandle()
                });
            });
            var progressProvider = yasoon.oauth({
                url: jira.settings.baseUrl + '/rest/api/2/issue/' + ribbonCtx.externalData + '/attachments',
                oauthServiceName: jira.settings.currentService,
                type: yasoon.ajaxMethod.Post,
                formData: formData,
                headers: { Accept: 'application/json', 'X-Atlassian-Token': 'nocheck' },
                error: function (data, statusCode, result, errorText, cbkParam) {
                    yasoon.dialog.showMessageBox(yasoon.i18n('general.couldNotUploadAttachments') + ' - ' + errorText);
                },
                success: function () {
                    ribbonCtx.items[0].completeLoader();
                    jira.sync();
                }
            });
            ribbonCtx.items[0].showLoader([progressProvider]);
        }
    };
    JiraRibbonController.prototype.ribbonRefreshTasks = function (ribbonId, ribbonCtx) {
        jira.ribbonFactory.update('jiraTaskSync', {
            enabled: false
        }, true);
        var forceSync = (ribbonId == 'jiraTaskForceRefresh');
        jira.tasks.syncTasks(forceSync)
            .then(function () {
            yasoon.dialog.showMessageBox(yasoon.i18n('general.taskSyncSuccess'));
            jira.ribbonFactory.update('jiraTaskSync', {
                enabled: true
            }, true);
        })
            .catch(function () {
            yasoon.dialog.showMessageBox(yasoon.i18n('general.taskSyncFailed'));
        });
    };
    JiraRibbonController.prototype.ribbonOnCloseNewIssue = function (type, data) {
        if (data && data.action === 'success')
            jira.sync();
        if (data && data.issueKey) {
            var text = '';
            var title = '';
            if (data.changeType === 'updated') {
                text = yasoon.i18n('dialog.successAddPopupText', { key: data.issueKey });
                title = yasoon.i18n('dialog.successAddPopupTitle');
            }
            else {
                text = yasoon.i18n('dialog.successPopupText', { key: data.issueKey });
                title = yasoon.i18n('dialog.successPopupTitle');
            }
            yasoon.notification.showPopup({ title: title, text: text, click: notificationOpenIssue, eventParam: { issueKey: data.issueKey } });
        }
        if (data && data.mail) {
            yasoon.outlook.mail.get(data.mail.entryId, data.mail.storeId)
                .then(function (mail) {
                jira.ribbons.updateRibbons(mail);
            });
        }
    };
    JiraRibbonController.prototype.ribbonOnCloseAddToIssue = function (type, data) {
        if (data && data.action === 'success')
            jira.sync();
        if (data && data.mail) {
            yasoon.outlook.mail.get(data.mail.entryId, data.mail.storeId)
                .then(function (mail) {
                jira.ribbons.updateRibbons(mail);
            });
        }
    };
    return JiraRibbonController;
}());
var templateLoaded = false;
var settingTemplate = null;
var settingsContainer = null;
var defaults = {
    currentService: '',
    lastSync: new Date(new Date().getTime() - (1000 * 60 * 60 * 24 * 14)),
    showDesktopNotif: true,
    addAttachmentsOnNewAddIssue: false,
    addMailHeaderAutomatically: 'off',
    addEmailOnNewAddIssue: false,
    showFeedAssignee: true,
    showFeedMentioned: true,
    showFeedWatcher: true,
    showFeedProjectLead: false,
    showFeedReporter: true,
    showFeedCreator: true,
    showFeedComment: true,
    newCreationScreen: true,
    syncCalendar: false,
    syncFeed: 'auto',
    syncTask: false,
    tasksActiveProjects: '',
    deleteCompletedTasks: false,
    tasksSyncAllProjects: true,
    hideResolvedIssues: false,
    activeFilters: 'fields.project.id,fields.issuetype.id,fields.status.id,fields.priority.id,fields.assignee.emailAddress'
};
var JiraSettingController = (function () {
    function JiraSettingController() {
        var _this = this;
        this.renderSettingsContainer = function (container) {
            if (!container) {
                container = settingsContainer;
            }
            if (!container)
                return;
            settingsContainer = container;
            //Prepare Data for handlebar Template
            //We need all oAuth Services + determine the description
            var oAuthServices = yasoon.app.getOAuthServices();
            oAuthServices.forEach(function (service) {
                service.description = (service.appParams) ? service.appParams.description : service.serviceName;
            });
            //Check selected filters
            jira.filter.filterObj.forEach(function (f) {
                //Is in selected?!            
                f.selected = jira.filter.getSelectedFilters().filter(function (key) { return key === f.key; }).length > 0;
            });
            //Active Projects for Task Sync
            var projects = [];
            if (jira.data.projects) {
                projects = JSON.parse(JSON.stringify(jira.data.projects));
            }
            if (_this.tasksActiveProjects) {
                var activeProjects = _this.tasksActiveProjects.split(',');
                projects.forEach(function (p) {
                    p.selected = activeProjects.filter(function (key) { return key === p.key; }).length > 0;
                });
            }
            var templateParams = {
                oAuthServices: oAuthServices,
                loggedIn: !!jira.settings.currentService,
                filters: jira.filter.filterObj,
                taskSyncEnabled: jira.settings.taskSyncEnabled,
                tasksSyncAllProjects: jira.settings.tasksSyncAllProjects,
                projects: projects,
                loaderPath: yasoon.io.getLinkPath('Dialogs/ajax-loader.gif')
            };
            if (!templateLoaded) {
                var path = yasoon.io.getLinkPath('templates/settings.js');
                $.getScript(path, function (template) {
                    templateLoaded = true;
                    settingTemplate = jira.templates.settings;
                    _this.fillSettingsContainer(settingsContainer, settingTemplate, templateParams);
                });
            }
            else {
                _this.fillSettingsContainer(settingsContainer, settingTemplate, templateParams);
            }
        };
        this.saveSettings = function (form) {
            //Create deep copy
            $.each(form, function (i, param) {
                //Special Case for activeFilters
                if (param.key === 'activeFilters' && _this[param.key] != param.value) {
                    yasoon.dialog.showMessageBox(yasoon.i18n('settings.filterChange'));
                    if (param.value === null)
                        param.value = '';
                }
                if (param.key === 'tasksActiveProjects' && _this[param.key] != param.value ||
                    param.key === 'taskSyncEnabled' && _this[param.key] != param.value ||
                    param.key === 'tasksSyncAllProjects' && _this[param.key] != param.value) {
                    jira.tasks.requireFullSync = true;
                    jira.sync();
                }
                if (param.value == "true") {
                    _this[param.key] = true;
                }
                else if (param.value == "false") {
                    _this[param.key] = false;
                }
                else {
                    _this[param.key] = param.value;
                }
            });
            _this.save();
        };
        /****** Initial Load of settings */
        var urlString = yasoon.setting.getAppParameter('baseUrl');
        if (urlString) {
            this.baseUrl = urlString;
        }
        var dataString = yasoon.setting.getAppParameter('ownUser');
        if (dataString) {
            jira.data = {};
            jira.data.ownUser = JSON.parse(dataString);
        }
        //Load License
        var licenseString = yasoon.setting.getAppParameter('license');
        if (licenseString) {
            jira.license = JSON.parse(licenseString);
            jira.license.validUntil = new Date(jira.license.validUntil);
        }
        else {
            var validUntil = new Date();
            validUntil.setDate(validUntil.getDate() + 14);
            jira.license = { comment: 'Please play fair and pay for your software.', isFullyLicensed: false, validUntil: validUntil };
            yasoon.setting.setAppParameter('license', JSON.stringify(jira.license));
        }
        //Load System Infos
        var sysInfoString = yasoon.setting.getAppParameter('systemInfo');
        if (sysInfoString) {
            jira.sysInfo = JSON.parse(sysInfoString);
        }
        //Load TaskSync Settings
        this.taskSyncEnabled = (yasoon.setting.getAppParameter('taskSyncEnabled') == 'true');
        //Load Temlead CRM Settings
        var teamleadCrmDataString = yasoon.setting.getAppParameter('teamlead');
        if (teamleadCrmDataString) {
            this.teamlead = JSON.parse(teamleadCrmDataString);
            if (this.teamlead.mapping) {
                try {
                    this.teamlead.mapping = JSON.parse(this.teamlead.mapping) || {};
                }
                catch (e) {
                    this.teamlead.mapping = {};
                }
            }
        }
        //Merge company defaults
        var defaultSettingsString = yasoon.setting.getAppParameter('defaultSettings');
        if (defaultSettingsString) {
            var def = JSON.parse(defaultSettingsString);
            defaults = $.extend(defaults, def);
        }
        //Determine settings to load:
        var settingsString = yasoon.setting.getAppParameter('settings');
        var settings = null;
        if (!settingsString) {
            //Initial Settings
            settings = defaults;
            yasoon.setting.setAppParameter('settings', JSON.stringify(settings));
        }
        else {
            //Load Settings
            settings = JSON.parse(settingsString);
            settings = $.extend(defaults, settings);
        }
        $.each(settings, function (key, value) {
            _this[key] = value;
        });
        this.lastSync = new Date(this.lastSync);
        //Determine URL from service if possible
        if (this.currentService) {
            var service = yasoon.app.getOAuthService(this.currentService);
            if (service && service.appParams && service.appParams.url) {
                this.baseUrl = service.appParams.url;
            }
        }
    }
    JiraSettingController.prototype.fillSettingsContainer = function (container, template, parameter) {
        var _this = this;
        //Add Values
        var elem = $('<div>' + template(parameter) + '</div>');
        $.each(jira.settings, function (i, val) {
            if (elem.find('#' + i).attr('type') == "checkbox") {
                if (val) {
                    elem.find('#' + i).attr('checked', 'true');
                }
            }
            else {
                elem.find('#' + i).val(val);
            }
        });
        //Add JS
        container.afterRender = function () {
            $('#activeFilters').multiSelect({
                selectableHeader: yasoon.i18n('settings.filterAvailable'),
                selectionHeader: yasoon.i18n('settings.filterActive')
            });
            $('#tasksActiveProjects').multiSelect({
                selectableHeader: yasoon.i18n('settings.taskProjectAvailable'),
                selectionHeader: yasoon.i18n('settings.taskProjectActive')
            });
            $('#tasksSyncAllProjects').off().on('change', function (e) {
                e.preventDefault();
                if ($('#tasksSyncAllProjects').getValue() === true) {
                    $('#tasksProjectfilterContainer').slideUp();
                }
                else {
                    $('#tasksProjectfilterContainer').slideDown();
                }
                return true;
            });
            $('#tasksSyncAllProjects').trigger('change');
            $('#jiraLogin').off().click(function () {
                var selectedServiceName = $('#currentService').val();
                var newService = parameter.oAuthServices.filter(function (s) { return s.serviceName == selectedServiceName; })[0];
                if (!newService) {
                    yasoon.alert.add({ type: yasoon.alert.alertType.error, message: yasoon.i18n('settings.loginNotPossible') });
                    throw new Error('Selected service ' + selectedServiceName + ' does not exist.');
                }
                if (!newService.appParams || !newService.appParams.url) {
                    yasoon.alert.add({ type: yasoon.alert.alertType.error, message: yasoon.i18n('settings.loginNotPossible') });
                    return false;
                }
                //Set new BaseUrl so it's considered for oAuth flow
                yasoon.setting.setAppParameter('baseUrl', newService.appParams.url);
                jira.settings.baseUrl = newService.appParams.url;
                yasoon.app.getOAuthUrlAsync('com.yasoon.jira', selectedServiceName, function (url) {
                    window.open(url);
                }, function () {
                    //Setting new currentService also set in jira.handleOauthSuccess() because of automated oAuth popups
                    jira.settings.currentService = selectedServiceName;
                    //Refresh UI --> standard yasoon Function
                    oAuthSuccess();
                });
                return false;
            });
            $('#addMailHeaderAutomatically').select2({ minimumResultsForSearch: 5 })
                .val(jira.settings.addMailHeaderAutomatically).trigger('change');
            $('#syncFeed').select2({ minimumResultsForSearch: 5 })
                .val(jira.settings.syncFeed).trigger('change');
            $('#jiraLogout').off().click(function () {
                yasoon.app.invalidateOAuthToken(_this.currentService);
                _this.currentService = '';
                yasoon.setting.setAppParameter('settings', JSON.stringify(_this));
                yasoon.view.header.triggerOAuthStatus.valueHasMutated();
                yasoon.view.settings.renderOptionPane(yasoon.view.settings.currentApp());
                return false;
            });
            var reloadOAuthHandler = function (e) {
                e.preventDefault();
                //We have a few checks to do.
                //This button shouldn't be used if
                // - it has already been clicked and processing is not finished yet
                // - it's currently an version running from a shadow folder 
                // - Or the downloaded app is newer (prevent implicit updates)
                $('#jiraReloadOAuth').prop('disabled', true).off();
                var app = yasoon.model.apps.get('com.yasoon.jira');
                yasoon.store.getLatestVersions(function (storeApp) {
                    if (storeApp.id > app.origin.versionId) {
                        yasoon.dialog.showMessageBox(yasoon.i18n('settings.pendingUpdates'));
                        $('#jiraReloadOAuth').off().prop('disabled', false).click(reloadOAuthHandler);
                        return;
                    }
                    if (app.origin.basePath.indexOf('update') > -1) {
                        yasoon.dialog.showMessageBox(yasoon.i18n('settings.pendingUpdatesApp'));
                        $('#jiraReloadOAuth').off().prop('disabled', false).click(reloadOAuthHandler);
                        return;
                    }
                    yasoon.app.downloadManifest(null, function (path) {
                        if (path) {
                            jira.downloadScript = true;
                            yasoon.app.update(null, null, function () {
                                yasoon.view.settings.renderOptionPane(yasoon.view.settings.currentApp());
                                yasoon.alert.add({ message: yasoon.i18n('settings.reloadSuccess'), type: 3 });
                            });
                        }
                    });
                });
                return false;
            };
            $('#jiraReloadOAuth').off().click(reloadOAuthHandler);
        };
        container.setContent(elem.html());
    };
    JiraSettingController.prototype.save = function () {
        var _this = this;
        var result = {};
        Object.keys(defaults).forEach(function (key) {
            result[key] = _this[key] || defaults[key];
        });
        yasoon.setting.setAppParameter('settings', JSON.stringify(this));
    };
    JiraSettingController.prototype.setLastSync = function (date) {
        this.lastSync = date;
        yasoon.feed.saveSyncDate(date);
        this.save();
    };
    JiraSettingController.prototype.updateData = function () {
        yasoon.setting.setAppParameter('data', JSON.stringify(jira.data));
    };
    return JiraSettingController;
}());
/// <reference path="../models/issueTask.ts" />
var JiraTaskController = (function () {
    function JiraTaskController() {
        this.requireFullSync = false;
    }
    JiraTaskController.prototype.handleTask = function (issue, task) {
        return Promise.resolve()
            .then(function () {
            if (task)
                return task;
            else
                return jiraGetTask(issue.key);
        })
            .then(function (dbTask) {
            var taskIssue = new JiraIssueTask(issue);
            if (taskIssue.isSyncNeeded()) {
                return taskIssue.save();
            }
            else if (dbTask) {
                return jiraRemoveTask(dbTask);
            }
        });
    };
    JiraTaskController.prototype.syncLatestChanges = function () {
        var _this = this;
        if (!jira.settings.syncTask)
            return Promise.resolve();
        if (this.requireFullSync) {
            this.requireFullSync = false;
            return this.syncTasks();
        }
        return Promise.resolve().then(function () {
            return jira.issues.all();
        })
            .each(function (issue) {
            return _this.handleTask(issue)
                .catch(function (e) {
                //Do not stop sync on error
            });
        });
    };
    JiraTaskController.prototype.syncTasks = function (forceSync) {
        if (!jira.settings.syncTask) {
            return Promise.resolve();
        }
        var updatedIssues = [];
        var ownIssues = [];
        var ownUserKey = jira.data.ownUser.key || jira.data.ownUser.name; //Depending on version >.<
        var getIssueData = function (jql, startAt) {
            return jiraGet('/rest/api/2/search?jql=' + jql + '&startAt=' + startAt + '&expand=transitions,renderedFields')
                .then(function (issueData) {
                //This is one of the first calls. We may have a proxy (like starbucks) returning an XML.
                jiraCheckProxyError(issueData);
                var result = JSON.parse(issueData);
                if (result.issues && result.issues.length > 0) {
                    ownIssues = ownIssues.concat(result.issues);
                }
                if (result.total > (result.maxResults + result.startAt)) {
                    return getIssueData(jql, (result.maxResults + result.startAt));
                }
            });
        };
        var jql = 'assignee="' + ownUserKey + '" AND status != "resolved" AND status != "closed" AND status != "done" ORDER BY created DESC';
        return getIssueData(jql, 0)
            .then(function (data) {
            return ownIssues;
        })
            .each(function (issue) {
            return new JiraIssueTask(issue).save(forceSync)
                .then(function () {
                updatedIssues.push(issue.key);
            })
                .catch(function (e) {
                yasoon.util.log('Error while updating task' + e);
            });
        })
            .then(function () {
            //Check other way around and look for resolved or reassigned issues
            return jiraAllFolders()
                .each(function (folder) {
                return jiraGetFolderTasks(folder.externalId)
                    .each(function (task) {
                    //First check if it has already been updated
                    if (updatedIssues.indexOf(task.externalId) > -1)
                        return;
                    //If we are here, we need to update the issue. it has either been assigned to someone else or it has been resolved
                    return jira.issues.get(task.externalId)
                        .then(function (issue) {
                        return jira.tasks.handleTask(issue, task);
                    })
                        .catch(function (e) {
                        yasoon.util.log('Error while removing task' + e);
                    });
                });
            });
        });
    };
    return JiraTaskController;
}());
